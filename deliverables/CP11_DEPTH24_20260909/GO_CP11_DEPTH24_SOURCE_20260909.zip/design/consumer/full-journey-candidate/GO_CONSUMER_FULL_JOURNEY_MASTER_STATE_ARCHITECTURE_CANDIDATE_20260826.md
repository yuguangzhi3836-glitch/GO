# GO Consumer Full Journey Master — State Architecture Candidate

Version: `GO-CONSUMER-FULL-JOURNEY-CANDIDATE-2026.08.26-01`  
Status: `CANDIDATE / NOT FROZEN / NOT PRODUCTION TRUTH`  
Parent visual baseline: `GO Consumer Design System 1.0 — Development Freeze`  
Governance: `GO Consumer App Version Governance V1.0.0 — Audit Seal`

## Scope

This candidate extends the frozen visual baseline across the five consumer verticals without rewriting the frozen V1.0 design-system files and without changing supplier, order, payment, refund, database, API, or settlement business truth.

Five verticals:

1. Hotel
2. Flight
3. Rail
4. Car Rental
5. Attraction

Each vertical is modeled as a full consumer journey:

`Search → Results → Detail/Selection → Checkout → Payment → Confirmation → GO Trips → Fulfillment → Change/Cancel/Refund → Review Eligibility → Review/Closed`

## Review eligibility state machine

`REVIEW_NOT_ELIGIBLE → REVIEW_ELIGIBLE → REVIEW_COMPLETED`

Eligibility triggers:

- Hotel: actual stay completed.
- Flight: actual flown segment completed.
- Rail: actual trip completed.
- Car Rental: actual return and fulfillment completion.
- Attraction: actual redemption/use completed.

`CANCELLED`, `REFUNDED_WITHOUT_FULFILLMENT`, `NO_SHOW_WITHOUT_FULFILLMENT`, `PAYMENT_FAILED`, `BOOKING_FAILED`, `TICKETING_FAILED`, and `EXPIRED_UNUSED` do not create review eligibility.

## Refund state chain

Cancellation and refund are separate state domains.

`REFUND_ELIGIBILITY_CHECK → REFUND_REQUESTED → SUPPLIER_PROCESSING → REFUND_AMOUNT_CONFIRMED → REFUND_INITIATED → PSP_PROCESSING → REFUND_COMPLETED`

Failure/recovery states remain explicit:

`REFUND_FAILED`, `REFUND_REQUIRES_ACTION`.

## Flight / Rail change flow

`Original Order → Eligibility → Allowed Change Scope → New Options → Fare Difference → Change Fee → Pay/Refund Difference → Supplier Confirmation → New Ticket → GO Trips Update`

Supplier confirmation may fail after payment; UI must not manufacture a new-ticket success fact without supplier evidence.

## Color hierarchy candidate clarification

- `White / Neutral = Space`
- `Navy = Structure`
- `GO Blue = Interaction & Brand Signal`
- `GO Orange = Offer & Value Signal`

GO Blue is allowed. Ctrip-style high-saturation blue UI language is not. Blue must not become the page area/surface color.

## Production truth boundary

This document and its accompanying visual board are design/state-architecture artifacts. They do not prove real PSP, airline, rail, rental, attraction, hotel, payment, cancellation, refund, or production runtime completion.
