# GO Consumer Design System 1.0
## 开发冻结版 / Development Freeze

**版本：V1.0**  
**冻结日期：2026-08-26**  
**状态：FROZEN**  
**适用端：iOS / Android / Web / H5**  
**基准页面：GO Consumer Home / Reference / 10.0**

> 冻结原则：除非发布新的 Design System 版本，任何产品、设计、研发人员不得自行修改本规范中的 Token、组件结构、品牌比例、视觉优先级及评级表达。

## 1. 设计总原则

GO Consumer UI 的设计语言固定为：**极简、克制、可信、直接、具有独立判断。**

首页不得演化为传统 OTA 的高密度促销页面。

视觉优先级固定为：

1. GO 主品牌
2. GO AI / GO Offer
3. GO 推荐
4. 旅行内容
5. GO 直连 / GO 推荐 / GO 礼遇
6. 辅助导航及状态信息

位置高低不等于视觉权重高低。任何开发实现必须同时满足：品牌一致、Token 一致、组件一致、信息层级一致、响应式行为一致、跨端视觉一致。

## 2. Global Design Tokens

### 2.1 Color Tokens

```text
GO.Color.Navy              #071B55
GO.Color.Blue              #0878F9
GO.Color.Orange            #FF4B16
GO.Color.White             #FFFFFF
GO.Color.Black             #000000

GO.Text.Primary            #071B55
GO.Text.Secondary          rgba(7,27,85,0.68)
GO.Text.Tertiary           rgba(7,27,85,0.50)
GO.Text.Disabled           rgba(7,27,85,0.30)

GO.Border.Default          rgba(7,27,85,0.08)
GO.Divider                 rgba(7,27,85,0.08)

GO.Surface.Base            #FFFFFF
GO.Surface.AI              #F6F9FF
GO.Surface.Offer           #FFF8F5
GO.Surface.Elevated        #FFFFFF

GO.Image.Overlay.Start     rgba(0,10,40,0.00)
GO.Image.Overlay.End       rgba(0,10,40,0.68)

GO.Badge.Background        rgba(7,27,85,0.90)
GO.Badge.Text              #FFFFFF

GO.Rating.OnImage          rgba(255,255,255,0.96)
GO.Rating.Separator        rgba(255,255,255,0.64)
```

以上色值为 V1.0 开发冻结值。未经 Design System 升版，不得自行“调蓝”“调橙”“调灰”。

## 3. Typography Tokens

中文：**PingFang SC**  
英文及数字：**SF Pro**

Web 备用字体：

```text
-apple-system,
BlinkMacSystemFont,
"SF Pro Display",
"SF Pro Text",
"PingFang SC",
"Helvetica Neue",
Arial,
sans-serif
```

固定字号：

```text
GO.Type.Display        22px / 30px / 600
GO.Type.Title.L        20px / 28px / 600
GO.Type.Title.M        18px / 26px / 600
GO.Type.Title.S        16px / 24px / 600
GO.Type.Body.L         15px / 23px / 400
GO.Type.Body.M         14px / 22px / 400
GO.Type.Body.S         13px / 20px / 400
GO.Type.Caption.L      12px / 18px / 500
GO.Type.Caption.S      11px / 16px / 400
GO.Type.Rating         12px / 18px / 500
GO.Type.Badge          10px / 14px / 500
GO.Type.Nav            12px / 18px / 500
```

字重只允许：Regular 400 / Medium 500 / Semibold 600。禁止使用 700 Bold 作为常规视觉层级。

## 4. Spacing System

```text
GO.Space.2      2
GO.Space.4      4
GO.Space.6      6
GO.Space.8      8
GO.Space.12     12
GO.Space.16     16
GO.Space.20     20
GO.Space.24     24
GO.Space.32     32
GO.Space.40     40
```

首页基准：

```text
Page.HorizontalPadding      12
Section.VerticalGap         20
Card.InternalPadding        18
Card.HorizontalGap           8
IconLabel.Gap                8
TitleBody.Gap               12
```

禁止使用非 Token 间距。

## 5. Radius System

```text
GO.Radius.S        8
GO.Radius.M       12
GO.Radius.L       16
GO.Radius.XL      20
GO.Radius.Pill   999
```

使用规则：Recommendation Card 12；GO AI / GO Offer 16；Category Container 16；Bottom Navigation 16；Badge 999；Voice Button 999。

## 6. Shadow System

只允许两个标准阴影：

```text
GO.Shadow.Subtle = 0 2px 12px rgba(7,27,85,0.035)
GO.Shadow.Card   = 0 4px 18px rgba(7,27,85,0.045)
```

禁止黑色重阴影、双重阴影、Material Design 式浮层、Blur 超过 24px 的常规卡片阴影。

## 7. GO Logo System

### 7.1 Asset Rule

GO Logo 必须调用正式 SVG。禁止文字重绘、PNG 替代主 SVG、将 G/O 分开拼接、修改 O 开口比例、修改橙色连接块位置、修改 G 与 O 的尺寸关系。

### 7.2 主 Logo

```text
Header.GO.Width      98
Header.GO.Height     Auto
GO : AI DIRECT+      1 : 1.60
Divider Width        1px
Divider Height       48px
Divider Color        rgba(7,27,85,0.28)
```

AI DIRECT+：18 / 600 / letter-spacing 0.18em / GO.Navy。`+` 使用 GO.Orange，视觉高度为大写字母 cap-height 的 60%。

## 8. Category Navigation

首页固定五个一级旅行品类：酒店、机票、火车票、租车、景点玩乐。不得增加第六个入口。

```text
Height             88
Radius             16
Background         #FFFFFF
Shadow             GO.Shadow.Subtle
Icon Size          24
Icon Stroke        1.5
Icon Color         GO.Navy
Text               GO.Type.Body.M
```

五项等宽。

## 9. GO AI / GO Offer

这是首页的一级交互中心，两卡保持完全对称。

```text
Card Gap            8
Card Radius        16
Card Padding       18
GO AI Background  #F6F9FF
GO Offer Background #FFF8F5
Voice Diameter     78
Microphone         29
GO Mark            26
Glow.1 Opacity     0.08
Glow.2 Opacity     0.04
Glow.3 Opacity     0.02
```

不允许增加第四层光环。若启用 idle 动效：Scale 1.00 → 1.025 → 1.00；Duration 2200ms；Easing ease-in-out。

## 10. Trust Layer

固定组件：GO 直连 / GO 推荐 / GO 礼遇。定义为 **Trust Layer**，不是一级 Feature。

固定文案：

**GO 直连**  
直连官方  
交易更直接

**GO 推荐**  
独立判断  
只推荐值得的

**GO 礼遇**  
官方专享  
尊享更多礼遇

```text
Title Size          14
Title Weight        500
Title Opacity       0.92
Body Size           11
Body Weight         400
Body Opacity        0.50
Body LineHeight     16
Divider Width       1
Divider Opacity     0.08
Small GO Logo Width 30
```

整个 Trust Layer 不允许提升到一级视觉权重。

## 11. GO Recommendation Badge

组件名称：`GORecommendationBadge`

```text
Height               20
Padding.Horizontal    8
Radius               999
Background           rgba(7,27,85,0.90)
Text Color           #FFFFFF
Font                 10 / 14 / 500
Top                   8
Left                  8
```

固定文字：**GO 推荐**。任何页面不得自行设计第二套 GO 推荐 Badge。

## 12. GO Rating System

组件名：`GORating`

唯一表达格式：**GO ★★★★★+ · 4.9**

禁止：`GO | ★★★★★+ | GO 4.9`、`★★★★★ GO 4.9`、`GO评分 4.9`、`★★★★★ 4.9`。

```text
GO Mark        12 / 600
Stars          11 / 500
Plus            8 / 500
Separator      12 / 400
Score          12 / 500
GO → Stars      4
Stars → +       1
+ → ·           5
· → Score       5
On-image Color rgba(255,255,255,0.96)
Separator      rgba(255,255,255,0.64)
```

星级与 4.9 不是同一个字段。后端分别输出 `go_star_level` 和 `go_score`。UI 不得根据 `4.9` 自行推导 `★★★★★+`。

## 13. Recommendation Card

组件名：`GORecommendationCard`

```text
Radius               12
Gap                   8
Image Overlay         0 → 0.68
Title                 14 / 20 / 600
Description           12 / 18 / 400
Description Opacity   0.90
Rating Bottom         10
Badge Top              8
Badge Left             8
```

## 14. Bottom Navigation

固定五项：首页、行程、收藏、消息、我的。

```text
Height              68
Radius              16
Background          #FFFFFF
Shadow              GO.Shadow.Subtle
Icon Size           24
Icon Stroke         1.5
Active Color        GO.Blue
Inactive Color      GO.Navy
Text                GO.Type.Nav
```

不允许 Tab 超过五项。

## 15. Component States

所有核心交互组件至少实现：Default / Pressed / Focused / Disabled / Loading / Error。

Pressed：Scale 0.98；Duration 120ms；Opacity 0.94。  
Disabled：Opacity 0.36；Pointer disabled。  
Loading：不得改变卡片尺寸，使用 skeleton 或局部 loading，禁止整个首页闪白刷新。  
Error：保留原卡尺寸，使用正文错误提示，不使用大面积红底，不使用系统 Alert 作为常规失败体验。

## 16. Responsive Rules

设计基准：390pt。必须验收：375pt / 390pt / 430pt / ≥768pt。

### 375pt
- 保持双卡并排
- 横向间距不缩至 6 以下
- 字号不缩小
- Logo 不压缩变形
- 推荐卡允许展示 2.35–2.55 张

### 390pt
采用 Reference Master。

### 430pt
- Page padding = 16
- 双卡保持并排
- 推荐卡允许 2.7–3 张露出
- 字号不放大

### ≥768pt
内容最大宽度 768，居中显示，禁止无限拉宽卡片。

## 17. Light / Dark Boundary

GO Consumer Home 为 **Light-first**。V1.0 首页在系统 Dark Mode 下仍允许保持 Light Brand Surface。

```text
Home Brand Surface = Light Locked
```

系统状态栏、Modal、Sheet 可适配 Dark Mode。禁止未经专门设计直接反色。未来 GO Dark Theme 必须作为 Design System 2.x 独立设计。

## 18. SVG Asset Rules

所有品牌核心资产必须 SVG，包括：GO Main Logo、GO AI、GO Offer、GO 推荐 Badge 标记、Navigation Icons、Category Icons。

要求：必须存在 viewBox；不得包含 raster image；不得 hard-code 页面背景；不得使用 filter 模拟重阴影；不得转换为 Base64。

Stroke Icon：Stroke Width 1.5；Linecap round；Linejoin round。禁止同一页面混用 Outline / Filled / 2px Stroke / 1px Stroke。

## 19. Platform Mapping

### iOS
pt = Design Token；SF Pro / PingFang SC；CornerRadius = Token；Color = sRGB；优先 SwiftUI Semantic Token。

### Android
1 dp = 1 Design Unit；Typography 使用 sp；品牌尺寸保持设计视觉等效，不做设备厂商个性化适配。

### Web

```css
:root {
  --go-navy: #071B55;
  --go-blue: #0878F9;
  --go-orange: #FF4B16;
  --go-radius-s: 8px;
  --go-radius-m: 12px;
  --go-radius-l: 16px;
  --go-space-4: 4px;
  --go-space-8: 8px;
  --go-space-12: 12px;
  --go-space-16: 16px;
  --go-space-20: 20px;
  --go-space-24: 24px;
}
```

禁止业务页面重新定义品牌色。

## 20. Accessibility

Body Contrast ≥ WCAG AA；Tap Target ≥ 44×44；Focus State 必须可见；支持系统正常字号。GO Blue / Orange 不得作为唯一状态表达，状态必须同时通过 Icon / Text / Shape 至少一种辅助信号表达。

## 21. Pixel QA Checklist

### Brand
- [ ] GO Logo 为正式 SVG
- [ ] Logo 未变形
- [ ] G/O 比例正确
- [ ] O 开口正确
- [ ] 橙色连接块位置正确
- [ ] AI DIRECT+ 比例正确

### Color
- [ ] Navy = #071B55
- [ ] Blue = #0878F9
- [ ] Orange = #FF4B16
- [ ] 无自行吸色
- [ ] 无额外品牌蓝
- [ ] 无额外品牌橙

### Layout
- [ ] 横向 Padding 符合 Token
- [ ] Section Gap = 20
- [ ] 双卡 Gap = 8
- [ ] Card Radius = 16
- [ ] Recommendation Radius = 12
- [ ] Bottom Nav Radius = 16

### GO AI / Offer
- [ ] 两卡等宽
- [ ] Voice Button = 78
- [ ] 光环只有三层
- [ ] Opacity = 8% / 4% / 2%
- [ ] 蓝橙角色未互换

### Trust Layer
- [ ] GO 直连 / GO 推荐 / GO 礼遇位置一致
- [ ] Body Opacity = 50%
- [ ] 分隔线 Opacity = 8%
- [ ] 视觉权重明显低于双卡

### Rating
- [ ] 格式仅为 GO ★★★★★+ · 4.9
- [ ] 无第二个 GO
- [ ] 无竖线
- [ ] 星级字段来自后端
- [ ] Score 字段来自后端
- [ ] UI 不自行推导星级

### Recommendation
- [ ] GO 推荐 Badge 位置正确
- [ ] Badge 样式唯一
- [ ] 图片 Overlay 正确
- [ ] 文字可读
- [ ] 图片未过度压暗

### Navigation
- [ ] 仅五项
- [ ] 首页 Active = GO Blue
- [ ] 其他为 Navy
- [ ] Icon 风格一致

## 22. Pixel QA 公差

```text
Position            ±1px
Spacing             ±1px
Component Size      ±1px
Logo Size           ±1px
Radius              0px tolerance
Color HEX           0 tolerance
Opacity             ±0.02
Font Size           0 tolerance
Font Weight         0 tolerance
```

品牌色、Logo 比例、字号、Rating 表达不接受“肉眼差不多”。

## 23. 真机验收设备

最低必须完成：375pt / 390pt / 430pt。并完成 iOS Safari / Native、Android Chrome / Native、Desktop Chrome Web Responsive。截图需与 Reference Master 并排对比。

## 24. Visual Hierarchy Acceptance

将首页截图缩小至 25% 或进行 Blur Test。正确视觉顺序必须仍为：

**GO → GO AI / GO Offer → GO 推荐 → 推荐旅行内容 → GO 直连 / GO 推荐 / GO 礼遇**

若 Trust Layer 在 Blur Test 中比 GO 推荐更抢眼：**NO-GO**。  
若五大品类入口比 GO AI / Offer 更抢眼：**NO-GO**。

## 25. 禁止事项

V1.0 禁止：首页增加巨大 Hero、大面积营销 Banner、闪烁促销角标、红色价格刺激、OTA 式满减标签堆积、多套蓝色、多套橙色、强阴影、玻璃拟态、过度 AI 光效、GO Logo 任意变体、GO Rating 任意改写、Trust Layer 提升权重、首页新增超过五个一级旅行品类。

## 26. 开发冻结声明

本文件自 V1.0 起成为 **GO Consumer UI 前端开发、设计验收及视觉 QA 的唯一首页基线**。

Reference Page：**GO Consumer Home / Reference / 10.0**

开发验收不再使用“看起来差不多”。唯一验收口径：**Token 一致、Asset 一致、Component 一致、Hierarchy 一致、Responsive 一致、Pixel QA 通过。**

未经 Design System Version Upgrade：**不得修改。**

---

## FINAL STATUS

**GO Consumer Design System 1.0**  
**HOME VISUAL MASTER**  
**DEVELOPMENT FREEZE**  
**STATUS: FROZEN / READY FOR IMPLEMENTATION**
