# Sprint 2C — Real Staging Certification + TestFlight / Play Internal Release Gate

Sprint 2C adds no consumer product features. It converts the Sprint 2B release baseline into an explicit, evidence-driven release certification process.

A release may be declared `INSTALLABLE_INTERNAL` only after every BLOCKER gate is PASS with evidence. Local/static validation cannot substitute for credentials, real infrastructure, store processing, or physical-device testing.

## Blocker gates

1. PostgreSQL 16 staging migration + concurrency tests
2. Redis queue/outbox/push worker smoke
3. PSP sandbox tokenization + auth/capture/void/refund lifecycle
4. Real hotel connector sandbox booking/cancel/status reconciliation
5. APNs iOS delivery + receipt lifecycle
6. FCM Android delivery + receipt lifecycle
7. Universal Link apple-app-site-association validation
8. Android App Link assetlinks.json validation
9. Apple Developer/App Store Connect signing and app record
10. Google Play signing and app record
11. iOS production/preview binary built and uploaded to TestFlight
12. Android AAB built and uploaded to Play Internal Testing
13. Physical iPhone P0 golden-path matrix
14. Physical Android P0 golden-path matrix
15. Store submission metadata/privacy/support checklist

## Release states

- `ENGINEERING_READY`: local code/config gates pass; external gates may remain blocked.
- `STAGING_CERTIFIED`: real infrastructure/PSP/connector/push/link gates pass.
- `INSTALLABLE_INTERNAL`: TestFlight and Play Internal binaries are installed and P0 real-device E2E passes.
- `PRODUCTION_CANDIDATE`: internal certification passes and store production checklist is complete.

## Safety rule

No release gate may be marked PASS from a placeholder, mock provider, synthetic push receipt, SQLite compatibility run, or unverified screenshot. Evidence must identify environment, build/version, timestamp and responsible system/tester.
