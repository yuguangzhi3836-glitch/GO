# Recovery Experimentation Governance

A Strategy Version defines a candidate adaptive policy. An Experiment defines how GO proves that candidate is better and safe enough to promote.

Promotion requires configured minimum samples, primary metric significance when enabled, stratification coverage, and safety guardrails. Timeout/manual-review regression can force immediate `DEGRADE` even if confirmation rate improves.

Calibration Profiles are evidence-backed outputs of promoted experiments. They remain governance inputs, not Supplier Facts and not permission to resend a timed-out mutation.
