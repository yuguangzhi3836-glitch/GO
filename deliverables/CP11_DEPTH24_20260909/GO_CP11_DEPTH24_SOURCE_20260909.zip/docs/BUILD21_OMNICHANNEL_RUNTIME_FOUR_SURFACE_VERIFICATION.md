# Build 21 — Omnichannel Runtime + Four-Surface Operations

Runtime 8.4.0, DB head 0093. Signed per-channel callbacks, replay protection, state convergence, ledger-once behavior, Supplier finance, Admin payment operations and Finance reconciliation surfaces are implemented. Consumer Intent/channel APIs exist; full checkout replacement remains runtime pending. External executors, credentials, Sandbox certification, Canary and Live remain Phase 2 and are not claimed.
