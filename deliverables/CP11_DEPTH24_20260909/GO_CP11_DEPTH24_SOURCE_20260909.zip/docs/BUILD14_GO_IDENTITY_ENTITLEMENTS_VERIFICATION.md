# Build 14 — GO Identity Entitlements Verification

Date: 2026-08-18  
Runtime contract: 8.0.0  
Database head: `0090_go_identity_entitlements`

## Implemented

- Unified `MEMBER / STAFF / FRIENDS_FAMILY / OWNER` credential model.
- Evidence records with source, reference, subject match, confidence, validity and SHA-256 identity.
- Deterministic Staff/Owner activation threshold; AI or an operator cannot directly bypass the rule service.
- Staff lifecycle supports `PENDING / ACTIVE / REVIEW / SUSPENDED / EXPIRED / REVOKED`; revocation does not delete the underlying GO Account.
- Supplier opt-in controls dates, rooms, inventory limit and authorized benefits.
- Staff price is fixed at 60% of BAR when eligible; supplier cannot choose another Staff discount.
- Friends & Family invitations are named, limited, non-transferable and priced weaker than Staff.
- Owner selects exactly one path: `OWNER_RATE` (60%, no high-cost benefit stacking) or `OWNER_BENEFITS` (no deep discount); both retain Owner Recognition.
- Identity selection returns only the currently applicable identity and explicitly disables stacking.
- Consumer `GO 身份` screen implements loading, empty, error/retry and Owner path selection states.

## Verification executed in this workspace

- `python -m compileall -q src tests alembic/versions` — PASS.
- Static assertions for migration head, five model objects, 60% rule, Owner mutual-exclusion values, non-stacking and non-transferability — PASS.

## Remaining before registry items ID-01 through ID-05 can be DONE

- Run migration and pytest in a dependency-complete environment.
- Add Supplier program configuration UI and GO Admin evidence/review/transition UI.
- Parse/type-check the Consumer TSX with the declared production toolchain and register the new screen in final navigation.
- Add expiry scheduler, periodic evidence revalidation, risk-signal ingestion and invitation consumption counters.
- Add search/hotel/order presentation tests proving that only the selected active identity price/benefit is shown.

This artifact verifies implemented code only. It does not claim real HR, ownership registry, supplier, payment or production activation.
