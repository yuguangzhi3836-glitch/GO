# GO Recovery Supplier Adapter Contract — Sprint 3I

Sprint 3I replaces the Sprint 3H inline supplier mutation hook with a production-shaped adapter boundary. The contract is deliberately separate from Journey reasoning: GO may decide *what* recovery should be attempted, but only the Vertical adapter may translate that intent into supplier-specific servicing calls.

## Required adapters

- FlightRecoveryAdapter — NDC/GDS/airline servicing contract boundary.
- RailRecoveryAdapter — official rail change/reissue contract boundary.
- MobilityRideRecoveryAdapter — airport transfer / point-to-point servicing boundary.
- MobilityRentalRecoveryAdapter — rent-a-car modification boundary.
- HotelRecoveryAdapter — hotel servicing boundary.
- AttractionRecoveryAdapter — attraction/session/ticket servicing boundary.

## Required methods

Every adapter implements `revalidate`, `mutate`, `poll`, and `parse_webhook`. Capabilities explicitly declare supplier-side idempotency, polling, webhook support, and lookup by idempotency key.

`mutate()` receives a GO-generated stable supplier idempotency key. The same Recovery Execution Item must reuse the same key after process restart, timeout, reconciliation, or safe retry. A client timeout is never evidence that the supplier mutation was not applied.

## Durable external-state rule

`CONFIRMED` is accepted only from a supplier confirmation response, authoritative poll result, signed supplier webhook, or audited manual reconciliation. `UNKNOWN` or asynchronous acceptance creates a persistent reconciliation job. Worker leases expire and can be reclaimed after a crash. Retry exhaustion transitions to `DEAD_LETTER` and `MANUAL_REVIEW`; it does not blindly resend the supplier mutation.

## Engineering implementation boundary

The adapters shipped in Sprint 3I are deterministic production-shaped engineering adapters. They validate orchestration semantics and connector contracts, but are not live NDC, China Rail, Mobility, Hotel, or Attraction production integrations. Production adapters must implement the same contract and preserve the same idempotency and evidence rules.
