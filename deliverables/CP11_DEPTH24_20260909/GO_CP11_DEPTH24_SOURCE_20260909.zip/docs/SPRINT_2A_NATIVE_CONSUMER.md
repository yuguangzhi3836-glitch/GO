# Sprint 2A — Native Consumer Full UI + Real Mobile Golden Path + Push Event Orchestration

## Product path

`GO ID Login -> Home -> Search -> Hotel Detail -> Prebook -> Booking Review -> Payment Authorization -> Supplier Book -> Capture -> Booking Success -> GO Trips -> Change / Cancel / Refund / Stay Credit -> Quick Review`

The native client does not own business rules. Price, inventory, fare conditions, payment terminal state, refund amount, Stay Credit and review/risk decisions remain server-side facts.

## Mobile engagement mapping

| Domain fact | Mobile intent | Deep link |
|---|---|---|
| `ORDER_CONFIRMED` | Booking confirmed | `go://trips/order/{order_id}` |
| Check-in minus 24h | Check-in reminder | `go://trips/order/{order_id}` |
| `REFUND_COMPLETED` | Refund completed | `go://trips/order/{order_id}` |
| `COMPENSATION_COMPLETED` | Supplier-fault compensation completed | `go://trips/order/{order_id}` |
| `FULFILLMENT_COMPLETED` + 4h | First review invite | `go://reviews/{review_id}` |
| Next authenticated app open while still not reviewed | Blocking Uber-style Quick Review | `go://reviews/{review_id}` |

The four-hour review delay is a deterministic default inside the locked hotel 2–10 hour window. Completed reviews cancel any remaining review engagement job and never trigger the second prompt.

## Review semantics

- Raw input remains 1–5 stars.
- 4/5 stars can complete immediately.
- 1–3 stars require at least one structured issue tag.
- Raw star is not the public experience score.
- Public normal experience remains 3.0–5.0.
- Serious hygiene/safety/no-room/fraud/abnormal-charge tags create a separate `RISK_EVENT_CANDIDATE`.

## Native security

- Access and rotating refresh tokens: OS secure storage (`expo-secure-store`).
- Mobile mutation wrappers derive consumer ownership from JWT, never request `account_id`.
- Wallet exposes tokenized payment references only; PAN/CVC are not persisted by GO.
- Deep links are allowlisted by the backend.
- Push token is encrypted at rest and never returned by read APIs.

## Production boundary

This repository validates the mobile/domain contract. A store release still requires Apple/Google signing, physical-device builds, real APNs/FCM credentials and receipts, production Universal/App Link files, PCI-compliant native PSP tokenization, accessibility/visual QA, and real PostgreSQL/Redis staging gates.
