# Build 10｜First GO-Hosted Hotel Direct Booking Pilot

首家 Pilot 锁定哈尔滨敖麓谷雅酒店。GO 提供直订页面，酒店在后台管理房价、库存、确认、拒绝与取消。支付宝商户主体已确认，但开放平台应用尚未申请，因此系统只接受预订申请，明确显示不扣款。

DB head `0081_first_go_hosted_direct_booking_pilot`，新增 Hotel、Room Offer、Reservation、Reservation Event、Payment Readiness 五个对象及 9 条 API。页面入口 `/go-app/direct.html`。预订状态为 `PENDING_HOTEL_CONFIRMATION`，支付状态为 `ALIPAY_APPLICATION_PENDING_NO_CHARGE`；酒店确认后为 `HOTEL_CONFIRMED_AWAITING_ALIPAY_ONBOARDING`，仍不表示付款。取消为 `NO_PAYMENT_NO_REFUND_REQUIRED`。

验收：Build 10 7/7；Build 8–10 联合 22/22；Fresh DB 385 表、新表 5/5；OpenAPI 7.2.0 / 585 paths / 新增 9；443 Python 文件、15 Web JS 通过。当前 payment_live=false、production_live=false。
