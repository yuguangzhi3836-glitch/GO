# Mother Plan Production Build 4 — Connector Registry / Certification / Live Gate

Database head: `0075_production_connector_live_gate` (parent `0074_good_hotel_standard`).

The production control plane implements `ENGINEERING -> CONNECTABLE -> CERTIFIABLE -> CERTIFIED -> OBSERVABLE -> SWITCHABLE -> LIVE`, plus `SUSPENDED` and `REVOKED`. Engineering or sandbox adapters cannot pass the production Live Gate.

## Mandatory evidence

- formal supplier legal identity and signed contract/distribution authority;
- external vault reference only (no inline API keys, passwords, certificates or private keys);
- passing sandbox and production certification evidence;
- idempotency, signed webhooks, query-by-idempotency, reconciliation, settlement/refund;
- runtime telemetry, SLO, alerts, kill switch and fail-safe/rollback capability;
- maker-checker activation, approved change window, rollback plan and production smoke test.

Every certification, assessment, activation and kill-switch action writes a hashed governance event. A production-shaped engineering adapter is never represented as production-certified or LIVE.
