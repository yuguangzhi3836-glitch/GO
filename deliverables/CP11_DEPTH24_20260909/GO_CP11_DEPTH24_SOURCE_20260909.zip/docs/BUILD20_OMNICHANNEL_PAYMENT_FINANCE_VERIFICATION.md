# Build 20 — Omnichannel Payment & Financial Reconciliation OS

Runtime `8.3.0`; DB head `0093_omnichannel_payment_finance_os`.

The channel-neutral core supports Payment Intent, Authorization/Capture/Refund/Payout operation types, globally idempotent attempts, explicit channel selection, consented fallback, unknown-external-state reconciliation, credential references, webhook receipt objects, double-entry ledger entries and channel/bank/ledger reconciliation with fee/tax/FX differences.

First-class channels: Alipay, WeChat Pay, UnionPay QuickPass, Visa, Mastercard, Amex, JCB, UnionPay Card, Apple Pay, Google Pay, corporate e-bank/bank transfer, corporate credit/monthly billing, and regional adapters.

Static Python/migration verification is required in this environment. Dedicated pytest, Fresh Alembic, Runtime OpenAPI and four-surface E2E remain dependency-complete verification gates. External executors are hard blocked; no Sandbox, certification, charge, refund, payout or Live claim is made.
