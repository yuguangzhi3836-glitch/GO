# Build 18 — Supplier Fault + Double Compensation Product Closure

Date: 2026-08-18

## Closed product gap

- Supplier Console now uses a dedicated `Unable to Fulfill` flow with reason and evidence IDs; it does not disguise supplier inability as an ordinary guest cancellation.
- Deterministic classification keeps supplier fault, external cause, guest fault and unresolved/evidence-required paths separate.
- Confirmed supplier fault calculates refund = 1× actual paid and additional compensation = 1× actual paid; total return = 2× actual paid.
- Funding sequence remains settlement offset → reserve → authorized bank debit → Consumer Protection Fund advance + supplier negative balance.
- Future supplier settlements recover the protection advance before becoming supplier-available payout.
- Consumer order detail separately presents original-payment refund and additional fulfillment compensation while hiding supplier cash-shortage/recovery mechanics.
- GO Admin governance shows fault cases, liabilities, protection-fund advances/recoveries and negative-balance state.

## Verification

- Python compileall — PASS.
- Supplier/Admin Console JavaScript parse — PASS.
- Consumer/Supplier/Admin/API/service static contract — PASS.
- Existing dedicated compensation tests cover bank debit, protection advance, no-mandate, external cause, evidence-required, idempotency and future-settlement recovery, but could not be rerun because pytest is absent in this environment.

No engineering ledger or mock payment result is represented as real bank debit, real fund transfer or Production Live settlement.
