# Production Readiness Gate

A production release is BLOCKED if any blocker fails: database connectivity, non-default JWT signing key, non-default connector vault key, Secure cookies in production, mandatory Admin MFA in production, and GLOBAL_WRITES kill switch inactive.

Additional staging/CI gates: PostgreSQL 16 concurrency tests, backup restore drill, OIDC IdP certification, TLS/WAF validation, payment/connector sandbox certification, webhook signature and replay tests, outbox/DLQ drain test, recovery worker reconciliation test, and tenant isolation adversarial tests.
