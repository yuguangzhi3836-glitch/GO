# GO Ultimate Mother Plan — Phase 1 Coverage Registry

Baseline: `GO_ULTIMATE_MASTER_PLAN_V6.1_2026-08-22_THREE_TIER_POSITIONING_MASTER`  
Registry date: 2026-08-22  
Phase 1 objective: code and system design reach 100% before external Sandbox/Canary/Live activation.

## Definition of Done

A requirement is `DONE` only when all applicable evidence exists:

1. versioned system design and deterministic business rules;
2. persistent data model plus Alembic migration;
3. production API/service implementation with authorization, idempotency and audit/evidence boundaries;
4. required Consumer, Partner/Supplier and GO Admin user journeys;
5. positive, negative, state-transition and regression tests;
6. no demo data, silent fallback, mock external success or document-only placeholder in a production path.

`EXTERNAL_PENDING` may still count as Phase 1 complete only when the production adapter contract, signature/callback/idempotency/reconciliation behavior, failure semantics, simulator and tests are complete and the runtime truthfully remains non-live. Real credentials, supplier certification, Sandbox execution, Canary and Live Gate are Phase 2.

## Status vocabulary

| Status | Meaning |
|---|---|
| `DONE` | Meets the Phase 1 Definition of Done. |
| `PARTIAL` | Some code/design exists, but one or more required surfaces or tests are missing. |
| `MISSING` | No sufficient implementation evidence. |
| `RUNTIME_PENDING` | Implementation exists but executable verification has not passed in the dependency-complete environment. |
| `EXTERNAL_PENDING` | Phase 1 adapter contract can be complete; real external activation remains Phase 2. |

## Authoritative requirement register

| ID | Requirement family | Current | Required closure evidence |
|---|---|---:|---|
| GOV-00 | Three-tier strategic positioning + Official Direct terminology hierarchy | `DONE` | Runtime master baseline locks: Global Travel Gateway / Global Travel Infrastructure / Global Official Direct Booking Platform; GO直连 remains product capability and Official Direct Network remains underlying connection asset |
| GOV-01 | Global Day-1 multi-vertical architecture | `RUNTIME_PENDING` | Six-vertical/eleven-capability matrix and uniform state contract implemented; route/UI parity runtime pending |
| GOV-02 | Direct First + governed external supply | `RUNTIME_PENDING` | Cross-vertical official-first selector, explicit authorized fallback and negative tests implemented; runtime pending |
| GOV-03 | Truth / Judgment / User Fit separation | `DONE` | Existing domain models, services and separation tests |
| GOV-04 | Evidence Chain, immutable ledgers, rule versions | `RUNTIME_PENDING` | Cross-domain mutation/evidence policy and forbidden-action contract implemented; runtime coverage audit pending |
| CON-01 | Consumer GO Account, GO ID, traveler, wallet | `DONE` | Existing Sprint 1Y implementation and tests |
| CON-02 | Consumer production-only data paths | `RUNTIME_PENDING` | Demo transaction facts removed across Home/search/detail/booking/payment/trips/journey/recovery/refund/review/notifications; formal TSX and runtime regression pending |
| CON-03 | Unified search/detail/order/trip/refund across verticals | `RUNTIME_PENDING` | Evidenced six-vertical lifecycle projection, stale-fact protection, account isolation and unified Trips UI implemented; producer/E2E runtime pending |
| CON-04 | Consumer Cellular Growth Engine | `DONE` | Growth events/attribution, MATU/organic ratio/Consumer Cellular K, Trip Invite→Member→Join shared-read, Adult Traveler Claim + Guardian boundary, Hotel/Staff source attribution and P0 tests |
| DIRECT-01 | Three-layer Consumer value: Recommendation / Official Direct Value / Market Benchmark | `DONE` | Runtime value-layer API; Recommendation/Value firewall; comparable benchmark evidence and UI contract |
| DIRECT-02 | Official Direct Value priority and ~3% value anchor | `DONE` | Upgrade priority → late checkout → ~3% cash → breakfast option; 3% non-mandatory/non-recommendation-gate guardrail |
| DIRECT-03 | Supplier Value Optimizer + Direct Channel Economics | `DONE` | Supplier offer controls, perceived-value/incremental-cost separation, channel economics evidence, net revenue uplift and supplier console surfaces |
| ID-01 | Member/Staff/F&F/Owner credential domain | `RUNTIME_PENDING` | Models/migration/API/event evidence plus Consumer/Supplier/Admin surfaces implemented; runtime tests pending |
| ID-02 | GO Staff automatic verification state machine | `RUNTIME_PENDING` | Transitions, periodic revalidation and risk ingestion implemented; runtime tests pending |
| ID-03 | GO Staff uniform 60% rate and supplier opt-in controls | `RUNTIME_PENDING` | Price/open dates/rooms/inventory rules and Supplier UI implemented; presentation/runtime tests pending |
| ID-04 | GO Friends & Family controlled entitlement | `RUNTIME_PENDING` | Named limited non-transferable invitation and consumption counters implemented; runtime tests pending |
| ID-05 | GO Owner mutually exclusive dual paths | `RUNTIME_PENDING` | Mutual selection, non-stacking, recognition and Consumer UI implemented; runtime tests pending |
| HOTEL-01 | Structured hotel Fare Families and snapshots | `DONE` | Existing fare-rule implementation and tests |
| HOTEL-02 | Supplier cancellation fault and double compensation | `RUNTIME_PENDING` | Deterministic chain, Consumer/Supplier/Admin UI, liability/protection-fund evidence implemented; runtime regression pending |
| HOTEL-03 | T+20 subscription/cohort eligibility | `RUNTIME_PENDING` | Evidence-driven Official Direct counting, Fallback exclusion, cohort derivation, policy-bound invoices, maker-checker waivers and hash-chained audit implemented; runtime regression pending |
| OFFER-01 | Structured Requirement Builder | `RUNTIME_PENDING` | Backend and Consumer builder complete; runtime/API/TSX regression pending |
| OFFER-02 | Dedicated-supply system quote vs manual quote | `RUNTIME_PENDING` | Supplier/Admin UI and dedicated-authority lifecycle implemented; runtime/audit regression pending |
| OFFER-03 | Quote select → prebook → booking handoff | `RUNTIME_PENDING` | Expiry, idempotent revalidation, supplier decision and checkout handoff implemented; runtime/end-to-end regression pending |
| AIR-01 | Official check-in and boarding-pass fact lifecycle | `RUNTIME_PENDING` | Runtime tests plus production adapter contract; external source Phase 2 |
| MOB-01 | Flight-aware airport transfer synchronization | `RUNTIME_PENDING` | Runtime tests plus fleet callback/reconciliation contract; external Phase 2 |
| PAY-01 | Omnichannel payment, ledger and reconciliation OS | `RUNTIME_PENDING` | Unified authorization/capture/refund/compensation/payout, ledger, close and four-surface contracts implemented; runtime E2E and real channel Sandbox pending |
| SUP-01 | Supplier Console property/room/content/ARI/policy operations | `RUNTIME_PENDING` | Six-vertical capability authority, contract certification and Supplier UI implemented; full runtime/UI tests pending |
| ADM-01 | GO Admin governance, maker-checker and exception operations | `RUNTIME_PENDING` | Identity/Offer/payment/finance/closure dashboards and control contracts implemented; end-to-end runtime pending |
| OPS-01 | Autonomous operations and deterministic action boundaries | `RUNTIME_PENDING` | Recovery/exception/reconciliation boundaries and evidence policy implemented; closed-loop runtime pending |
| SEC-01 | RBAC/MFA/SSO/secrets/privacy/observability/DR | `RUNTIME_PENDING` | Threat model, RBAC/MFA, external secret references and audit boundaries documented/implemented; formal security runtime pending |
| UI-01 | Brand IA, dual microphone roles, no second-page Offer mic | `RUNTIME_PENDING` | Four-surface state/accessibility contract and core UI paths implemented; device/visual/accessibility execution pending |
| QA-01 | Fresh migration, runtime OpenAPI, Python/TS/TSX and regressions | `RUNTIME_PENDING` | Clean dependency-complete verification artifact |
| DOC-01 | System architecture, state machines, API and operations design | `RUNTIME_PENDING` | 28-family traceability matrix, threat model, UI acceptance and build artifacts complete; trace audit pending |

## Completion calculation

Phase 1 completion is calculated by requirement evidence, not file count or route count:

`completion = DONE requirements / all applicable requirements`

`PARTIAL`, `MISSING` and `RUNTIME_PENDING` contribute zero to the final 100% gate. An `EXTERNAL_PENDING` item contributes only after its Phase 1 adapter contract and tests are independently marked `DONE`; it never implies a real external connection or Live status.

## Locked implementation sequence

1. ID-01 through ID-05 — GO Staff, Owner and Friends & Family.
2. CON-02 — remove demo/silent fallback paths.
3. OFFER-01 through OFFER-03 — complete the GO Offer lifecycle.
4. Close remaining Consumer/Supplier/Admin/finance/autonomous-operation gaps.
5. Execute QA-01 and publish the independent Phase 1 100% verification artifact.
