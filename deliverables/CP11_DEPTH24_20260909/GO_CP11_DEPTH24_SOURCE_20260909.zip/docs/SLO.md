# Sprint 1V SLO baseline

P0 SLOs are explicitly separated from commercial KPIs. Availability and transaction safety are release gates; GMV, clicks and recommendation results are not SLO inputs.

- API availability: 99.9% / rolling 30d.
- Booking workflow safe-success: 99.5% / rolling 30d.
- Payment orchestration safe terminal state: 99.9% / rolling 30d.
- Eligible refund execution success: 99.5% / rolling 30d.
- Activated connector search success: 99.0% / rolling 7d.

Error-budget burn alerts must page before the full SLO is exhausted. A release is blocked when the production readiness gate has any blocker.
