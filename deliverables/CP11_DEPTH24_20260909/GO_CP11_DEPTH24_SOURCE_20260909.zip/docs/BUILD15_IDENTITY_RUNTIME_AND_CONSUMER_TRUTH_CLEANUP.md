# Build 15 — Identity Runtime + Consumer Truth Cleanup

Date: 2026-08-18

## Identity runtime added

- Scheduled credential revalidation and expiry processing.
- Risk signals: 7000+ basis points enters REVIEW; 9000+ suspends the credential.
- Friends & Family invitation consumption, expiry and usage-limit enforcement.
- Supplier program listing and Admin credential queue APIs.
- Consumer GO Identity is now reachable directly from the Profile screen.

## Consumer production-path cleanup completed in this increment

- Home: removed hard-coded recommended Tokyo hotel and price.
- Hotel list: removed fallback hotels, dates, counts, review totals and location claims.
- Rooms: removed demo offers and fake prebook success.
- Trips: removed the visual Tokyo/Kyoto journey.
- Order detail: removed visual order, payment, timeline, price and hotel facts.
- Wallet: removed test PAN defaults and fake Visa token.
- Stay Credit: removed fake quote amount and expiry.
- All rewritten pages now distinguish loading, empty and error states; supplier/API failure no longer becomes success.

## Verification

- Python compileall: PASS.
- Identity static contract assertions from Build 14 remain PASS.
- Formal TS/TSX parse/type-check: BLOCKED because the workspace runtime does not contain the TypeScript compiler or project dependencies.
- Runtime pytest/Alembic: still pending in the dependency-complete environment.

## Remaining Consumer cleanup

The audit still identifies visual/demo paths in Journey Recovery, Journey Detail, notifications, hotel detail, booking review/success/payment, cancel/change, and quick review. `CON-02` therefore remains `PARTIAL`; this increment does not claim full Consumer truth closure.
