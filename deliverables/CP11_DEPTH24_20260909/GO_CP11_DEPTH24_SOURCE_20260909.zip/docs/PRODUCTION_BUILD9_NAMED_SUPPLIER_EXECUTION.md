# Production Build 9｜Named Supplier Adapter + External Sandbox Execution Gate

Build 9 建立具名 Hotel 与 PSP Adapter Definition、配置绑定、Maker-Checker 执行授权、外部执行尝试、Transport Evidence 与执行决策。当前未收到真实供应商资料，外部 Executor 保持未配置，任何执行尝试均以 `BLOCKED / EXTERNAL_CONNECTOR_EXECUTOR_NOT_CONFIGURED` 收敛，且不能生成外部 Transport Evidence。

DB head 为 `0080_named_supplier_external_sandbox_execution`，父版本为 0079；新增 6 张表和 9 条 GO Admin API。Hotel Adapter 强制包含 BOOK/QUERY/CANCEL/WEBHOOK，PSP Adapter 强制包含 AUTHORIZE/CAPTURE/REFUND/SETTLEMENT/CALLBACK。Supplier 名称必须匹配 Intake，Endpoint、Vault Binding、Allowlist 和测试资源必须来自已批准 Intake。

只有 Implementation Verified + Configuration Attested 的成对 Binding 才可进入 Maker-Checker；审批仍只授权 External Sandbox，不授权 Production。没有真实 Transport 时，最终决策只能是 `NOT_EXTERNALLY_VERIFIED`，系统始终返回 `real_supplier_connected=false`、`production_live=false`。

验收：Build 9 专项 7/7、Build 4–9 联合 41/41、Build 1–3 回归 19/19；Fresh DB 380 张表、新表 6/6；OpenAPI 7.1.0 共 576 paths、新增 9 paths；439 个 Python AST、13 个 Web JS parse PASS。

