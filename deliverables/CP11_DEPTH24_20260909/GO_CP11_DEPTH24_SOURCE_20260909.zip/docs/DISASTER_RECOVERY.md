# Disaster Recovery baseline

Target baseline: RPO <= 5 minutes for transactional PostgreSQL data, RTO <= 60 minutes for hotel booking/control plane. Use encrypted PITR-capable PostgreSQL backups, separate-region object storage for immutable backup artifacts, restore verification at least monthly, and quarterly full failover drills.

Recovery order: Identity/authorization -> database -> payment reconciliation -> order ledger/workflows -> connector status/reconciliation -> Supplier Console/GO Admin -> analytics/non-critical projections. Never replay an ambiguous supplier book or payment capture without reconciliation/idempotency checks.
