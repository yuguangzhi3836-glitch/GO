# Production Build 8｜External Supplier Sandbox Certification Workbench

## 交付结论

Build 8 建立供应商资料 Intake、Vault/KMS Reference、外部 Sandbox 认证套件、执行边界、证据导入、回调证明与认证决策工作台。当前没有收到具名供应商的合同、账号、端点和密钥，因此只完成可验证的 `FRAMEWORK_DRY_RUN`，没有执行或宣称真实外部 Sandbox 连接。

## 核心能力

- DB head：`0079_external_supplier_sandbox_certification`，父版本为 `0078_first_connector_pilot_integration`。
- 七个持久化对象：Supplier Intake、Credential Binding、Certification Suite、Certification Run、Evidence Import、Callback Proof、Certification Decision。
- 输入门禁覆盖 Hotel/PSP 名称、合同、Authority、双方 Sandbox Endpoint、IP Allowlist、测试酒店/账号和认证窗口。
- Credential 只接受外部 Vault/KMS Reference，不接收明文 password/token/secret。
- 双连接器 Vault Access Test 均通过后，Intake 才能进入 `READY_FOR_EXTERNAL_EXECUTION`。
- 外部执行必须位于批准的认证窗口；未配置供应商专用 Executor 时返回 `EXTERNAL_CONNECTOR_EXECUTOR_NOT_CONFIGURED`。
- Dry Run 不能导入“已认证外部证据”，最终决策固定为 `FRAMEWORK_VALIDATED_NOT_EXTERNAL_CERTIFIED`。
- 回调证明要求签名验证并按 Delivery ID 防重放。

## 生产诚实边界

当前 `external_executor_configured=false`、`real_supplier_connected=false`、`production_live=false`。只有供应商专用 Executor 实际配置、完整输入门禁通过、外部 Sandbox 真正执行、外部证据完成 Attestation，才可能形成 `EXTERNAL_SANDBOX_CERTIFIED` 决策；该决策仍不等于 Production LIVE。

## 验收摘要

- Build 8 专项：8/8 PASS。
- Build 4–8 联合：34/34 PASS。
- Build 1–3 回归：19/19 PASS。
- Fresh DB：空库升级至 0079，374 张表，Build 8 新表 7/7。
- Runtime OpenAPI：版本 7.0.0，共 567 paths，Build 8 新增 11 paths。
- 静态验证：435 个 Python 文件 AST、12 个 Web JavaScript 文件解析通过。

