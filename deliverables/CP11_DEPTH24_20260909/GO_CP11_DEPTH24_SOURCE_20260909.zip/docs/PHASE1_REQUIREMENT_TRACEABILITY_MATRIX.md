# Phase 1 Requirement Traceability Matrix

Baseline: GO Ultimate Master Plan V3.0, 2026-08-17. This matrix is the code/design closure index; runtime proof remains in QA-01.

| ID | Design and rule source | Model / migration | Service / API | Surface | Verification |
|---|---|---|---|---|---|
| GOV-01 | `phase1_closure.py` capability matrix | Existing vertical models | `/phase1-closure/capability-matrix` | Admin Closure | `test_phase1_cross_domain_closure.py` |
| GOV-02 | Direct First selector | Distribution authority | `/phase1-closure/source-selection` | Admin Closure | Direct/fallback negative tests |
| GOV-03 | Truth/Judgment/User Fit separation | Judgment runtime | Judgment APIs | Consumer/Admin | Existing governance tests |
| GOV-04 | Evidence policy | Audit/ledger/event rows | `/phase1-closure/evidence-policy` | Admin Closure | Forbidden mutation contract |
| CON-01 | GO Account/GO ID | Identity/wallet models | Consumer identity APIs | Consumer | Existing Sprint 1Y tests |
| CON-02 | Production truth states | Existing domain rows | Consumer APIs | Web/Mobile | Static forbidden-path audit + runtime pending |
| CON-03 | 11-capability state contract | 0096 unified lifecycle projection | Unified Trips + vertical APIs | Consumer | Six-vertical/stale/account tests; runtime pending |
| ID-01–05 | Build 14–16 identity rules | 0090 | GO identity APIs | Consumer/Supplier/Admin | Identity verification artifacts |
| HOTEL-01 | Fare families | Fare snapshots | Fare APIs | Consumer/Supplier | Existing fare tests |
| HOTEL-02 | Fault/compensation | Liability/protection ledger | Compensation APIs | Consumer/Supplier/Admin | Build 18 artifact |
| HOTEL-03 | T20/Cohort/Billing | 0092 | Commercial APIs | Supplier/Admin/Finance | Build 19 artifact |
| OFFER-01–03 | Requirement→Handoff | 0089/0091 | GO Offer APIs | Consumer/Supplier/Admin | Build 17 artifact |
| AIR-01 | Official check-in facts | 0089 | Flight APIs | Consumer/Admin | P0 artifact |
| MOB-01 | Flight-aware ride sync | 0089 | Mobility APIs | Consumer/Supplier/Admin | P0 artifact |
| PAY-01 | Omnichannel money lifecycle | 0093/0094 | Payment/Finance APIs | Four surfaces | Builds 20–23 artifacts |
| SUP-01 | Supplier operating contract | 0095 capability/certification | Supplier vertical APIs | Supplier/Admin | Authority/certification tests; runtime pending |
| ADM-01 | Governance/exception control | Approval/audit rows | Internal APIs | Admin | Runtime E2E pending |
| OPS-01 | Deterministic action boundaries | Cases/events/reconciliation | Ops/recovery APIs | Admin | Runbook and runtime pending |
| SEC-01 | Security architecture | Identity/audit/key refs | Auth/governance APIs | All | Threat model and runtime pending |
| UI-01 | Four-surface IA/state contract | N/A | BFF/API contracts | All | Accessibility/visual runtime pending |
| QA-01 | Verification plan | Alembic 0094 | Runtime OpenAPI | CI | Dependency-complete run pending |
| DOC-01 | This matrix + artifacts | N/A | N/A | Engineering | Trace audit |

No row may be promoted from `RUNTIME_PENDING` to `DONE` solely because it appears in this matrix.
