# Build 23 — Unified Money Movement + Financial Close

Runtime 8.6.0; DB head 0094. Authorization, capture, refund, compensation, payout and release share a root payment intent, idempotent movement ledger and evidence. Capture requires authorization; total refund/compensation cannot exceed capture. Daily close requires balanced debit/credit, no unresolved external movement and matched reconciliation, followed by maker-checker approval. External money movement remains disabled pending Phase 2 channel Sandbox and certification.
