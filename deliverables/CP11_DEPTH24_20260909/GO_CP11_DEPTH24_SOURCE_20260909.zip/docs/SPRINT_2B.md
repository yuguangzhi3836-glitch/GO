# Sprint 2B — Real Device QA + Network Recovery + Push Receipts + Store Release Build

Sprint 2B hardens Sprint 2A for installable pre-release distribution. It does **not** claim a TestFlight or Google Play build was uploaded in this execution environment because Apple/Google/EAS credentials and native SDK runners are not available here.

Implemented:
- connectivity-aware native API client and visible offline state;
- financial-command rule: no blind offline replay;
- mutation idempotency keys;
- push provider receipt persistence and lifecycle worker;
- dead push-token revocation;
- Staging mobile-push + push-receipt workers;
- EAS development/preview/production build profiles;
- GitHub Actions release workflow;
- real-device QA matrix and store release checklist.
