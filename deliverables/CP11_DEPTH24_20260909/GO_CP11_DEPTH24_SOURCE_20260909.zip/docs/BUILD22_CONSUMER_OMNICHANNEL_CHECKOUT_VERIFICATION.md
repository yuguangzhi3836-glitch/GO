# Build 22 — Consumer Omnichannel Checkout Integration

Runtime 8.5.0, DB head 0093. Consumer hotel checkout now uses the shared Payment Intent and explicit channel-selection contract. Hard-coded test-card collection and the legacy single-channel checkout call are removed from the production UI. Missing certified channel bindings/executors fail visibly with payment_completed=false and booking_confirmed=false. Runtime pytest, browser E2E, external SDK/redirect/callback and Sandbox certification remain pending.
