# Mother Plan Production Build 5 — Connector Runtime Enforcement

Database head: `0076_production_connector_runtime` (parent `0075_production_connector_live_gate`).

Every supplier mutation is denied unless the connector is formally `LIVE`, in `PRODUCTION`, healthy within the runtime freshness window, covered by active operation authority and backed by an active external credential reference. Runtime operations require stable idempotency keys; key reuse with a changed payload is rejected.

Webhook payloads are verified with an externally resolved HMAC secret, recorded by delivery ID and rejected on replay. The secret itself is never persisted. Poll and webhook observations converge only on supplier evidence. `UNKNOWN_EXTERNAL_STATE` never grants permission to resend a mutation; exhausted reconciliation enters durable manual review. Repeated invalid signatures engage the connector kill switch and suspend the connector.

This build supplies the shared production runtime enforcement plane. It does not claim any supplier is connected, certified or LIVE without real contract, account, credentials and certification evidence.
