# GO R8.1 Codex Staging Handoff

## Scope

R8.1 is a control-debt-cleanup release on top of the V6.1 control baseline. It does not redefine product strategy or database history.

## Staging target

- Public base: `https://staging-api.goaidirect.com`
- Consumer: `/go-app/`
- Supplier: `/supplier-console/`
- Admin: `/go-admin/`
- Database: existing private RDS PostgreSQL; do not expose it publicly.

## Important deployment truths

- Do not delete, rename, or rewrite an Alembic revision that has already been applied to RDS.
- New Alembic revision IDs must be <=32 characters.
- New explicit PostgreSQL object names must be <=63 bytes.
- Docker image now explicitly includes `frontend/`.
- Workbench-safe scripts use POSIX `/bin/sh`; do not assume `pipefail` or `unzip`.
- Do not place real secrets, passwords, connection strings, or MFA seeds in code, frontend files, logs, or handoff text.
- A 200 `/health` response does not prove any web UI is deployed correctly.

## Pre-deploy package gate

```sh
./scripts/release_gate_r81.sh
```

Expected:

```text
R8.1 RELEASE GATE: PASS
```

No new R8.1 database migration is introduced by this release. Existing migration history must remain intact.

## Deploy / rebuild

Use the existing R7/RDS deployment procedure, replacing only the application package/image with R8.1. Do not invent credentials or modify identity rules.

After rebuild, independently verify container health and migration logs. Incomplete Compose stdout is not evidence of success.

## HTTP/static verification

```sh
BASE_URL=https://staging-api.goaidirect.com ./scripts/r81_staging_verify.sh
```

This is intentionally POSIX-compatible. It does not substitute for browser testing.

## Mandatory real-browser acceptance

Open each page in a real browser and inspect both rendered UI and developer-console errors:

1. `/go-app/`
   - page renders, not blank;
   - consumer registration/login remains self-service;
   - hotel flow includes search -> hotel list -> hotel detail/room offers -> same-room comparison -> prebook/order review -> payment readiness;
   - no GO Trips success state before payment/confirmation;
   - cancellation/refund and review entry points remain visible after eligible lifecycle states.

2. `/supplier-console/`
   - password login works with the existing Staging supplier test account;
   - command center, product graph, operating snapshot, orders, reviews/truth, GO rating/recommendation, T20, finance and connectors render;
   - browser console has no syntax/runtime blank-screen error.

3. `/go-admin/`
   - do **not** claim username/password login is generally usable for a first-time admin account;
   - backend MFA enforcement remains intact;
   - R8.1 does not deliver first-time MFA enrollment UI;
   - if an already-enrolled admin or configured SSO is available, verify R8.1 Staging Readiness, six vertical operations, Supplier Registry, GO Recommendation, GO Reviews, GO Truth, GO Star, GO Trips, payment/refund and release governance surfaces;
   - browser console has no syntax/runtime blank-screen error.

## R8.1 product/runtime changes to verify

- Day-1 hotel coverage policy is encoded as multi-OTA/official discovery -> Canonical Hotel -> multi-source merge -> media harvest/room binding -> authorized fallback -> page live -> hotel registration + official association -> GO Direct upgrade.
- Fallback priority is GO Direct -> third-party API fallback -> deep-link fallback.
- GO has no call center/traditional consumer after-sales model; GO Trips self-service and API automation are the default, with exception-only internal intervention.
- Media Rights Gate supports `DISTRIBUTION_LICENSE` only with explicit provider, contract ID, evidence and cache permission.
- Hotel AutoPage accepts OTA discovery/distribution source types but does not make unlicensed media publishable.

## Report back

Return exact evidence, not conclusions only:

- deployed image/package identifier;
- Alembic current revision before/after;
- migration log excerpt;
- container health/status;
- HTTPS status for health and all three UI entries;
- screenshots or browser observations for all three UIs;
- browser console errors, if any;
- any API/UI mismatch with exact endpoint and response code;
- rollback result if rollback was required.
