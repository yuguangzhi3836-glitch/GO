# GO R8.1 Control-Debt Cleanup Release

Control product version remains **V6.1**. Deployment release train is **R8.1**.

## Locked product/runtime alignment

- Day 1 hotel coverage: multi-OTA/official discovery -> Canonical Hotel -> multi-source merge -> media harvest + room binding -> authorized fallback inventory -> page live -> hotel registration + official association -> official content / GO Direct upgrade.
- Inventory priority: GO Direct -> Third-party API Fallback -> Deep-Link Fallback.
- GO remains the page owner. Provider/content/inventory/fulfillment legal truth is retained separately.
- No GO call center and no traditional consumer after-sales team. GO Trips self-service + API automation + exception-only internal intervention.
- Media Rights Gate now supports `DISTRIBUTION_LICENSE` only with explicit provider, contract ID, evidence, and cache permission.
- Admin MFA truth is not overstated: backend enforcement exists; first-enrollment UI is not delivered in R8.

## Staging alignment

- Docker image explicitly copies `frontend/`, so `/go-app/`, `/supplier-console/`, and `/go-admin/` can exist in the container.
- Alembic revision IDs are statically gated to <=32 characters.
- Explicit PostgreSQL migration object names are gated to <=63 bytes.
- `scripts/r81_staging_verify.sh` is POSIX `/bin/sh` compatible and does not use `pipefail` or `unzip`.
- HTTP health is insufficient: real browser render and console inspection remain mandatory external acceptance evidence.

## Consumer web alignment

- Hotel selection now passes through an explicit same-room comparison screen before Prebook.
- Prebook, order, payment, confirmation, GO Trips, cancellation/refund and review remain separate lifecycle states.

## Production truth

R8.1 code/gates do not claim External Sandbox, Canary, or Live status. Those require Codex/Staging evidence and real provider/PSP evidence.

## R8.1 control-debt closure

- V6.1 is the only current control authority. Historical V5.4/V3.0 precedence text in the bundled master is explicitly marked superseded and cannot override V6.1.
- Hotel lifecycle wording is `page live -> hotel registration + official association -> official content / GO Direct upgrade`; retired claim-language is not an active product state.
- Subscription invoice generation is fail-closed: an ACTIVE `T20_SUBSCRIPTION` policy must explicitly contain `amount_minor`; no implicit historical 599-price fallback exists.
- `scripts/r81_control_debt_gate.py` and `scripts/r81_commercial_fail_closed_gate.py` are mandatory R8.1 local release gates.
