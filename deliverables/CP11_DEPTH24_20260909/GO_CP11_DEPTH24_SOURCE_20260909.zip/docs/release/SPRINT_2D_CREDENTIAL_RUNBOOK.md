# Sprint 2D Credential Runbook

## Apple / EAS
Create or connect the EAS project, Apple Developer team, App Store Connect app and automation identity. Store credentials outside Git. Configure `ASC_APP_ID` in `eas.json`/CI at release time rather than committing real IDs if policy requires it.

## Google Play
Create the Play Console app/package, configure Play App Signing, create the release automation service account and keep its JSON in secret storage. Production Android submission must be an AAB.

## Push
Certify APNs and FCM on physical devices. A successful provider submission is not enough: retain provider receipt/message ID and device-open evidence for the gate.

## Domain links
Serve association files over HTTPS from `GO_APP_DOMAIN` with HTTP 200 and valid JSON. Validate on a physical iPhone/Android device from a cold app state.

## PSP / connector
Run real sandbox authorization→book→capture and cancel/refund/change scenarios. Never mark PSP or connector PASS using only a health endpoint.

## Database / queue
Run Alembic from empty PostgreSQL 16, concurrency tests, Redis/outbox/push-worker smoke, and restart/recovery drills.
