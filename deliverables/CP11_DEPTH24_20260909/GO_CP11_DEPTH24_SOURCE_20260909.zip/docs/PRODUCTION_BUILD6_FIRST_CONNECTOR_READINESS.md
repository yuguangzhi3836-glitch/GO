# Mother Plan Production Build 6 — First Real Connector Activation Readiness

Database head: `0077_first_connector_activation_readiness` (parent `0076_production_connector_runtime`).

The control plane now captures the first-supplier onboarding materials, verified production account and authority, external Vault/KMS bindings, production IP allowlists, HTTPS webhook endpoint and signing-key rotation lifecycle, sandbox/production certification evidence, smoke/canary/rollback drills, and settlement/refund/reconciliation closure.

The highest successful result is `READY_FOR_EXTERNAL_ACTIVATION`. It deliberately does not set the connector to `LIVE`. Real supplier contract, account, credentials, endpoints, allowlisting and supplier-side certification remain external prerequisites.

## Next build

Production Build 7 should execute the first paired pilot integration: one Hotel PMS/CRS/Channel Manager connector plus one PSP connector. It requires named suppliers, signed authority, sandbox/production endpoints, external KMS references, allowlist confirmation, supplier test accounts/properties and certification windows. Without these inputs, only engineering fixtures may run and no LIVE claim is permitted.
