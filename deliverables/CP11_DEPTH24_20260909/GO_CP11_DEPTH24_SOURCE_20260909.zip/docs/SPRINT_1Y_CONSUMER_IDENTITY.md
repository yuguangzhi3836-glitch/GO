# Sprint 1Y — Consumer Identity + GO ID + Wallet/Payment Tokenization

## Production contract

- Consumer registration creates an `IdentityUser` with `actor_type=CONSUMER` plus a globally unique `GO ID` profile.
- Browser sessions use separate Secure/HttpOnly consumer access + rotating refresh cookies. JavaScript receives no JWT or refresh token.
- Unsafe cookie-authenticated requests require the session-bound CSRF token.
- Orders created by the Consumer App derive `account_id` from the authenticated principal. The frontend cannot select another account.
- Traveler identity documents are encrypted at rest and only masked values are returned.
- Payment cards are tokenized through the PSP boundary. GO persists only provider token ciphertext, fingerprint, brand, last4 and expiry metadata. PAN/CVC are never persisted or returned.
- `GO Wallet` in Sprint 1Y is a payment-reference wallet, not a stored-value account. Hotel `Stay Credit` remains property-scoped and is not converted into general GO balance.
- Consumer order/review endpoints enforce ownership against the authenticated GO ID.

## Real-provider boundary

`MOCK_PSP_TOKENIZATION` is a contract simulator. Production requires a PCI-compliant PSP hosted fields/native SDK/tokenization endpoint; raw PAN/CVC must bypass GO application servers where the provider supports it. Provider webhooks and payment method lifecycle events must be verified and reconciled.
