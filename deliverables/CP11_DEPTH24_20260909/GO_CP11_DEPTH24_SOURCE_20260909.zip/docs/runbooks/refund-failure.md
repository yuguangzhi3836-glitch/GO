# Runbook: refund-failure

1. Declare incident severity and incident commander. 2. Inspect trace/request IDs, structured logs, SLO burn and exception queue. 3. If user harm can grow, activate the narrowest applicable kill switch; GLOBAL_WRITES is last resort. 4. Reconcile external payment/connector state before retrying ambiguous writes. 5. Record every controlled action in Audit Trail. 6. Restore service, deactivate switch, verify SLO recovery, and complete post-incident review with evidence links.
