# Production Build 7｜First Paired Connector Pilot Integration

## 交付结论

Build 7 建立了一个 Hotel PMS/CRS/Channel Manager 与一个 PSP 的成对 Pilot 执行框架。当前仅允许 `SANDBOX_ONLY`；在正式合同、Authority、供应商 Endpoint、Vault/KMS Reference、IP Allowlist、测试酒店/账号与认证窗口未提供前，系统硬阻断外部 Pilot，并始终返回 `real_supplier_connected=false`、`production_live=false`。

## 核心实现

- DB head：`0078_first_connector_pilot_integration`，父版本为 `0077_first_connector_activation_readiness`。
- 八个持久化对象：Pilot Pair、Scenario、Execution、Operation、Callback、Evidence、Reconciliation、Control。
- Hotel Sandbox Adapter：Book、Query、Cancel。
- PSP Sandbox Adapter：Authorize、Capture、Refund、Settlement Query。
- 订单、取消、退款、查询的确定性 Sandbox 闭环。
- Supplier Webhook / Payment Callback：签名通过门禁、Delivery ID 防重放、证据入链。
- Hotel Order、Payment、Refund、Settlement 联合 Reconciliation。
- Smoke + Rollback 双门禁、Canary Limit、Kill Switch。
- GO Admin Pilot Command Center、Evidence/Reconciliation、Canary/Kill Switch 控制面。

## 生产诚实边界

本 Build 的 Adapter 是可验证的供应商专用接口形状与 Sandbox 执行器，不代表供应商认证，更不代表生产连接。`EXTERNAL_SANDBOX` 或生产模式在缺少外部资料时返回 `REAL_EXTERNAL_PILOT_INPUTS_REQUIRED`。任何真实连接及 LIVE 状态仍须由外部合同、账号、密钥、网络、认证证据和审批共同证明。

## 验收摘要

- Build 7 专项：7/7 PASS。
- Build 4–7 联合：26/26 PASS。
- Build 1–3 回归：19/19 PASS。
- Fresh DB：空库升级至 `0078_first_connector_pilot_integration`，367 张表，Build 7 新表 8/8。
- Runtime OpenAPI：版本 6.9.0，共 556 paths，Build 7 为 9 paths。
- 静态验证：411 个 Python 文件 AST、11 个 Web JavaScript 文件解析通过。

