# Phase 1 Security Threat Model

Trust boundaries: Consumer device, Supplier Console, GO Admin/Finance, API runtime, database, secret manager, payment/supplier adapters and webhook ingress.

Mandatory controls: tenant ownership checks; least-privilege RBAC; MFA for high-risk admin/finance actions; maker-checker for policy, waiver and close; idempotency for every mutation; signed callback plus replay protection; external keys referenced through KMS/Vault only; immutable audit/ledger evidence; PII minimization; rate limiting; explicit unknown external state; reconciliation before resend; backup/restore and incident evidence.

Hard failures: cross-account intent access, unsigned callback, duplicate external event, plaintext secret, timeout resend, silent channel/source fallback, admin recommendation purchase, refund above capture, unbalanced finance close and mock external success.

Production gates still required: formal SSO/IdP certification, penetration test, dependency/SBOM scan, PostgreSQL tenant-isolation tests, key rotation drill, backup restore drill, WAF/TLS validation and privacy/legal review.
