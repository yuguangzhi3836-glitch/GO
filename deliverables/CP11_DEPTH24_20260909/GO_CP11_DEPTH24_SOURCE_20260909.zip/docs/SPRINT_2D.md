# Sprint 2D — Credential & Real Environment Bring-up

Sprint 2D is a release-execution sprint, not a feature sprint. It converts Sprint 2C's certification matrix into secret-backed, evidence-backed real-environment gates.

## Hard rule
No gate may become PASS from an environment flag alone. PASS requires a non-secret evidence artifact whose SHA-256 is recorded in `staging/certification/status.sprint2d.json`.

## Bring-up order
1. Secret manager / CI environments.
2. Real PostgreSQL 16 and Redis.
3. PSP sandbox and contracted hotel connector sandbox.
4. Expo/EAS project plus Apple and Google signing identities.
5. APNs / FCM credentials and real device push receipts.
6. `apple-app-site-association` and `assetlinks.json` on the real GO app domain.
7. EAS production builds.
8. TestFlight and Play Internal submissions and installs.
9. Physical iPhone and Android P0 E2E matrix.
10. Store submission checklist.

## Deliberate non-assumptions
The repository does not invent private PSP or hotel-connector API fields. Their concrete sandbox transactions must be implemented/certified against the chosen provider's contracted documentation and credentials.

## Secret handling
Use GitHub Environments, cloud secret manager, EAS credential store, or equivalent. Never commit `.p8`, service-account JSON, passwords, API keys, push tokens, PAN/CVC, or production database URLs.

## Evidence promotion example
`python scripts/sprint2d_gate_ledger.py --gate PG16 --pass-evidence evidence/pg16-certification.json`

The release state becomes `INSTALLABLE_INTERNAL` only when all 15 blocking gates have evidence-backed PASS status.
