# Sprint 1Z — Mobile App Shell + iOS/Android Production Client

## Scope delivered
- Expo/React Native shared iOS + Android application shell.
- Native bearer session endpoints separate from browser cookie/BFF sessions.
- Access and rotating refresh tokens intended for OS-backed SecureStore only.
- APNs/FCM native device token registration; tokens are encrypted at rest and never returned by read APIs.
- Notification inbox persistence and read state.
- Deep-link allowlist: order detail, quick review, wallet, home.
- iOS custom scheme + Associated Domains placeholder; Android App Links + custom scheme placeholder.
- GO Trips, order detail, Quick Review, Wallet and profile client screens.
- Migration `0019_sprint1z`.

## Security invariants
1. Native app MUST NOT use localStorage/AsyncStorage for auth tokens.
2. Server-side APNs/FCM credentials MUST NOT be compiled into the mobile app.
3. Deep links are typed internal navigation intents, never arbitrary redirect URLs.
4. Device registration is authenticated and user-scoped.
5. Payment card PAN/CVC remains outside GO generic state; production uses a PCI-compliant PSP SDK/tokenization surface.
6. Stay Credit remains property-only and is not a GO Wallet stored-value balance.

## Production gates not claimed in this build environment
- Apple Developer signing/provisioning and App Store Connect upload.
- Google Play signing/Play Console upload.
- AASA and assetlinks.json published on the final production domain.
- Real APNs/FCM provider credentials and delivery receipts.
- Real PSP native SDK.
- Physical-device push/deep-link E2E and store review.
