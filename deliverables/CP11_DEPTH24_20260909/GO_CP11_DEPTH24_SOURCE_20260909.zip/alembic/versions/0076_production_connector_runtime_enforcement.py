"""Production connector runtime enforcement, webhook and reconciliation."""
from alembic import op
from go_hotel.db.models import Base
revision='0076_126e14322d21'
down_revision='0075_442bc0d513d1'
branch_labels=None
depends_on=None
TABLES=['connector_runtime_authorization','connector_runtime_operation','connector_webhook_receipt','connector_runtime_observation','connector_runtime_reconciliation','connector_runtime_safety_event']
def upgrade():
 bind=op.get_bind()
 for name in TABLES: Base.metadata.tables[name].create(bind,checkfirst=True)
def downgrade():
 bind=op.get_bind()
 for name in reversed(TABLES): Base.metadata.tables[name].drop(bind,checkfirst=True)
