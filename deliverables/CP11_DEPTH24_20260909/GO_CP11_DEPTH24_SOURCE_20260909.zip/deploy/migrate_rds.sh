#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
ENV_FILE=${ENV_FILE:-deploy/.env.hk-staging}
COMPOSE_FILE=${COMPOSE_FILE:-deploy/docker-compose.hk-staging.yml}
EVIDENCE_DIR=${EVIDENCE_DIR:-deploy/evidence}
mkdir -p "$EVIDENCE_DIR"
TS=$(date -u +%Y%m%dT%H%M%SZ)
LOG="$EVIDENCE_DIR/${TS}_migration.log"

# Hard stop: never migrate unless lineage and naming constraints pass first.
sh deploy/static_preflight.sh
sh deploy/db_readonly_preflight.sh
sh deploy/backup_rds.sh

python3 scripts/r82_no_stamp_gate.py

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" --profile migration run --rm migrate > "$LOG" 2>&1
cat "$LOG"

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm --no-deps api alembic current -v

echo "R8.2_MIGRATION: PASS"
