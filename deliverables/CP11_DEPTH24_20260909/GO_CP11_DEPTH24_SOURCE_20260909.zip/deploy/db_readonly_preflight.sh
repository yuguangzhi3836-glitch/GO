#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
ENV_FILE=${ENV_FILE:-deploy/.env.hk-staging}
COMPOSE_FILE=${COMPOSE_FILE:-deploy/docker-compose.hk-staging.yml}
EVIDENCE_DIR=${EVIDENCE_DIR:-deploy/evidence}
mkdir -p "$EVIDENCE_DIR"
TS=$(date -u +%Y%m%dT%H%M%SZ)
LOG="$EVIDENCE_DIR/${TS}_db_readonly_preflight.log"

test -f "$ENV_FILE" || { echo "missing $ENV_FILE"; exit 1; }

# Build is non-mutating and gives a known Alembic/Python runtime for the read-only checks.
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" build api
{
  echo "=== alembic heads ==="
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm --no-deps api alembic heads
  echo "=== alembic current ==="
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm --no-deps api alembic current -v
  echo "=== alembic history ==="
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm --no-deps api alembic history --verbose
  echo "=== direct alembic_version read ==="
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm --no-deps api python scripts/r82_rds_lineage_probe.py
} > "$LOG" 2>&1
cat "$LOG"

echo "R8.2_DB_READONLY_PREFLIGHT: PASS"
