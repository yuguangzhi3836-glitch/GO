const { chromium } = require('playwright');

(async () => {
  const base = process.env.PUBLIC_BASE_URL || 'https://staging-api.goaidirect.com';
  const paths = ['/go-app/', '/supplier-console/', '/go-admin/'];
  const browser = await chromium.launch({headless: true});
  let failed = false;
  for (const path of paths) {
    const page = await browser.newPage();
    const consoleErrors = [];
    const pageErrors = [];
    page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text()); });
    page.on('pageerror', err => pageErrors.push(String(err)));
    const response = await page.goto(base + path, {waitUntil: 'networkidle', timeout: 45000});
    const title = await page.title();
    const bodyText = (await page.locator('body').innerText()).trim();
    const loginVisible = (path === '/supplier-console/' || path === '/go-admin/') ? (await page.locator('form#login').count()) === 1 : true;
    console.log(JSON.stringify({path, status: response && response.status(), title, bodyLength: bodyText.length, loginVisible, consoleErrors, pageErrors}));
    if (!response || response.status() >= 400 || bodyText.length < 20 || !loginVisible || consoleErrors.length || pageErrors.length) failed = true;
    await page.close();
  }
  await browser.close();
  if (failed) process.exit(1);
})().catch(err => { console.error(err); process.exit(1); });
