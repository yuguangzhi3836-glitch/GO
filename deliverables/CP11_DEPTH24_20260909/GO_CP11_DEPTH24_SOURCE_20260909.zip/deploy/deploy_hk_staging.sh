#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
# Python zipfile extraction does not preserve POSIX executable bits. Restore all
# packaged shell helpers before any gate or deployment step. Gate scripts also
# use explicit `sh` invocation, so read-only/preflight execution does not depend
# on the archive executable bit being preserved.
chmod 0755 deploy/*.sh scripts/*.sh
ENV_FILE=${ENV_FILE:-deploy/.env.hk-staging}
COMPOSE_FILE=${COMPOSE_FILE:-deploy/docker-compose.hk-staging.yml}
EVIDENCE_DIR=${EVIDENCE_DIR:-deploy/evidence}
mkdir -p "$EVIDENCE_DIR"
TS=$(date -u +%Y%m%dT%H%M%SZ)
LOG="$EVIDENCE_DIR/${TS}_deploy.log"

run_all() {
  echo "[1/8] static preflight"
  sh deploy/static_preflight.sh
  echo "[2/8] image build + read-only DB lineage preflight"
  sh deploy/db_readonly_preflight.sh
  echo "[3/8] RDS backup"
  sh deploy/backup_rds.sh
  echo "[4/8] migration"
  # migrate_rds repeats all safety checks by design before the mutating step.
  sh deploy/migrate_rds.sh
  echo "[5/8] build/up runtime"
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" build api outbox-worker recovery-worker reconciliation-worker judgment-worker mobile-engagement-worker
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d redis api outbox-worker recovery-worker reconciliation-worker judgment-worker mobile-engagement-worker
  echo "[6/8] container health/status"
  docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" ps
  i=0
  while [ "$i" -lt 30 ]; do
    if curl -fsS http://127.0.0.1:8000/health >/dev/null 2>&1; then break; fi
    i=$((i+1)); sleep 2
  done
  curl -fsS http://127.0.0.1:8000/health
  echo "[7/8] HTTPS verification"
  sh deploy/https_verify.sh
  echo "[8/8] real browser render + console verification"
  sh deploy/browser_verify.sh
  echo "R8.2_HK_STAGING_DEPLOYMENT: PASS"
}

run_all > "$LOG" 2>&1 || { cat "$LOG"; echo "R8.2_HK_STAGING_DEPLOYMENT: FAIL"; exit 1; }
cat "$LOG"
