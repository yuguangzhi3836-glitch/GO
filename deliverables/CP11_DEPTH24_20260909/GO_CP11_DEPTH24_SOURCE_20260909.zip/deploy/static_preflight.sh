#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
PYTHON=${PYTHON:-python3}

echo "[R8.2] repository/static preflight"
test -f Dockerfile
test -f alembic.ini
test -f frontend/consumer/index.html
test -f frontend/supplier/index.html
test -f frontend/admin/index.html
grep -q 'COPY frontend ./frontend' Dockerfile
$PYTHON scripts/r82_migration_lineage_gate.py

echo "R8.2_STATIC_PREFLIGHT: PASS"
