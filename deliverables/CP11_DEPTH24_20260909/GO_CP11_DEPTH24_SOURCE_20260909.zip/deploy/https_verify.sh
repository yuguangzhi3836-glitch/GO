#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
ENV_FILE=${ENV_FILE:-deploy/.env.hk-staging}
set -a
. "$ENV_FILE"
set +a
BASE=${PUBLIC_BASE_URL:-https://staging-api.goaidirect.com}
for path in /health /go-app/ /supplier-console/ /go-admin/; do
  code=$(curl -L -sS -o /dev/null -w '%{http_code}' "$BASE$path")
  echo "$path -> $code"
  case "$code" in 200) ;; *) echo "R8.2_HTTPS_FAILED:$path:$code"; exit 1;; esac
done
echo "R8.2_HTTPS: PASS"
