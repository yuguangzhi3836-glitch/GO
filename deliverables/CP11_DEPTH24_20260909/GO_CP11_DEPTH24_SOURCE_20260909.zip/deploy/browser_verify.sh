#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
ENV_FILE=${ENV_FILE:-deploy/.env.hk-staging}
EVIDENCE_DIR=${EVIDENCE_DIR:-deploy/evidence}
mkdir -p "$EVIDENCE_DIR"
set -a
. "$ENV_FILE"
set +a
PUBLIC_BASE_URL=${PUBLIC_BASE_URL:-https://staging-api.goaidirect.com}
TS=$(date -u +%Y%m%dT%H%M%SZ)
LOG="$EVIDENCE_DIR/${TS}_browser.log"

# Mandatory real browser rendering + console/page error inspection.
docker run --rm --network host \
  -e PUBLIC_BASE_URL="$PUBLIC_BASE_URL" \
  -v "$ROOT/deploy:/work:ro" -w /work \
  mcr.microsoft.com/playwright:v1.55.0-noble \
  node browser_check.js > "$LOG" 2>&1
cat "$LOG"
echo "R8.2_BROWSER_RENDER_CONSOLE: PASS"
