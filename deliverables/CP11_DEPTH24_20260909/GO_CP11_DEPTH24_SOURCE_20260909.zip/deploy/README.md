# R8.2 Hong Kong Staging Deployment

This directory is part of the release artifact. It is not a pointer to an older R7 deployment folder.

Hard rules:
- RDS/applied migration lineage is authoritative.
- Never delete or renumber an applied migration.
- Never rewrite `alembic_version` and never use `alembic stamp` to hide divergence.
- Alembic revision IDs must be <= 32 characters.
- PostgreSQL object names must be <= 63 characters.
- New migrations may only descend from the real Staging RDS head.
- Database backup and read-only lineage preflight occur before mutation.
- Docker image must contain all three frontend static bundles.
- `/health`, `/go-app/`, `/supplier-console/`, `/go-admin/` must pass HTTPS checks.
- Browser rendering and browser console/page-error checks are mandatory; curl alone is not release evidence.
- Scripts are POSIX `/bin/sh`; no `pipefail`, bash arrays, or process substitution.

Execution on the ECS staging host:
1. Copy `.env.hk-staging.example` to `.env.hk-staging` and populate server-side secrets.
2. Run `./deploy/static_preflight.sh`.
3. Run `./deploy/db_readonly_preflight.sh` and archive the output.
4. Only if the code lineage exactly contains the RDS-applied lineage, run `./deploy/deploy_hk_staging.sh`.

RC03 requires the exact authoritative R7/RDS lineage to be present: 111 revisions with `0111_test_account_expiry` as the only head. The read-only preflight fails closed on any divergence and never invents, stamps, deletes, or rewrites revision history.

## R8.2 release-engineering hardening

Python `zipfile` extraction does not reliably preserve POSIX executable bits. The canonical deployment entrypoint restores them before any gate or deployment action:

```sh
chmod 0755 deploy/*.sh scripts/*.sh
```

Nested shell helpers are invoked with `sh deploy/<name>.sh` so read-only preflight does not depend on archive mode preservation.

`r8_contract_gate.py` is safe against a read-only candidate source tree: when `GO_MEDIA_CACHE_DIR` is not explicitly configured, the gate allocates and cleans a temporary writable cache outside the source tree.
