#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
ENV_FILE=${ENV_FILE:-deploy/.env.hk-staging}
BACKUP_DIR=${BACKUP_DIR:-deploy/evidence/backups}
PG_DUMP_IMAGE=${PG_DUMP_IMAGE:-postgres:18.4}
mkdir -p "$BACKUP_DIR"

test -f "$ENV_FILE" || { echo "missing $ENV_FILE"; exit 1; }
# Load only deployment-owned env file on the ECS host.
set -a
. "$ENV_FILE"
set +a

# The portable release template accepts discrete PG* variables.  The Hong Kong
# staging compose adapter deliberately stores a single SQLAlchemy URL instead;
# support both without printing either credential form.
if [ -n "${STAGING_DATABASE_URL:-}" ]; then
  DB_URL=$(printf '%s' "$STAGING_DATABASE_URL" | sed 's#^postgresql+psycopg://#postgresql://#')
  DB_LABEL=staging
else
  : "${PGHOST:?PGHOST required}"
  : "${PGPORT:?PGPORT required}"
  : "${PGDATABASE:?PGDATABASE required}"
  : "${PGUSER:?PGUSER required}"
  : "${PGPASSWORD:?PGPASSWORD required}"
  DB_URL=
  DB_LABEL=$PGDATABASE
fi
TS=$(date -u +%Y%m%dT%H%M%SZ)
OUT="$BACKUP_DIR/${DB_LABEL}_${TS}.dump"

if command -v pg_dump >/dev/null 2>&1; then
  if [ -n "$DB_URL" ]; then
    pg_dump --dbname="$DB_URL" --format=custom --no-owner --no-acl --file="$OUT"
  else
    pg_dump --format=custom --no-owner --no-acl --file="$OUT"
  fi
else
  if [ -n "$DB_URL" ]; then
    docker run --rm \
      -e DATABASE_URL="$DB_URL" \
      -v "$BACKUP_DIR:/backup" "$PG_DUMP_IMAGE" \
      sh -c 'pg_dump --dbname="$DATABASE_URL" --format=custom --no-owner --no-acl --file="/backup/$1"' sh "$(basename "$OUT")"
  else
    docker run --rm \
      -e PGHOST -e PGPORT -e PGDATABASE -e PGUSER -e PGPASSWORD \
      -v "$BACKUP_DIR:/backup" "$PG_DUMP_IMAGE" \
      pg_dump --format=custom --no-owner --no-acl --file="/backup/$(basename "$OUT")"
  fi
fi

test -s "$OUT"
sha256sum "$OUT" > "$OUT.sha256"
echo "R8.2_RDS_BACKUP: PASS $OUT"
