import React,{createContext,useContext,useEffect,useState} from 'react';
import {api,login as apiLogin} from '../api/client';
import {accessToken,clearTokens} from '../storage/secureSession';

type Auth={ready:boolean;authenticated:boolean;profile:any;login:(e:string,p:string)=>Promise<void>;logout:()=>Promise<void>;reload:()=>Promise<void>};
const C=createContext<Auth>(null as any);

export function AuthProvider({children}:{children:React.ReactNode}){
  const [ready,setReady]=useState(false);
  const [profile,setProfile]=useState<any>(null);
  const reload=async()=>{
    try{
      if(!await accessToken()){setProfile(null);return;}
      const r=await api('/v1/consumer/me');setProfile(r.data);
    }catch{setProfile(null)}finally{setReady(true)}
  };
  useEffect(()=>{reload()},[]);
  const login=async(e:string,p:string)=>{await apiLogin(e,p);await reload()};
  const logout=async()=>{try{await api('/v1/consumer/auth/logout',{method:'POST'})}catch{}await clearTokens();setProfile(null)};
  return <C.Provider value={{ready,authenticated:!!profile,profile,login,logout,reload}}>{children}</C.Provider>;
}
export const useAuth=()=>useContext(C);
