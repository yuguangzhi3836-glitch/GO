import Constants from 'expo-constants';
import {accessToken,refreshToken,saveTokens,clearTokens} from '../storage/secureSession';
import {online,idempotencyKey} from './network';
const API=String(Constants.expoConfig?.extra?.apiBaseUrl || 'http://localhost:8000').replace(/\/$/,'');
async function refresh(){
  const r=await refreshToken(); if(!r) return false;
  let res:Response; try{res=await fetch(`${API}/v1/mobile/auth/refresh`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({refresh_token:r})})}catch{return false}
  if(!res.ok){await clearTokens();return false;} const j=await res.json(); await saveTokens(j.data.access_token,j.data.refresh_token); return true;
}
export async function api(path:string,init:RequestInit={},retry=true){
  const method=String(init.method||'GET').toUpperCase();
  if(!await online()) throw new Error(method==='GET'?'NETWORK_OFFLINE':'NETWORK_OFFLINE_RETRY_REQUIRED');
  const token=await accessToken(); const headers:any={...(init.headers||{}),'Content-Type':'application/json'}; if(token) headers.Authorization=`Bearer ${token}`;
  if(method!=='GET' && !headers['Idempotency-Key']) headers['Idempotency-Key']=idempotencyKey('go');
  let res:Response; try{res=await fetch(`${API}${path}`,{...init,headers})}catch{throw new Error('NETWORK_REQUEST_FAILED')}
  if(res.status===401 && retry && await refresh()) return api(path,init,false);
  const text=await res.text(); const body=text?JSON.parse(text):{}; if(!res.ok) throw new Error(body.detail || body.error?.code || `HTTP_${res.status}`); return body;
}
export async function login(email:string,password:string){ const r=await api('/v1/mobile/auth/login',{method:'POST',body:JSON.stringify({email,password})},false); await saveTokens(r.data.access_token,r.data.refresh_token); return r.data; }
export {API};
