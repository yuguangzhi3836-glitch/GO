# GO Provider Adapter Contract v2 — Vertical-Neutral Readiness Boundary

Scope: HOTEL, FLIGHT, RAIL, RENTAL, RIDE, ATTRACTION.

This is a GO integration-readiness boundary only. It does not connect a provider and does not invent supplier endpoints, schemas, credentials, webhooks, error codes or rate limits. Supplier-specific values must come from signed/current supplier documentation.

Required controls: SANDBOX only; Vault/KMS credential references only; no inline secrets; vertical-specific operation and canonical-truth profiles; webhook replay protection; unknown supplier errors fail closed; bounded timeouts/retries; evidence/attestation; external_transport_verified=false and production_live=false by default.

A complete contract reaches only PROVIDER_CONTRACT_READY_NOT_EXTERNALLY_VERIFIED. External sandbox certification and LIVE require separate runtime evidence and gates.
