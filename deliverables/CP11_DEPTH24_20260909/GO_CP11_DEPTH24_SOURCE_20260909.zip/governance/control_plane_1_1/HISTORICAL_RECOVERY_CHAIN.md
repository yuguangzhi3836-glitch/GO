# GO Control Plane 1.1 — Historical Recovery Chain

Recovered from GO Command Center project history and reconciled against Wave07 governance sources.

## 1.0
- Scope: HK Staging only.
- Flow: submit task -> validate authority -> execute allowlisted action -> collect evidence -> report gate result.

## 1.0.1
- HK ECS did not have host `psql`.
- Read-only RDS check moved to an ephemeral `postgres:16.4` client.
- Expected behavior: read `public.alembic_version` with `transaction_read_only=on`.

## 1.0.2
- Read-only final gate historically PASS.
- Authority remained STAGING_READONLY.
- Arbitrary shell and bypass behavior remained denied/fail-closed.
- Expected RDS head: `0114_ext_truth_incident_hard`.

## 1.1
- HK Agent historically installed, loaded, inactive, disabled.
- Secure Transport was not configured.
- Missing external values at the recovery point: CONTROL_API_ENDPOINT, NODE_TOKEN, TASK_HMAC_KEY, CA_PEM.
- No secret may be embedded in this reconstructed candidate.

## Recovery limitation
The original 1.1 package bytes have not been found. This package is a reconstructed candidate, not an assertion of byte identity with the missing historical package. Final reconciliation requires read-only SHA evidence from the existing HK Agent filesystem.
