from __future__ import annotations
import hashlib, json, pathlib, py_compile, re, sys
root = pathlib.Path(__file__).resolve().parents[1]
errors=[]
required=[
 root/'contracts/control_plane_1_1_contract.json',
 root/'config/control_plane_1_1.env.example',
 root/'src/go_control_plane_1_1/core.py',
 root/'scripts/collect_hk_agent_identity.sh',
 root/'MANIFEST.json', root/'PAYLOAD_SHA256SUMS.txt', root/'README.md'
]
for p in required:
    if not p.exists(): errors.append(f'MISSING:{p.relative_to(root)}')
try:
    py_compile.compile(str(root/'src/go_control_plane_1_1/core.py'), cfile='/tmp/go_cp11_core.pyc', doraise=True)
except Exception as e:
    errors.append(f'PY_COMPILE:{e}')
contract=json.loads((root/'contracts/control_plane_1_1_contract.json').read_text())
manifest=json.loads((root/'MANIFEST.json').read_text())
if contract.get('default_authority')!='STAGING_READONLY': errors.append('AUTHORITY_NOT_READONLY')
if contract.get('fail_closed') is not True: errors.append('FAIL_CLOSED_NOT_TRUE')
if contract.get('arbitrary_shell')!='DENY': errors.append('ARBITRARY_SHELL_NOT_DENY')
if contract.get('raw_database_access')!='DENY_BY_DEFAULT': errors.append('RAW_DB_NOT_DENY_BY_DEFAULT')
if manifest.get('deployment_authorized') is not False: errors.append('DEPLOYMENT_MUST_BE_FALSE')
if manifest.get('activation_default')!='DISABLED': errors.append('ACTIVATION_NOT_DISABLED')
if manifest.get('historical_byte_identity_claimed') is not False: errors.append('BYTE_IDENTITY_MUST_NOT_BE_CLAIMED')
# No real secure-transport values embedded in the example.
for line in (root/'config/control_plane_1_1.env.example').read_text().splitlines():
    if line.startswith(('CONTROL_API_ENDPOINT=','NODE_TOKEN=','TASK_HMAC_KEY=','CA_PEM=')) and line.split('=',1)[1].strip():
        errors.append('SECRET_OR_ENDPOINT_EMBEDDED:'+line.split('=',1)[0])
# Check payload manifest. It must not hash itself.
sums=(root/'PAYLOAD_SHA256SUMS.txt').read_text().splitlines()
for raw in sums:
    if not raw.strip(): continue
    m=re.fullmatch(r'([0-9a-f]{64})  \./(.+)', raw)
    if not m:
        errors.append('BAD_CHECKSUM_LINE:'+raw); continue
    expected, rel=m.groups()
    if rel=='PAYLOAD_SHA256SUMS.txt':
        errors.append('SELF_REFERENTIAL_CHECKSUM_FORBIDDEN'); continue
    p=root/rel
    if not p.is_file():
        errors.append('CHECKSUM_FILE_MISSING:'+rel); continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual!=expected: errors.append('CHECKSUM_MISMATCH:'+rel)
# No pycache / bytecode in a sealed source candidate.
for p in root.rglob('*'):
    if '__pycache__' in p.parts or p.suffix=='.pyc': errors.append('BYTECODE_PRESENT:'+str(p.relative_to(root)))
print('CONTROL_PLANE_1_1_LOCAL_SELF_VERIFY=' + ('PASS' if not errors else 'FAIL'))
for e in errors: print(e)
sys.exit(0 if not errors else 1)
