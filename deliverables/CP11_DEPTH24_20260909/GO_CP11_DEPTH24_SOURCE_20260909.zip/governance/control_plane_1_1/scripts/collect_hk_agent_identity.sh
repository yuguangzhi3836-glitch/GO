#!/bin/sh
set -eu
OUT_DIR="${1:-./hk_agent_identity_evidence}"
mkdir -p "$OUT_DIR"
TS=$(date -u +%Y%m%dT%H%M%SZ)
OUT="$OUT_DIR/HK_CONTROL_PLANE_AGENT_IDENTITY_${TS}.txt"
{
  echo "COLLECTED_AT_UTC=$TS"
  echo "HOSTNAME=$(hostname)"
  echo "=== candidate systemd units ==="
  systemctl list-unit-files --no-pager 2>/dev/null | grep -Ei 'go.*(control|agent)|control.*plane|command.*center' || true
  echo "=== loaded units ==="
  systemctl list-units --all --no-pager 2>/dev/null | grep -Ei 'go.*(control|agent)|control.*plane|command.*center' || true
  echo "=== candidate files ==="
  for root in /etc/systemd/system /usr/local/bin /usr/local/lib /opt /home/go-stg; do
    [ -d "$root" ] || continue
    find "$root" -maxdepth 5 -type f \( -iname '*control*plane*' -o -iname '*go*agent*' -o -iname '*command*center*' -o -iname '*node*agent*' \) -print 2>/dev/null || true
  done
} > "$OUT"
# Append sha256 and metadata for only the paths discovered above.
awk '/^\//{print}' "$OUT" | sort -u | while IFS= read -r p; do
  [ -f "$p" ] || continue
  printf 'FILE=%s\n' "$p" >> "$OUT"
  stat -c 'SIZE=%s MODE=%a UID=%u GID=%g MTIME=%y' "$p" >> "$OUT" 2>/dev/null || true
  sha256sum "$p" >> "$OUT"
done
sha256sum "$OUT" > "$OUT.sha256"
printf '%s\n' "$OUT"
cat "$OUT.sha256"
