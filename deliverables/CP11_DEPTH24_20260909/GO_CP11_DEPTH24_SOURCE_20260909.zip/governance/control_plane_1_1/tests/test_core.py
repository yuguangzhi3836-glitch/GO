import hashlib,hmac,sys,pathlib,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
from go_control_plane_1_1.core import Authority, execute_task, canonical_json

def sign(task,key):
    return hmac.new(key.encode(),canonical_json(task),hashlib.sha256).hexdigest()

def assert_hold(task,key='test-only-key',sig=None):
    r=execute_task(task, sig if sig is not None else sign(task,key), key, Authority())
    assert r['gate']=='HOLD' and r['executed'] is False, r
    return r

def main():
    key='test-only-key'
    # Unknown / dangerous actions fail closed.
    for action in ['arbitrary_shell','shell','exec','sql','db_write','service_restart','runtime_cutover']:
        r=assert_hold({'action':action,'params':{}})
        assert 'AUTHORITY_DENY' in r['reason']
    # Invalid HMAC always fails before execution.
    r=execute_task({'action':'runtime_identity','params':{}},'00',key,Authority())
    assert r['reason']=='TASK_HMAC_INVALID' and r['executed'] is False
    # File hashing is a deterministic read-only capability.
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'go-control-plane-1.1'); f.flush()
        task={'action':'file_sha256','params':{'path':f.name}}
        r=execute_task(task,sign(task,key),key,Authority())
        assert r['gate']=='PASS' and r['executed'] is True
        assert r['evidence']['sha256']==hashlib.sha256(b'go-control-plane-1.1').hexdigest()
    # Missing file fails closed.
    assert_hold({'action':'file_sha256','params':{'path':'/no/such/file'}})
    # HTTP health requires TLS URL.
    r=assert_hold({'action':'http_health','params':{'url':'http://example.invalid'}})
    assert r['reason']=='HTTPS_REQUIRED'
    # Systemd unit name is constrained.
    r=assert_hold({'action':'service_status','params':{'unit':'x;rm -rf /'}})
    assert r['reason']=='INVALID_UNIT'
    # RDS head capability refuses raw command/shell execution in this reconstructed component.
    r=assert_hold({'action':'rds_head_readonly','params':{'probe_command':'psql -c select 1'}})
    assert r['reason']=='RAW_SHELL_AND_RAW_DB_DENIED_USE_APPROVED_PROBE_WRAPPER'
    print('CONTROL_PLANE_1_1_CORE_TEST=PASS')
if __name__=='__main__': main()
