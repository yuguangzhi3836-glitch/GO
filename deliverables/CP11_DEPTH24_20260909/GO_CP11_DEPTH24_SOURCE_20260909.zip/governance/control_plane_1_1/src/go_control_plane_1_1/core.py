from __future__ import annotations
import hashlib, hmac, json, os, subprocess, time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ALLOWED_READONLY_ACTIONS = {
    "runtime_identity",
    "http_health",
    "rds_head_readonly",
    "service_status",
    "file_sha256",
}

class GateError(RuntimeError):
    pass

@dataclass(frozen=True)
class Authority:
    name: str = "STAGING_READONLY"

    def permits(self, action: str) -> bool:
        return self.name == "STAGING_READONLY" and action in ALLOWED_READONLY_ACTIONS


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def verify_task_hmac(task: dict[str, Any], key: str, supplied_hex: str) -> bool:
    if not key or not supplied_hex:
        return False
    expected = hmac.new(key.encode(), canonical_json(task), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, supplied_hex)


def file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run_readonly_action(action: str, params: dict[str, Any], authority: Authority) -> dict[str, Any]:
    if not authority.permits(action):
        raise GateError(f"AUTHORITY_DENY:{authority.name}:{action}")
    if action == "file_sha256":
        path = str(params.get("path", ""))
        if not path or not Path(path).is_file():
            raise GateError("FILE_NOT_FOUND")
        return {"action": action, "path": path, "sha256": file_sha256(path)}
    if action == "service_status":
        unit = str(params.get("unit", ""))
        if not unit or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@_.-" for c in unit):
            raise GateError("INVALID_UNIT")
        cp = subprocess.run(["systemctl", "show", unit, "--no-pager", "--property=LoadState,ActiveState,SubState,UnitFileState,FragmentPath"], text=True, capture_output=True)
        return {"action": action, "unit": unit, "exit_code": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr}
    if action == "runtime_identity":
        cp = subprocess.run(["docker", "ps", "--no-trunc", "--format", "{{.Names}}|{{.Image}}|{{.ID}}"], text=True, capture_output=True)
        return {"action": action, "exit_code": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr}
    if action == "http_health":
        url = str(params.get("url", ""))
        if not url.startswith("https://"):
            raise GateError("HTTPS_REQUIRED")
        cp = subprocess.run(["curl", "--fail", "--silent", "--show-error", "--max-time", "10", "--output", "/dev/null", "--write-out", "%{http_code}", url], text=True, capture_output=True)
        return {"action": action, "url": url, "exit_code": cp.returncode, "http_code": cp.stdout.strip(), "stderr": cp.stderr}
    if action == "rds_head_readonly":
        # This action deliberately requires an external wrapper/approved capability.
        # It does not embed credentials and does not issue raw SQL itself.
        probe = str(params.get("probe_command", ""))
        if not probe:
            raise GateError("APPROVED_READONLY_PROBE_REQUIRED")
        raise GateError("RAW_SHELL_AND_RAW_DB_DENIED_USE_APPROVED_PROBE_WRAPPER")
    raise GateError("ACTION_NOT_IMPLEMENTED")


def execute_task(task: dict[str, Any], supplied_hmac: str, key: str, authority: Authority | None = None) -> dict[str, Any]:
    authority = authority or Authority()
    if not verify_task_hmac(task, key, supplied_hmac):
        return {"gate": "HOLD", "reason": "TASK_HMAC_INVALID", "executed": False}
    action = str(task.get("action", ""))
    started = int(time.time())
    try:
        evidence = run_readonly_action(action, dict(task.get("params") or {}), authority)
        return {"gate": "PASS", "executed": True, "authority": authority.name, "started_at": started, "evidence": evidence}
    except GateError as e:
        return {"gate": "HOLD", "executed": False, "authority": authority.name, "started_at": started, "reason": str(e)}
