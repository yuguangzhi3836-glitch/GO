# V7.0 AI Organization Build 01.1 — AI Legal & Authority Control Layer

## Frozen control principle

Every AI Action is Authority-Checked.
Every Legally Exposed AI Action is Legal-Checked.
No AI Self-Determines or Expands Its Own Authority.

所有 AI 动作 100% 经过 Authority / Constitution Gate；所有具有法律、监管、合同或对外责任暴露的 AI 动作，再 100% 经过 C14 AI Legal Gate；任何 AI 不得自行判断、授予或扩大自己的权限。

“绿区经营动作”不是永久免审白名单。是否进入 C14 只按动态 Legal Exposure 判断，不按业务标签判断。

## Engineering boundary

Build 01.1 only adds organization/control-runtime machinery. It does not add or change Hotel, Flight, Rail, Rental, Ride, Attraction or other business functionality; it does not change database schema or migrations; and it does not claim deployment or production autonomy.

## Runtime flow

AI Action Envelope
→ mandatory Authority / Constitution Gate
→ if authority denied: BLOCK
→ if legally exposed: C14 AI Legal Policy Gate
→ LEGAL_ALLOW / LEGAL_ALLOW_WITH_CONDITIONS / LEGAL_HOLD / LEGAL_BLOCK
→ executable only when authority is valid and legal result permits execution.

Legally exposed actions with no approved machine legal-policy match fail closed to LEGAL_HOLD. No jurisdiction-specific law is fabricated by this Build.


## Constitutional Legal Synchronization
GO Constitution is GO internal supreme law. C14 constitutional/authority review applies to 100% of AI actions. External law/regulation/contract review is an additional dynamic layer only where Legal Exposure exists.
