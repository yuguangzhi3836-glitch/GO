# GO Control Plane 1.1 — Reconstructed / Local-Verified Source Component

This component restores the recovered `1.0 -> 1.0.1 -> 1.0.2 -> 1.1` control-plane contract and carries forward relevant Wave07 authority/governance artifacts.

## Merge status
The component is approved only for **dormant source-tree merge** into the unified GO parent. It is not deployment-authorized, not enabled by default, and does not claim byte identity with the lost historical 1.1 package or the historical HK Agent.

The operator explicitly waived HK Agent SHA reconciliation for this source merge on 2026-09-06. That waiver is not evidence of historical byte identity.

## Restored contract
- `submit task -> validate authority -> execute allowlisted action -> collect evidence -> report gate result`.
- `STAGING_READONLY` default authority.
- Fail-closed action validation.
- HMAC task validation primitive.
- Explicit read-only action allowlist.
- Evidence-first result model.
- Secure Transport configuration contract with no embedded secrets.
- Wave07 authority / constitutional governance lineage.

## Safety boundaries
- Arbitrary shell: denied.
- Raw database access: denied by default.
- Write authority: denied by default.
- Production authority: absent.
- Secure Transport: required but unconfigured.
- Activation: disabled by default.

## Historical limitation
The original Control Plane 1.1 archive was not recovered. This is a source reconstruction, not a byte-for-byte restoration.
