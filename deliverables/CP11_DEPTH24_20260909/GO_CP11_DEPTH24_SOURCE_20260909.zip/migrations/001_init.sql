-- GO Hotel Platform - Sprint 1B PostgreSQL DDL V1
-- PostgreSQL 15+
-- Design: modular monolith friendly, append-only event/evidence records, versioned rules.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE SCHEMA IF NOT EXISTS go_hotel;
SET search_path TO go_hotel, public;

-- ---------- ENUMS ----------
CREATE TYPE hotel_status AS ENUM ('DISCOVERED','MATCH_PENDING','ACTIVE','MERGED','SUSPENDED','CLOSED');
CREATE TYPE prebook_status AS ENUM ('CREATED','PROCESSING','PREBOOKED','PRICE_CHANGED','INVENTORY_LOST','FAILED','EXPIRED','CONSUMED');
CREATE TYPE order_status AS ENUM ('DRAFT','PREBOOKED','PAYMENT_PENDING','PAID','CONFIRMATION_PENDING','CONFIRMED','IN_FULFILLMENT','COMPLETED','CHANGE_PENDING','CANCEL_PENDING','CREDIT_CONVERSION_PENDING','CANCELLED','CONVERTED_TO_CREDIT','PAYMENT_FAILED','CONFIRMATION_FAILED','FAILED','CLOSED');
CREATE TYPE fulfillment_status AS ENUM ('NOT_STARTED','CHECKIN_ELIGIBLE','CHECKED_IN','CHECKED_OUT','COMPLETED','NO_SHOW');
CREATE TYPE payment_status AS ENUM ('CREATED','AUTHORIZED','CAPTURED','FAILED','VOIDED');
CREATE TYPE payment_type AS ENUM ('ORIGINAL_BOOKING','CHANGE_ADDITIONAL_PAYMENT','STAY_CREDIT_DIFFERENCE','OTHER_APPROVED');
CREATE TYPE refund_status AS ENUM ('CALCULATED','REQUESTED','PROCESSING','COMPLETED','FAILED');
CREATE TYPE change_status AS ENUM ('QUOTE_CREATED','REQUESTED','PAYMENT_PENDING','NEW_STAY_PREBOOKED','SUPPLIER_PROCESSING','CONFIRMED','FAILED','ROLLED_BACK');
CREATE TYPE stay_credit_status AS ENUM ('RESERVED','ACTIVE','REDEEMING','REDEEMED','EXPIRED','CANCELLED');
CREATE TYPE liability_status AS ENUM ('CALCULATED','OFFSET_PENDING','BANK_DEBIT_PENDING','PARTIALLY_RECOVERED','NEGATIVE_BALANCE','CLEARED','DISPUTED');
CREATE TYPE review_status AS ENUM ('ELIGIBLE','FIRST_INVITE_SENT','NOT_REVIEWED','SECOND_TRIGGERED','COMPLETED','DISPUTED','FROZEN','INVALIDATED');
CREATE TYPE risk_status AS ENUM ('CANDIDATE','UNDER_REVIEW','CONFIRMED','DOWNGRADED','REJECTED','REMEDIATION_REQUIRED','REMEDIATION_VERIFIED','MONITORING','RESOLVED','DISPUTED','REVERSED','ARCHIVED');
CREATE TYPE authorization_status AS ENUM ('DRAFT','ACTIVE','EXPIRED','REVOKED','SUSPENDED');
CREATE TYPE workflow_status AS ENUM ('PENDING','RUNNING','WAITING','SUCCEEDED','FAILED','CANCELLED');
CREATE TYPE recommendation_status AS ENUM ('RECOMMENDED','RECOMMENDED_WITH_ALERT','OBSERVATION','PAUSED','NOT_RECOMMENDED');

-- ---------- CORE IDENTITY ----------
CREATE TABLE hotel (
  hotel_id text PRIMARY KEY,
  canonical_name text NOT NULL,
  localized_name text,
  country_code char(2) NOT NULL,
  city_code text NOT NULL,
  timezone text NOT NULL,
  lat numeric(9,6),
  lng numeric(9,6),
  address_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  phone text,
  official_domain citext,
  status hotel_status NOT NULL DEFAULT 'DISCOVERED',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (hotel_id LIKE 'htl_%')
);

CREATE TABLE supplier (
  supplier_id text PRIMARY KEY,
  legal_name text NOT NULL,
  display_name text,
  country_code char(2),
  status text NOT NULL DEFAULT 'ACTIVE',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (supplier_id LIKE 'sup_%')
);

CREATE TABLE connector (
  connector_id text PRIMARY KEY,
  name text NOT NULL,
  connector_type text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE',
  config_ref text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (connector_id LIKE 'conn_%')
);

CREATE TABLE hotel_external_identity (
  id bigserial PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  connector_id text NOT NULL REFERENCES connector(connector_id),
  external_hotel_id text NOT NULL,
  external_name text,
  match_confidence numeric(5,4),
  match_method text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(connector_id, external_hotel_id)
);

-- ---------- AUTHORIZATION ----------
CREATE TABLE authorization (
  authorization_id text PRIMARY KEY,
  supplier_id text NOT NULL REFERENCES supplier(supplier_id),
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  authorization_type text NOT NULL,
  scope_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  version integer NOT NULL CHECK (version > 0),
  status authorization_status NOT NULL DEFAULT 'DRAFT',
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  signed_evidence_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(hotel_id, authorization_type, version),
  CHECK (authorization_id LIKE 'auth_%')
);

-- ---------- INVENTORY / RATE / OFFER ----------
CREATE TABLE room_type (
  room_type_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  canonical_name text NOT NULL,
  max_occupancy integer NOT NULL CHECK (max_occupancy > 0),
  bed_config_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  size_sqm numeric(7,2),
  status text NOT NULL DEFAULT 'ACTIVE',
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (room_type_id LIKE 'room_%')
);

CREATE TABLE hotel_fare_rule (
  fare_rule_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  supplier_id text NOT NULL REFERENCES supplier(supplier_id),
  version integer NOT NULL CHECK (version > 0),
  fare_family text NOT NULL,
  cooling_off_minutes integer NOT NULL DEFAULT 0 CHECK (cooling_off_minutes >= 0),
  change_allowed boolean NOT NULL DEFAULT false,
  change_fee_type text,
  change_fee_value numeric(12,4),
  higher_price_rule text NOT NULL DEFAULT 'PAY_DIFFERENCE' CHECK (higher_price_rule = 'PAY_DIFFERENCE'),
  lower_price_rule text NOT NULL DEFAULT 'NO_REFUND' CHECK (lower_price_rule = 'NO_REFUND'),
  stay_credit_allowed boolean NOT NULL DEFAULT false,
  stay_credit_validity_days integer NOT NULL DEFAULT 365 CHECK (stay_credit_validity_days = 365),
  stay_credit_scope text NOT NULL DEFAULT 'PROPERTY_ONLY' CHECK (stay_credit_scope = 'PROPERTY_ONLY'),
  max_changes integer,
  no_show_rule_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  status text NOT NULL DEFAULT 'ACTIVE',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(hotel_id, version)
);

CREATE TABLE cancellation_tier (
  tier_id bigserial PRIMARY KEY,
  fare_rule_id text NOT NULL REFERENCES hotel_fare_rule(fare_rule_id) ON DELETE CASCADE,
  from_minutes_before_checkin integer,
  to_minutes_before_checkin integer,
  fee_type text NOT NULL CHECK (fee_type IN ('PERCENT','FIXED_MINOR','FIRST_NIGHT','FULL')),
  fee_value numeric(12,4),
  priority integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE rate_plan (
  rate_plan_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  room_type_id text NOT NULL REFERENCES room_type(room_type_id),
  name text NOT NULL,
  meal_plan text,
  fare_rule_id text REFERENCES hotel_fare_rule(fare_rule_id),
  status text NOT NULL DEFAULT 'ACTIVE',
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (rate_plan_id LIKE 'rate_%')
);

CREATE TABLE offer_snapshot (
  offer_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  room_type_id text NOT NULL REFERENCES room_type(room_type_id),
  rate_plan_id text NOT NULL REFERENCES rate_plan(rate_plan_id),
  stay_json jsonb NOT NULL,
  pricing_json jsonb NOT NULL,
  benefit_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  fare_rule_snapshot_json jsonb NOT NULL,
  source_type text NOT NULL,
  connector_id text NOT NULL REFERENCES connector(connector_id),
  authorization_id text REFERENCES authorization(authorization_id),
  external_offer_ref text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (offer_id LIKE 'off_%')
);

CREATE TABLE prebook (
  prebook_id text PRIMARY KEY,
  offer_id text NOT NULL REFERENCES offer_snapshot(offer_id),
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  connector_id text NOT NULL REFERENCES connector(connector_id),
  external_prebook_id text,
  price_snapshot_json jsonb NOT NULL,
  fare_rule_snapshot_json jsonb NOT NULL,
  benefit_snapshot_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  authorization_snapshot_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  status prebook_status NOT NULL DEFAULT 'CREATED',
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (prebook_id LIKE 'pb_%')
);

-- ---------- ORDER ----------
CREATE TABLE hotel_order (
  order_id text PRIMARY KEY,
  root_order_id text,
  account_id text NOT NULL,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  supplier_id text NOT NULL REFERENCES supplier(supplier_id),
  current_version integer NOT NULL DEFAULT 1 CHECK (current_version > 0),
  check_in date NOT NULL,
  check_out date NOT NULL,
  status order_status NOT NULL,
  fulfillment_status fulfillment_status NOT NULL DEFAULT 'NOT_STARTED',
  currency char(3) NOT NULL,
  order_value_minor bigint NOT NULL CHECK (order_value_minor >= 0),
  current_confirmation_no text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  CHECK (order_id LIKE 'ord_%'),
  CHECK (check_out > check_in)
);

CREATE TABLE hotel_order_version (
  order_version_id bigserial PRIMARY KEY,
  order_id text NOT NULL REFERENCES hotel_order(order_id),
  version_no integer NOT NULL CHECK (version_no > 0),
  stay_snapshot_json jsonb NOT NULL,
  room_snapshot_json jsonb NOT NULL,
  rate_snapshot_json jsonb NOT NULL,
  fare_rule_snapshot_json jsonb NOT NULL,
  benefit_snapshot_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  guest_snapshot_json jsonb NOT NULL,
  supplier_snapshot_json jsonb NOT NULL,
  effective_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(order_id, version_no)
);

-- ---------- MONEY ----------
CREATE TABLE payment (
  payment_id text PRIMARY KEY,
  order_id text NOT NULL REFERENCES hotel_order(order_id),
  payment_type payment_type NOT NULL,
  provider text NOT NULL,
  provider_payment_id text,
  amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
  currency char(3) NOT NULL,
  status payment_status NOT NULL DEFAULT 'CREATED',
  authorized_at timestamptz,
  captured_at timestamptz,
  failed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (payment_id LIKE 'pay_%')
);

CREATE TABLE refund (
  refund_id text PRIMARY KEY,
  order_id text NOT NULL REFERENCES hotel_order(order_id),
  payment_id text NOT NULL REFERENCES payment(payment_id),
  reason text NOT NULL,
  amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
  currency char(3) NOT NULL,
  provider_refund_id text,
  status refund_status NOT NULL DEFAULT 'CALCULATED',
  requested_at timestamptz,
  completed_at timestamptz,
  failed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (refund_id LIKE 'ref_%')
);

-- ---------- CHANGE / CREDIT ----------
CREATE TABLE order_change (
  change_id text PRIMARY KEY,
  order_id text NOT NULL REFERENCES hotel_order(order_id),
  from_version integer NOT NULL,
  to_version integer,
  quote_id text NOT NULL,
  old_value_minor bigint NOT NULL CHECK (old_value_minor >= 0),
  new_value_minor bigint NOT NULL CHECK (new_value_minor >= 0),
  fare_difference_minor bigint NOT NULL,
  change_fee_minor bigint NOT NULL DEFAULT 0 CHECK (change_fee_minor >= 0),
  additional_payment_minor bigint NOT NULL DEFAULT 0 CHECK (additional_payment_minor >= 0),
  currency char(3) NOT NULL,
  status change_status NOT NULL DEFAULT 'QUOTE_CREATED',
  created_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz,
  CHECK (change_id LIKE 'chg_%')
);

CREATE TABLE stay_credit (
  stay_credit_id text PRIMARY KEY,
  original_order_id text NOT NULL REFERENCES hotel_order(order_id),
  account_id text NOT NULL,
  property_id text NOT NULL REFERENCES hotel(hotel_id),
  original_value_minor bigint NOT NULL CHECK (original_value_minor >= 0),
  credit_value_minor bigint NOT NULL CHECK (credit_value_minor >= 0),
  currency char(3) NOT NULL,
  valid_from timestamptz NOT NULL,
  expires_at timestamptz NOT NULL,
  scope text NOT NULL DEFAULT 'PROPERTY_ONLY' CHECK (scope = 'PROPERTY_ONLY'),
  status stay_credit_status NOT NULL,
  redemption_order_id text REFERENCES hotel_order(order_id),
  rule_version text,
  evidence_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  activated_at timestamptz,
  redeemed_at timestamptz,
  CHECK (stay_credit_id LIKE 'sc_%')
);

-- ---------- SUPPLIER LIABILITY / SETTLEMENT ----------
CREATE TABLE supplier_liability (
  liability_id text PRIMARY KEY,
  supplier_id text NOT NULL REFERENCES supplier(supplier_id),
  order_id text NOT NULL REFERENCES hotel_order(order_id),
  liability_type text NOT NULL,
  principal_minor bigint NOT NULL DEFAULT 0 CHECK (principal_minor >= 0),
  compensation_minor bigint NOT NULL DEFAULT 0 CHECK (compensation_minor >= 0),
  total_minor bigint NOT NULL CHECK (total_minor >= 0),
  settlement_offset_minor bigint NOT NULL DEFAULT 0 CHECK (settlement_offset_minor >= 0),
  bank_debit_minor bigint NOT NULL DEFAULT 0 CHECK (bank_debit_minor >= 0),
  protection_fund_minor bigint NOT NULL DEFAULT 0 CHECK (protection_fund_minor >= 0),
  negative_balance_minor bigint NOT NULL DEFAULT 0 CHECK (negative_balance_minor >= 0),
  status liability_status NOT NULL DEFAULT 'CALCULATED',
  decision_id text,
  evidence_id text,
  rule_version text,
  created_at timestamptz NOT NULL DEFAULT now(),
  cleared_at timestamptz
);

CREATE TABLE settlement_ledger (
  settlement_entry_id bigserial PRIMARY KEY,
  supplier_id text NOT NULL REFERENCES supplier(supplier_id),
  order_id text REFERENCES hotel_order(order_id),
  liability_id text REFERENCES supplier_liability(liability_id),
  entry_type text NOT NULL,
  amount_minor bigint NOT NULL,
  currency char(3) NOT NULL,
  external_ref text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- REVIEW / RISK ----------
CREATE TABLE review (
  review_id text PRIMARY KEY,
  order_id text NOT NULL UNIQUE REFERENCES hotel_order(order_id),
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  account_id text NOT NULL,
  verified_stay boolean NOT NULL DEFAULT false,
  raw_star_input smallint CHECK (raw_star_input BETWEEN 1 AND 5),
  trigger_source text,
  status review_status NOT NULL DEFAULT 'ELIGIBLE',
  trust_weight numeric(6,5),
  public_status text NOT NULL DEFAULT 'PENDING',
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (review_id LIKE 'rev_%')
);

CREATE TABLE review_tag (
  review_tag_id bigserial PRIMARY KEY,
  review_id text NOT NULL REFERENCES review(review_id) ON DELETE CASCADE,
  category text NOT NULL,
  tag_code text NOT NULL,
  polarity text,
  severity text,
  mapped_dimensions_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE review_content (
  review_id text PRIMARY KEY REFERENCES review(review_id) ON DELETE CASCADE,
  text_content text,
  voice_ref text,
  photo_refs_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE risk_event (
  risk_event_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  order_id text REFERENCES hotel_order(order_id),
  review_id text REFERENCES review(review_id),
  risk_type text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('R0','R1','R2','R3')),
  status risk_status NOT NULL DEFAULT 'CANDIDATE',
  confidence numeric(5,4),
  occurred_at timestamptz,
  detected_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz,
  resolved_at timestamptz,
  decision_id text,
  rule_version text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (risk_event_id LIKE 'risk_%')
);

CREATE TABLE risk_evidence (
  id bigserial PRIMARY KEY,
  risk_event_id text NOT NULL REFERENCES risk_event(risk_event_id) ON DELETE CASCADE,
  evidence_id text NOT NULL,
  source_actor text,
  credibility numeric(5,4),
  relevance numeric(5,4),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE risk_remediation (
  remediation_id text PRIMARY KEY,
  risk_event_id text NOT NULL REFERENCES risk_event(risk_event_id),
  supplier_action_json jsonb NOT NULL,
  evidence_ids_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  verified_at timestamptz
);

-- ---------- JUDGMENT / RECOMMENDATION ----------
CREATE TABLE judgment (
  judgment_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  go_score numeric(3,2) NOT NULL CHECK (go_score BETWEEN 0 AND 5),
  quality_dimensions_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  risk_summary_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  model_version text,
  prompt_version text,
  rule_version text NOT NULL,
  evidence_package_id text,
  valid_from timestamptz NOT NULL,
  valid_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (judgment_id LIKE 'jud_%')
);

CREATE TABLE guest_experience_snapshot (
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  calculated_at timestamptz NOT NULL DEFAULT now(),
  experience_score numeric(3,2) NOT NULL CHECK (experience_score BETWEEN 3.0 AND 5.0),
  verified_review_count integer NOT NULL DEFAULT 0,
  dimensions_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  PRIMARY KEY(hotel_id, calculated_at)
);

CREATE TABLE recommendation_decision (
  decision_id text PRIMARY KEY,
  hotel_id text NOT NULL REFERENCES hotel(hotel_id),
  status recommendation_status NOT NULL,
  reason_codes_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  judgment_id text NOT NULL REFERENCES judgment(judgment_id),
  evidence_package_id text,
  valid_from timestamptz NOT NULL,
  valid_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- EVIDENCE / DECISION / WORKFLOW ----------
CREATE TABLE evidence (
  evidence_id text PRIMARY KEY,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  source_type text NOT NULL,
  source_id text,
  content_type text NOT NULL,
  content_ref text NOT NULL,
  content_hash text NOT NULL,
  captured_at timestamptz NOT NULL,
  metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (evidence_id LIKE 'evd_%')
);

CREATE TABLE evidence_package (
  package_id text PRIMARY KEY,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  evidence_ids_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  sealed_at timestamptz
);

CREATE TABLE decision (
  decision_id text PRIMARY KEY,
  decision_type text NOT NULL,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  rule_id text NOT NULL,
  rule_version text NOT NULL,
  input_snapshot_json jsonb NOT NULL,
  output_json jsonb NOT NULL,
  evidence_package_id text REFERENCES evidence_package(package_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (decision_id LIKE 'dec_%')
);

CREATE TABLE workflow_instance (
  workflow_id text PRIMARY KEY,
  workflow_type text NOT NULL,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  current_state text NOT NULL,
  status workflow_status NOT NULL DEFAULT 'PENDING',
  rule_version text,
  started_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  CHECK (workflow_id LIKE 'wf_%')
);

CREATE TABLE workflow_step (
  workflow_step_id bigserial PRIMARY KEY,
  workflow_id text NOT NULL REFERENCES workflow_instance(workflow_id) ON DELETE CASCADE,
  step_type text NOT NULL,
  status text NOT NULL,
  attempt_count integer NOT NULL DEFAULT 0,
  next_retry_at timestamptz,
  input_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  output_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

-- ---------- EVENTING / IDEMPOTENCY / WEBHOOK ----------
CREATE TABLE order_event (
  event_id text PRIMARY KEY,
  event_type text NOT NULL,
  event_version integer NOT NULL DEFAULT 1,
  aggregate_type text NOT NULL,
  aggregate_id text NOT NULL,
  occurred_at timestamptz NOT NULL,
  actor_type text NOT NULL,
  actor_id text,
  correlation_id text,
  causation_id text,
  decision_id text,
  evidence_id text,
  rule_version text,
  payload_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (event_id LIKE 'evt_%')
);

CREATE TABLE event_outbox (
  outbox_id bigserial PRIMARY KEY,
  event_id text NOT NULL UNIQUE REFERENCES order_event(event_id),
  topic text NOT NULL,
  payload_json jsonb NOT NULL,
  status text NOT NULL DEFAULT 'PENDING',
  available_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  attempts integer NOT NULL DEFAULT 0,
  last_error text
);

CREATE TABLE idempotency_record (
  idempotency_key text NOT NULL,
  actor_id text NOT NULL,
  operation text NOT NULL,
  request_hash text NOT NULL,
  status text NOT NULL,
  response_code integer,
  response_body jsonb,
  resource_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  PRIMARY KEY(actor_id, operation, idempotency_key)
);

CREATE TABLE webhook_inbox (
  webhook_id text PRIMARY KEY,
  connector_id text NOT NULL REFERENCES connector(connector_id),
  external_event_id text NOT NULL,
  signature_valid boolean,
  raw_payload_ref text NOT NULL,
  normalized_event_type text,
  processing_status text NOT NULL DEFAULT 'RECEIVED',
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  UNIQUE(connector_id, external_event_id)
);

-- ---------- STATE TRANSITION TABLES ----------
CREATE TABLE state_transition_rule (
  machine_name text NOT NULL,
  from_state text NOT NULL,
  event_type text NOT NULL,
  to_state text NOT NULL,
  guard_rule_id text,
  terminal boolean NOT NULL DEFAULT false,
  notes text,
  PRIMARY KEY(machine_name, from_state, event_type)
);

-- ---------- INDEXES ----------
CREATE INDEX idx_hotel_external_identity_hotel ON hotel_external_identity(hotel_id);
CREATE INDEX idx_offer_hotel_expiry ON offer_snapshot(hotel_id, expires_at);
CREATE INDEX idx_prebook_hotel_status ON prebook(hotel_id, status);
CREATE INDEX idx_order_account_created ON hotel_order(account_id, created_at DESC);
CREATE INDEX idx_order_hotel_checkin ON hotel_order(hotel_id, check_in);
CREATE INDEX idx_order_supplier_status ON hotel_order(supplier_id, status);
CREATE INDEX idx_order_event_aggregate_time ON order_event(aggregate_id, occurred_at);
CREATE INDEX idx_order_event_type_time ON order_event(event_type, occurred_at);
CREATE INDEX idx_payment_order ON payment(order_id);
CREATE INDEX idx_refund_order ON refund(order_id);
CREATE INDEX idx_stay_credit_account_status ON stay_credit(account_id, status);
CREATE INDEX idx_stay_credit_property_status ON stay_credit(property_id, status);
CREATE INDEX idx_stay_credit_expiry ON stay_credit(expires_at) WHERE status = 'ACTIVE';
CREATE INDEX idx_review_hotel_completed ON review(hotel_id, completed_at DESC);
CREATE INDEX idx_risk_hotel_status ON risk_event(hotel_id, status);
CREATE INDEX idx_risk_order ON risk_event(order_id);
CREATE INDEX idx_liability_supplier_status ON supplier_liability(supplier_id, status);
CREATE INDEX idx_workflow_subject_status ON workflow_instance(subject_id, status);
CREATE INDEX idx_outbox_pending ON event_outbox(status, available_at) WHERE status = 'PENDING';

-- ---------- PROTECT APPEND-ONLY TABLES ----------
CREATE OR REPLACE FUNCTION prevent_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'append-only table: mutation not allowed';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER evidence_append_only
BEFORE UPDATE OR DELETE ON evidence
FOR EACH ROW EXECUTE FUNCTION prevent_mutation();

CREATE TRIGGER order_event_append_only
BEFORE UPDATE OR DELETE ON order_event
FOR EACH ROW EXECUTE FUNCTION prevent_mutation();

CREATE TRIGGER decision_append_only
BEFORE UPDATE OR DELETE ON decision
FOR EACH ROW EXECUTE FUNCTION prevent_mutation();

CREATE TRIGGER settlement_ledger_append_only
BEFORE UPDATE OR DELETE ON settlement_ledger
FOR EACH ROW EXECUTE FUNCTION prevent_mutation();

COMMIT;
