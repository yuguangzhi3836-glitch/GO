-- GO Hotel Platform Sprint 1E resilience additions (PostgreSQL 16)
BEGIN;

ALTER TABLE payment_runtime ADD COLUMN IF NOT EXISTS payment_type varchar(48) NOT NULL DEFAULT 'ORIGINAL_BOOKING';
ALTER TABLE payment_runtime ADD COLUMN IF NOT EXISTS external_operation_id varchar(64);
CREATE UNIQUE INDEX IF NOT EXISTS uq_payment_external_operation_idx ON payment_runtime(external_operation_id) WHERE external_operation_id IS NOT NULL;

ALTER TABLE transactional_outbox ADD COLUMN IF NOT EXISTS locked_at timestamptz;
ALTER TABLE transactional_outbox ADD COLUMN IF NOT EXISTS lock_token varchar(64);
ALTER TABLE transactional_outbox ADD COLUMN IF NOT EXISTS worker_id varchar(128);
ALTER TABLE transactional_outbox ADD COLUMN IF NOT EXISTS dead_lettered_at timestamptz;
CREATE INDEX IF NOT EXISTS ix_outbox_claim ON transactional_outbox(status, available_at, locked_at, outbox_id);
CREATE INDEX IF NOT EXISTS ix_outbox_lock_token ON transactional_outbox(lock_token);

CREATE TABLE IF NOT EXISTS outbox_dead_letter (
  dead_letter_id bigserial PRIMARY KEY,
  outbox_id bigint NOT NULL,
  event_id varchar(64) NOT NULL,
  event_type varchar(96) NOT NULL,
  aggregate_id varchar(64) NOT NULL,
  payload jsonb NOT NULL,
  attempt_count integer NOT NULL,
  last_error text,
  dead_lettered_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_dlq_outbox ON outbox_dead_letter(outbox_id);
CREATE INDEX IF NOT EXISTS ix_dlq_event ON outbox_dead_letter(event_id);

CREATE TABLE IF NOT EXISTS external_operation (
  operation_id varchar(64) PRIMARY KEY,
  operation_type varchar(64) NOT NULL,
  aggregate_id varchar(64) NOT NULL,
  business_key varchar(160) NOT NULL UNIQUE,
  request_hash varchar(64) NOT NULL,
  status varchar(32) NOT NULL,
  attempt_count integer NOT NULL DEFAULT 1,
  external_reference varchar(128),
  request_payload jsonb NOT NULL,
  result_payload jsonb,
  last_error text,
  next_retry_at timestamptz,
  created_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL,
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS ix_external_operation_aggregate ON external_operation(aggregate_id);
CREATE INDEX IF NOT EXISTS ix_external_operation_recovery ON external_operation(status, next_retry_at);

CREATE TABLE IF NOT EXISTS webhook_inbox (
  webhook_id varchar(64) PRIMARY KEY,
  connector_id varchar(64) NOT NULL,
  external_event_id varchar(128) NOT NULL,
  aggregate_id varchar(64) NOT NULL,
  event_type varchar(96) NOT NULL,
  external_sequence bigint,
  signature_valid boolean NOT NULL,
  raw_payload jsonb NOT NULL,
  status varchar(32) NOT NULL,
  processing_error text,
  received_at timestamptz NOT NULL,
  processed_at timestamptz,
  CONSTRAINT uq_webhook_connector_event UNIQUE(connector_id, external_event_id)
);
CREATE INDEX IF NOT EXISTS ix_webhook_aggregate ON webhook_inbox(aggregate_id);
CREATE INDEX IF NOT EXISTS ix_webhook_pending ON webhook_inbox(status, received_at);

CREATE TABLE IF NOT EXISTS connector_event_cursor (
  connector_id varchar(64) NOT NULL,
  aggregate_id varchar(64) NOT NULL,
  last_sequence bigint NOT NULL DEFAULT 0,
  last_external_event_id varchar(128),
  updated_at timestamptz NOT NULL,
  PRIMARY KEY(connector_id, aggregate_id)
);

COMMIT;
