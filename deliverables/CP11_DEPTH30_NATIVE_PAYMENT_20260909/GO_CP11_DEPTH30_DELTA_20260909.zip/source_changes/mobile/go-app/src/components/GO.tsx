import React from 'react';
import {Pressable,StyleSheet,Text,TextInput,View} from 'react-native';
import {GO,screen,type} from '../design';

export function Brand({compact=false,reverse=false}:{compact?:boolean;reverse?:boolean}){
  // GO master proportion stays locked. The implementation remains text-built until the formal SVG asset is wired.
  const g=compact?30:42,o=Math.round(g*.667); const color=reverse?'#FFFFFF':GO.navy;
  return <View style={{flexDirection:'row',alignItems:'center',height:g}}>
    <Text style={{fontSize:g,fontWeight:'900',letterSpacing:-2.2,color,lineHeight:g}}>G</Text>
    <View style={{height:g,justifyContent:'center',marginLeft:-1,position:'relative'}}>
      <Text style={{fontSize:o,fontWeight:'800',letterSpacing:-1.2,color,lineHeight:o}}>O</Text>
      <View style={{position:'absolute',left:-3,top:'48%',width:compact?8:10,height:compact?3:4,borderRadius:2,backgroundColor:GO.orange}}/>
    </View>
  </View>
}
export function SubBrand({name,reverse=false,compact=false}:{name:'AI'|'推荐'|'直连'|'礼遇'|'Offer';reverse?:boolean;compact?:boolean}){
  const color=reverse?'#FFFFFF':GO.navy;
  return <View style={{flexDirection:'row',alignItems:'center'}}><Brand compact={compact} reverse={reverse}/><Text style={{marginLeft:compact?5:7,fontSize:compact?16:20,fontWeight:'600',color:name==='Offer'&&!reverse?GO.orange:color}}>{name}</Text></View>
}
export function TopBar({title,right,onBack}:{title?:string;right?:React.ReactNode;onBack?:()=>void}){return <View style={s.topbar}><View style={{width:44}}>{onBack?<Pressable onPress={onBack} style={s.iconBtn}><Text style={s.iconTxt}>‹</Text></Pressable>:<Brand compact/>}</View><Text style={s.topTitle}>{title||''}</Text><View style={{width:44,alignItems:'flex-end'}}>{right}</View></View>}
export function Btn({title,onPress,secondary=false,disabled=false,compact=false,signal='navy'}:{title:string;onPress?:()=>void;secondary?:boolean;disabled?:boolean;compact?:boolean;signal?:'navy'|'blue'|'orange'}){const fill=signal==='blue'?GO.blue:signal==='orange'?GO.orange:GO.navy;return <Pressable disabled={disabled} onPress={onPress} style={[s.btn,secondary?s.btnSecondary:{backgroundColor:fill},compact&&s.btnCompact,disabled&&{opacity:.36}]}><Text style={[s.btnText,secondary?{color:GO.navy}:{color:'white'}]}>{title}</Text></Pressable>}
export function Chip({children,active=false,coral=false}:{children:React.ReactNode;active?:boolean;coral?:boolean}){return <View style={[s.chip,active&&s.chipActive,coral&&s.chipValue]}><Text style={[s.chipText,active&&{color:GO.blue},coral&&{color:GO.orange}]}>{children}</Text></View>}
export function Field({label,value,onChangeText,placeholder,secure=false}:{label?:string;value?:string;onChangeText?:(v:string)=>void;placeholder?:string;secure?:boolean}){return <View style={{marginTop:12}}>{label&&<Text style={s.fieldLabel}>{label}</Text>}<TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor='rgba(7,27,85,0.40)' secureTextEntry={secure} style={s.field}/></View>}
export function Metric({label,value,accent}:{label:string;value:string;accent?:boolean}){return <View style={{flex:1}}><Text style={s.metricLabel}>{label}</Text><Text style={[s.metricValue,accent&&{color:GO.orange}]}>{value}</Text></View>}
export function Price({minor,currency='CNY',prefix='¥'}:{minor?:number;currency?:string;prefix?:string}){if(!Number.isSafeInteger(minor))return <Text style={s.price}>金额待核对</Text>;const n=minor!/100;return <Text style={s.price}>{currency==='CNY'?prefix:currency+' '}{n.toLocaleString('zh-CN',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2})}</Text>}
export function SectionTitle({title,action,onAction}:{title:string;action?:string;onAction?:()=>void}){return <View style={[screen.row,{marginTop:24,marginBottom:8}]}><Text style={screen.h2}>{title}</Text>{action&&<Pressable onPress={onAction}><Text style={{color:GO.blue,fontSize:13,fontWeight:'500'}}>{action} ›</Text></Pressable>}</View>}
export function StatusPill({text,tone='navy'}:{text:string;tone?:'navy'|'green'|'amber'|'coral'}){const bg=tone==='green'?GO.greenPale:tone==='amber'?GO.amberPale:tone==='coral'?GO.pale:GO.bluePale;const c=tone==='green'?GO.green:tone==='amber'?GO.amber:tone==='coral'?GO.orange:GO.navy;return <View style={[s.status,{backgroundColor:bg}]}><View style={[s.dot,{backgroundColor:c}]}/><Text style={{fontSize:12,fontWeight:'600',color:c}}>{text}</Text></View>}
export function InfoRow({label,value,emphasis=false}:{label:string;value:string;emphasis?:boolean}){return <View style={[screen.row,{paddingVertical:9}]}><Text style={screen.sub}>{label}</Text><Text style={{fontSize:14,fontWeight:emphasis?'600':'500',color:GO.navy,maxWidth:'62%',textAlign:'right'}}>{value}</Text></View>}
export function HeroVisual({label='GO 推荐',height=190}:{label?:string;height?:number}){return <View style={[s.hero,{height}]}><View style={s.heroBadge}><Text style={{color:'white',fontWeight:'600',fontSize:11}}>{label}</Text></View><Text style={s.heroText}>安静、可靠、值得住的城市酒店</Text></View>}
export function Timeline({items}:{items:{title:string;sub?:string;done?:boolean}[]}){return <View>{items.map((x,i)=><View key={i} style={{flexDirection:'row'}}><View style={{width:24,alignItems:'center'}}><View style={[s.timelineDot,{backgroundColor:x.done===false?GO.line:GO.blue}]}/>{i<items.length-1&&<View style={s.timelineLine}/>}</View><View style={{paddingBottom:18,flex:1}}><Text style={{fontWeight:'600',color:GO.navy}}>{x.title}</Text>{x.sub&&<Text style={screen.sub}>{x.sub}</Text>}</View></View>)}</View>}

const s=StyleSheet.create({
  topbar:{height:58,paddingHorizontal:16,flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:GO.white},
  iconBtn:{width:40,height:40,borderRadius:20,backgroundColor:GO.white,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:GO.line},iconTxt:{fontSize:32,lineHeight:32,color:GO.navy},topTitle:{...type.titleS,color:GO.navy},
  btn:{minHeight:50,borderRadius:GO.radius.l,alignItems:'center',justifyContent:'center',paddingHorizontal:18,marginTop:12},btnSecondary:{backgroundColor:GO.white,borderWidth:1,borderColor:'rgba(7,27,85,0.16)'},btnCompact:{minHeight:38,borderRadius:GO.radius.m,marginTop:0},btnText:{fontSize:15,fontWeight:'600'},
  chip:{paddingHorizontal:12,paddingVertical:8,borderRadius:999,borderWidth:1,borderColor:'rgba(7,27,85,0.12)',backgroundColor:GO.white,marginRight:8,marginBottom:8},chipActive:{backgroundColor:'rgba(8,120,249,0.06)',borderColor:'rgba(8,120,249,0.22)'},chipValue:{backgroundColor:'rgba(255,75,22,0.06)',borderColor:'rgba(255,75,22,0.18)'},chipText:{fontSize:12,fontWeight:'500',color:GO.navy},
  fieldLabel:{fontSize:12,fontWeight:'500',color:GO.slate,marginBottom:7},field:{backgroundColor:GO.white,borderWidth:1,borderColor:'rgba(7,27,85,0.12)',borderRadius:GO.radius.m,minHeight:50,paddingHorizontal:14,fontSize:15,color:GO.navy},
  metricLabel:{fontSize:12,color:GO.slate},metricValue:{fontSize:20,fontWeight:'600',color:GO.navy,marginTop:4},price:{fontSize:21,fontWeight:'600',color:GO.navy},status:{flexDirection:'row',alignItems:'center',alignSelf:'flex-start',paddingHorizontal:10,paddingVertical:6,borderRadius:999},dot:{width:6,height:6,borderRadius:3,marginRight:6},
  hero:{borderRadius:GO.radius.l,backgroundColor:'#3D4657',overflow:'hidden',position:'relative',justifyContent:'flex-end',padding:18},heroBadge:{position:'absolute',top:12,left:12,backgroundColor:'rgba(7,27,85,.88)',paddingHorizontal:8,paddingVertical:5,borderRadius:999},heroText:{color:'white',fontSize:20,fontWeight:'600',lineHeight:27,width:'80%'},
  timelineDot:{width:10,height:10,borderRadius:5,marginTop:4},timelineLine:{width:2,backgroundColor:GO.line,flex:1,minHeight:34,marginVertical:4},
});
