"""Seal the explicitly enumerated V13 deliverables and verify ZIP contents."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
files=[
    'README.md','build.py','package.py','inputs/GO_MASTER_V12.svg',
    'GO_MASTER_V13.svg','GO_MASTER_V13.png','GO_MASTER_V13_TRANSPARENT.png',
    'GO_MASTER_V13_EQUAL_HEIGHT.svg','GO_MASTER_V13_EQUAL_HEIGHT.png',
    'GO_MASTER_V13_REVERSE.svg','GO_MASTER_V13_REVERSE.png','GO_MASTER_V13_MONO.svg',
    'GO_MASTER_V13_SECOND_RENDERER.png','GO_MASTER_V13_480.png',
    'GO_MASTER_V13_400.png','GO_MASTER_V13_320.png',
    'GO_COMPACT_V13.svg','GO_COMPACT_V13_REVERSE.svg',
    'GO_COMPACT_V13_200.png','GO_COMPACT_V13_160.png',
    'GO_SYMBOL_V13.svg','GO_SYMBOL_V13_48.png','GO_APPLICATIONS_V13.png',
    'DESIGN_VERIFIED.json',
]
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=''.join(sha((root/f).read_bytes())+'  '+f+'\n' for f in files)
(root/'SHA256SUMS').write_text(manifest)
package=root/'GO_BRAND_V13_PACKAGE.zip'
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in files+['SHA256SUMS']: z.write(root/name,arcname=name)
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(files+['SHA256SUMS'])
    for name in files: assert z.read(name)==(root/name).read_bytes()
archive=['README.md','GO_MASTER_V13.svg','GO_MASTER_V13.png',
         'GO_MASTER_V13_EQUAL_HEIGHT.svg','GO_COMPACT_V13.svg','GO_APPLICATIONS_V13.png',
         'DESIGN_VERIFIED.json','SHA256SUMS','GO_BRAND_V13_PACKAGE.zip']
items=[]
for name in archive:
    raw=(root/name).read_bytes()
    items.append({'path':str(root/name),'relative':name,'size':len(raw),'sha256':sha(raw),
                  'git_sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
print(json.dumps(items))
