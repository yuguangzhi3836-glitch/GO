"""Package an explicitly enumerated set of generated V12 files."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
files = [
    'README.md', 'build.py', 'package.py', 'inputs/GO_LIGHTER_V7.svg',
    'GO_MASTER_V12.svg', 'GO_MASTER_V12.png',
    'GO_MASTER_V12_EQUAL_HEIGHT.svg', 'GO_MASTER_V12_EQUAL_HEIGHT.png',
    'GO_MASTER_V12_REVERSE.svg', 'GO_MASTER_V12_REVERSE.png',
    'GO_MASTER_V12_MONO.svg', 'GO_MASTER_V12_SECOND_RENDERER.png',
    'GO_MASTER_V12_400.png', 'GO_MASTER_V12_320.png',
    'GO_COMPACT_V12.svg', 'GO_COMPACT_V12_200.png', 'GO_COMPACT_V12_160.png',
    'GO_SYMBOL_V12.svg', 'GO_SYMBOL_V12_48.png', 'GO_APPLICATIONS_V12.png',
    'DESIGN_VERIFIED.json',
]
manifest = ''.join(hashlib.sha256((root/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in files)
(root/'SHA256SUMS').write_text(manifest)
with zipfile.ZipFile(root/'GO_BRAND_V12_PACKAGE.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in files+['SHA256SUMS']: z.write(root/name,arcname=name)
with zipfile.ZipFile(root/'GO_BRAND_V12_PACKAGE.zip') as z:
    assert z.testzip() is None
    for name in files: assert z.read(name) == (root/name).read_bytes()

# Full native set is in the package; also expose key review files directly.
archive = ['README.md','GO_MASTER_V12.svg','GO_MASTER_V12.png',
    'GO_MASTER_V12_EQUAL_HEIGHT.svg','GO_COMPACT_V12.svg','GO_APPLICATIONS_V12.png',
    'DESIGN_VERIFIED.json','SHA256SUMS','GO_BRAND_V12_PACKAGE.zip']
items=[]
for name in archive:
    raw=(root/name).read_bytes()
    items.append({'path':str(root/name),'relative':name,'size':len(raw),
        'sha256':hashlib.sha256(raw).hexdigest(),
        'git_sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
print(json.dumps(items))
