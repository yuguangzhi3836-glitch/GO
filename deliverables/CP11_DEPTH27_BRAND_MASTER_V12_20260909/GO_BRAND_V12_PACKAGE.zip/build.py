"""GO V12: native outlined wordmark and preserved GO / Chinese artwork.

Build with Python 3, fontTools, Pillow, PyMuPDF and Inkscape. This creates
static identity assets only; it does not touch application code or deployment.
"""
from pathlib import Path
import copy
import hashlib
import json
import math
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from fontTools.pens.boundsPen import BoundsPen
from fontTools.svgLib.path import parse_path
from PIL import Image, ImageDraw, ImageFont
import fitz

ROOT = Path(__file__).resolve().parent
NS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', NS)
tag = lambda s: '{' + NS + '}' + s
SHA = lambda b: hashlib.sha256(b).hexdigest()
NAVY, RED = '#061B3A', '#FF3B24'
SOURCE_SHA = 'f08ddbe68f7a48f3121f601fee90be0ca9da8b6b3f33128b8016cbcf5a6d75d9'
source = ROOT / 'inputs' / 'GO_LIGHTER_V7.svg'
source.parent.mkdir(exist_ok=True)
if not source.exists():
    source.write_bytes((ROOT.parent / 'go-brand-master-v8-20260909/inputs/GO_LIGHTER_V7.svg').read_bytes())
assert SHA(source.read_bytes()) == SOURCE_SHA
base = ET.fromstring(source.read_bytes())

def get(root, id):
    return root.find(f".//*[@id='{id}']")

def save(root, name):
    p = ROOT / name
    p.write_bytes(ET.tostring(root, encoding='utf-8', xml_declaration=True))
    return p

def bounds(d):
    pen = BoundsPen(None)
    parse_path(d, pen)
    return pen.bounds

def new_svg(id, vb, title):
    r = ET.Element(tag('svg'), {'id':id, 'viewBox':vb, 'role':'img',
        'aria-label':title, 'preserveAspectRatio':'xMidYMid meet'})
    ET.SubElement(r, tag('title')).text = title
    return r

# Six purpose-drawn glyphs, sharing a 350-unit cap height and 54/56-unit stems.
# D/C use circular, not arbitrary elliptical, contours; R uses the same
# concentric-bowl construction. The A counter and bar form one filled outline.
cosa, sina = math.cos(math.radians(38)), math.sin(math.radians(38))
cx, cy = 175+175*cosa, 175-175*sina
ix, iy = 175+121*cosa, 175-121*sina
GLYPHS = {
    'A':'M0 350 L155 0 H211 L366 350 H307 L263 256 H103 L59 350 Z M123 205 H243 L183 67 Z',
    'I':'M0 0 H56 V350 H0 Z',
    'D':'M0 0 H195 A175 175 0 0 1 195 350 H0 Z M56 54 V296 H195 A121 121 0 0 0 195 54 Z',
    'R':'M0 0 H210 A110 110 0 0 1 210 220 H56 V350 H0 Z M56 54 V166 H210 A56 56 0 0 0 210 54 Z M181 195 H246 L354 350 H289 Z',
    'E':'M0 0 H330 V38 L314 54 H56 V148 H278 V186 L262 202 H56 V296 H330 V334 L314 350 H0 Z',
    'C':f'M{cx:.9f} {cy:.9f} A175 175 0 1 0 {cx:.9f} {350-cy:.9f} L{ix:.9f} {350-iy:.9f} A121 121 0 1 1 {ix:.9f} {iy:.9f} Z',
    'T':'M0 0 H350 V38 L334 54 H203 V350 H147 V54 H0 Z',
}

def draw_english(left=2380, top=105, height=350, total=3100, plus=200, word_gap=200, plus_gap=80):
    e = ET.Element(tag('g'), {'id':'english-line', 'fill':NAVY})
    word = ET.SubElement(e, tag('g'), {'id':'wordmark', 'data-wordmark':'AI DIRECT', 'data-design':'custom-filled-v12'})
    chars = 'AIDIRECT'
    s = height/350
    bs = [bounds(GLYPHS[c]) for c in chars]
    widths = [(b[2]-b[0])*s for b in bs]
    # Optical pair-specific spacing, explicitly separate from the word space.
    weights = [1.03, .94, 1.02, .91, .99, .87]
    unit = (total-sum(widths)-plus-plus_gap-word_gap)/sum(weights)
    assert unit > 0
    gaps = [weights[0]*unit, word_gap, *[w*unit for w in weights[1:]]]
    x = left
    for i, (ch, b, w) in enumerate(zip(chars, bs, widths)):
        ET.SubElement(word, tag('path'), {'id':f'english-{i}', 'data-character':ch,
            'd':GLYPHS[ch], 'fill-rule':'evenodd' if ch in 'AD' else 'nonzero',
            'transform':f'matrix({s:.12f} 0 0 {s:.12f} {x-b[0]*s:.12f} {top:.12f})'})
        x += w + (gaps[i] if i < 7 else 0)
    x += plus_gap
    a = plus*.38
    b = plus-a
    ET.SubElement(e, tag('path'), {'id':'plus', 'fill':RED,
        'd':f'M0 {a} H{a} V0 H{b} V{a} H{plus} V{b} H{b} V{plus} H{a} V{b} H0 Z',
        'transform':f'translate({x:.12f} {top})'})
    assert abs(x+plus-left-total) < .00001
    return e, {'cap_height':height, 'vertical_stem':56*s, 'horizontal_stem':54*s, 'total_width':total,
        'pair_gaps':gaps, 'word_gap':word_gap, 'plus_size':plus, 'plus_gap':plus_gap}

main = new_svg('go-master-v12', '-220 -100 5920 1200', 'GO AI DIRECT+ / 发现全世界 直接向官方预订')
mark = copy.deepcopy(get(base, 'go-mark'))
for e, id in zip(mark, ['g-ring', 'g-crossbar', 'o-ring', 'red-connector']):
    e.set('id', id)
get(mark, 'g-crossbar').set('d', 'M602 432 H1030 V568 H466 Z')
main.append(mark)
right = ET.SubElement(main, tag('g'), {'id':'right-block'})
eng, eng_layout = draw_english()
right.append(eng)
cn = copy.deepcopy(get(base, 'chinese-line'))
right.append(cn)
bs = [bounds(p.get('d')) for p in cn]
sw = float(cn.get('stroke-width'))
y0 = min(b[1] for b in bs)-sw/2
y1 = max(b[3] for b in bs)+sw/2
cn_height, cn_bottom, width, left, phrase = 244, 920, 3100, 2380, 62
s = cn_height/(y1-y0)
widths = [(b[2]-b[0]+sw)*s for b in bs]
gap = (width-sum(widths)-phrase)/11
assert gap > 0
x = left
for i, (p, b, w) in enumerate(zip(cn, bs, widths)):
    p.set('transform', f'matrix({s:.12f} 0 0 {s:.12f} {x-s*(b[0]-sw/2):.12f} {cn_bottom-cn_height-s*y0:.12f})')
    assert p.get('d') == list(get(base, 'chinese-line'))[i].get('d')
    x += w + (gap if i < 11 else 0) + (phrase if i == 4 else 0)
assert abs(x-left-width) < .00001
assert ''.join(p.get('data-character') for p in cn) == '发现全世界直接向官方预订'
layout = {'english':eng_layout, 'chinese':{'height':cn_height,'gap':gap,'phrase_extra_gap':phrase},
    'right_block':{'top':105,'bottom':920,'alignment':'optically centered within GO; not equal outer height'},
    'preserved':{'GO_outer_diameter':1000,'GO_inner_diameter':670,'red_square':[1050,420,160,160]}}

main_path = save(main, 'GO_MASTER_V12.svg')
# Bake only the original Chinese stroke expansion into filled outlines. Newly
# designed English has no stroke and cannot acquire centerline protrusions.
raw = copy.deepcopy(main)
temp = ROOT / 'GO_MASTER_V12-outline.svg'
subprocess.run(['inkscape', str(main_path), '--export-type=svg', '--export-plain-svg',
    f'--export-filename={temp}', '--actions=select-all:all;object-stroke-to-path;export-do'], check=True, capture_output=True)
main = ET.fromstring(temp.read_bytes())
for e in main.iter():
    if 'style' in e.attrib:
        style = dict(pair.split(':',1) for pair in e.get('style').split(';') if ':' in pair)
        for key in ['fill','fill-rule','clip-rule','opacity','fill-opacity']:
            if key in style: e.set(key,style[key])
        del e.attrib['style']
    for key in list(e.attrib):
        if key.startswith('stroke'): del e.attrib[key]
    if e.get('id'):
        old = get(raw, e.get('id'))
        if old is not None:
            for key, value in old.attrib.items():
                if key.startswith('data-'): e.set(key,value)
save(main, 'GO_MASTER_V12.svg')

def recolor(root, ink, accent):
    r = copy.deepcopy(root)
    for e in r.iter():
        if e.get('fill','').lower() == NAVY.lower(): e.set('fill',ink)
        if e.get('fill','').lower() == RED.lower(): e.set('fill',accent)
    return r

reverse_path = save(recolor(main, '#FFFFFF', RED), 'GO_MASTER_V12_REVERSE.svg')
mono_path = save(recolor(main, '#111111', '#111111'), 'GO_MASTER_V12_MONO.svg')
equal_height = copy.deepcopy(main)
equal_height.set('id','go-master-v12-equal-height')
get(equal_height,'english-line').set('transform','translate(0 -105)')
get(equal_height,'chinese-line').set('transform','translate(0 80)')
equal_path = save(equal_height,'GO_MASTER_V12_EQUAL_HEIGHT.svg')
compact = new_svg('go-compact-v12', '-150 -100 6100 1200', 'GO AI DIRECT+')
compact.append(copy.deepcopy(mark))
ce, compact_layout = draw_english(left=2350, top=290, height=420, total=3450, plus=200, word_gap=200, plus_gap=70)
compact.append(ce)
compact_path = save(compact, 'GO_COMPACT_V12.svg')
mark_only = new_svg('go-symbol-v12', '-160 -160 2370 1320', 'GO')
mark_only.append(copy.deepcopy(mark))
mark_path = save(mark_only, 'GO_SYMBOL_V12.svg')

def query(path):
    run = subprocess.run(['inkscape',str(path),'--query-all'],check=True,capture_output=True,text=True)
    return {v[0]:[float(n) for n in v[1:]] for v in (line.split(',') for line in run.stdout.splitlines()) if len(v)==5}

def near(a,b):
    assert abs(a-b) < .04, (a,b)

mb, cb = query(main_path), query(compact_path)
eb = query(equal_path)
for b in [mb, cb]: near(b['plus'][1],b['english-7'][1])
for i in [1,3]: near(eb['go-mark'][i],eb['right-block'][i])
for i in [0,2]: near(eb['english-line'][i],eb['chinese-line'][i])
near(eb['plus'][1],eb['english-7'][1])
for i in [0,2]: near(mb['english-line'][i],mb['chinese-line'][i])
for i in [1,3]: near(mb['g-ring'][i],mb['o-ring'][i])
assert mb['plus'][2:] == [200,200]
assert mb['red-connector'][2:] == [160,160]
assert mb['right-block'][1] > mb['go-mark'][1]
assert mb['right-block'][1]+mb['right-block'][3] < mb['go-mark'][1]+mb['go-mark'][3]
assert mb['chinese-11'][0]+mb['chinese-11'][2] < 5920-200
assert not list(main.iter(tag('text')))
assert not any(e.get('stroke') for e in main.iter())
for i in [0,2,3]:
    p = list(mark)[i]
    old = list(get(base,'go-mark'))[i]
    for key, value in old.attrib.items(): assert p.get(key) == value

renders = []
def render(path, width, name, bg='white', engine='inkscape'):
    target = ROOT / name
    if engine == 'inkscape':
        subprocess.run(['inkscape', str(path), '--export-type=png', f'--export-filename={target}',
            f'--export-width={width}', f'--export-background={bg}', '--export-background-opacity=1'],check=True,capture_output=True)
    else:
        with fitz.open(stream=path.read_bytes(),filetype='svg') as d: pdf=d.convert_to_pdf()
        with fitz.open(stream=pdf,filetype='pdf') as d:
            s=width/d[0].rect.width
            d[0].get_pixmap(matrix=fitz.Matrix(s,s),alpha=False).save(target)
    im=Image.open(target).convert('RGB')
    if bg == 'white':
        box=im.convert('L').point(lambda v:255 if v < 220 else 0).getbbox()
        assert box and 0 < box[0] < box[2] < im.width and 0 < box[1] < box[3] < im.height
    else: box=None
    renders.append({'file':name,'width':im.width,'height':im.height,'renderer':engine,'ink_bounds':box})
    return target

render(main_path,1800,'GO_MASTER_V12.png')
render(main_path,400,'GO_MASTER_V12_400.png')
render(main_path,320,'GO_MASTER_V12_320.png')
render(main_path,1800,'GO_MASTER_V12_SECOND_RENDERER.png',engine='mupdf')
render(equal_path,1800,'GO_MASTER_V12_EQUAL_HEIGHT.png')
render(reverse_path,1200,'GO_MASTER_V12_REVERSE.png',bg=NAVY)
render(compact_path,200,'GO_COMPACT_V12_200.png')
render(compact_path,160,'GO_COMPACT_V12_160.png')
render(mark_path,48,'GO_SYMBOL_V12_48.png')

# A static application proof, not a claim of live browser/mobile acceptance.
board = Image.new('RGB',(1600,1080),'#F3F4F6')
draw = ImageDraw.Draw(board)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
draw.text((60,38),'GO / V12     CUSTOM LETTERING SYSTEM',font=font,fill=NAVY)
draw.text((60,78),'Circular construction. Quiet proportions. One deliberate red connection.',font=small,fill='#6B7482')
draw.rectangle((40,130,1560,490), fill='white')
hero = Image.open(ROOT/'GO_MASTER_V12.png').convert('RGB')
hero.thumbnail((1420,288),Image.Resampling.LANCZOS)
board.paste(hero,((1600-hero.width)//2,164))
draw.text((62,451),'01  PRIMARY LOCKUP',font=small,fill='#6B7482')
draw.rectangle((40,520,1010,810), fill=NAVY)
rev=Image.open(ROOT/'GO_MASTER_V12_REVERSE.png').convert('RGB')
rev.thumbnail((905,210),Image.Resampling.LANCZOS)
board.paste(rev,(73,568))
draw.text((62,773),'02  REVERSED',font=small,fill='white')
draw.rectangle((1040,520,1560,810), fill='white')
draw.text((1070,553),'03  SMALL HEADER / 200 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_COMPACT_V12_200.png').convert('RGB'),(1080,602))
draw.text((1070,687),'160 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_COMPACT_V12_160.png').convert('RGB'),(1080,726))
draw.rectangle((40,840,1560,1038), fill='white')
draw.text((64,865),'04  FULL LOCKUP / 400 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_MASTER_V12_400.png').convert('RGB'),(64,917))
draw.text((615,865),'320 PX / SUBTITLE IS SMALL',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_MASTER_V12_320.png').convert('RGB'),(615,927))
draw.text((1115,865),'SYMBOL / 48 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_SYMBOL_V12_48.png').convert('RGB'),(1134,938))
board.save(ROOT/'GO_APPLICATIONS_V12.png')

checks = {'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Static vector geometry and raster proofs only',
    'source_sha256':SOURCE_SHA,'layout':layout,'compact':compact_layout,
    'geometry':mb,'compact_geometry':cb,'equal_height_geometry':eb,'renders':renders,
    'assertions':'PASS: preserved GO circles/connector; complete 12 original Chinese glyphs; equal bilingual visible width; T/plus top alignment; positive spacing; canvas safety; no runtime fonts/strokes',
    'not_asserted':['A universal 10/10 score','Live mobile/browser accessibility or three-end UX','Trademark clearance','Hong Kong deployment or release approval'],
    'design_boundary':'Primary uses an 815-high optically centered right block within 1000-high GO. An additional V12_EQUAL_HEIGHT version retains literal equal outer height without changing glyph shapes.'}
(ROOT/'DESIGN_VERIFIED.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(main_path),'checks':'PASS','right_block':mb['right-block'],'english':mb['english-line'],'chinese':mb['chinese-line'],'cn_gap':gap},ensure_ascii=False))
