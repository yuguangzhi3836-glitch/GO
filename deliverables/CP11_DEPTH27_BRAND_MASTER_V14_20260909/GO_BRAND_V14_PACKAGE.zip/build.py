"""GO V14 native vector identity. Requires Inkscape, Pillow and PyMuPDF.

All lettering is outlined. The V12 GO symbol and Chinese contours are preserved;
V13 English contours are retained, and their positions are refined here.
"""
from pathlib import Path
import copy
import hashlib
import json
import math
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import fitz
from PIL import Image, ImageDraw, ImageFont
from fontTools.pens.boundsPen import BoundsPen
from fontTools.svgLib.path import parse_path

ROOT = Path(__file__).resolve().parent
NS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', NS)
tag = lambda s: '{' + NS + '}' + s
NAVY, RED = '#061B3A', '#FF3B24'
PARENT_SHA256 = 'd3d91f3319288d0b31366e9554476c596e63dbbf3d9d0cce372287ba4e579e8c'
INPUT = ROOT/'inputs/GO_MASTER_V12.svg'
assert hashlib.sha256(INPUT.read_bytes()).hexdigest() == PARENT_SHA256
BASE = ET.parse(INPUT).getroot()
V13_INPUT = ROOT/'inputs/GO_MASTER_V13.svg'
V13_SHA256 = '782e2865d621f353235487cf785a295d519f5782a4982d049a27279e7765dfd2'
assert hashlib.sha256(V13_INPUT.read_bytes()).hexdigest() == V13_SHA256
V13 = ET.parse(V13_INPUT).getroot()
get = lambda root, id: root.find(f".//*[@id='{id}']")

def query(path):
    p = subprocess.run(['inkscape',str(path),'--query-all'],check=True,capture_output=True,text=True)
    return {v[0]:[float(n) for n in v[1:]] for v in (line.split(',') for line in p.stdout.splitlines()) if len(v)==5}

ORIGINAL_BOUNDS = query(INPUT)
# Inkscape reports document coordinates; the input viewBox starts at -220,-100.
for box in ORIGINAL_BOUNDS.values():
    box[0] -= 220
    box[1] -= 100

def outline_bounds(d):
    pen = BoundsPen(None)
    parse_path(d,pen)
    return pen.bounds

def save(root,name):
    path = ROOT/name
    path.write_bytes(ET.tostring(root,encoding='utf-8',xml_declaration=True))
    return path

def svg(id,vb,title):
    root = ET.Element(tag('svg'),{'id':id,'viewBox':vb,'role':'img','aria-label':title,
                                  'preserveAspectRatio':'xMidYMid meet'})
    ET.SubElement(root,tag('title')).text = title
    return root

# Extended circular construction: full-size round A counter, open stadium C,
# D and R bowls sharing the same stroke proportions. No decorative micro-notches.
a = math.radians(38)
xo, yo = 300+175*math.cos(a), 175-175*math.sin(a)
xi, yi = 300+121*math.cos(a), 175-121*math.sin(a)
GLYPHS = {
    'A': 'M0 350 V215 A215 215 0 0 1 430 215 V350 H374 V266 H56 V350 Z '
         'M56 212 H374 A159 159 0 0 0 56 212 Z',
    'I': 'M0 0 H56 V350 H0 Z',
    'D': 'M0 0 H295 A175 175 0 0 1 295 350 H0 Z '
         'M56 54 V296 H295 A121 121 0 0 0 295 54 Z',
    'R': 'M0 0 H300 A111 111 0 0 1 300 222 H56 V350 H0 Z '
         'M56 54 V168 H300 A57 57 0 0 0 300 54 Z '
         'M262 199 H325 L435 350 H366 Z',
    'E': 'M0 0 H390 V54 H56 V148 H326 V180 L304 202 H56 V296 H390 V350 H0 Z',
    'C': f'M{xo} {yo} A175 175 0 0 0 300 0 H175 A175 175 0 0 0 175 350 H300 '
         f'A175 175 0 0 0 {xo} {350-yo} L{xi} {350-yi} A121 121 0 0 1 300 296 '
         f'H175 A121 121 0 0 1 175 54 H300 A121 121 0 0 1 {xi} {yi} Z',
    'T': 'M0 0 H420 V54 H238 V350 H182 V54 H0 Z',
}
for i,ch in enumerate('AIDIRECT'):
    assert GLYPHS[ch] == get(V13,f'english-{i}').get('d')

def english(left=2300,top=190,height=280,width=2700,plus=150,word_gap=130,plus_gap=65):
    group = ET.Element(tag('g'),{'id':'english-line','fill':NAVY,'data-lettering':'GO V14 extended circular'})
    chars='AIDIRECT'
    s=height/350
    bounds=[outline_bounds(GLYPHS[c]) for c in chars]
    widths=[(b[2]-b[0])*s for b in bounds]
    # Six within-word pairs. AI is slightly more open, CT slightly tighter.
    weights=[1.0,.91,1.01,.94,.94,.82]
    unit = (width - (sum(widths) + word_gap + plus + plus_gap)) / sum(weights)
    assert unit>0
    gaps=[unit*weights[0],word_gap,*[unit*w for w in weights[1:]]]
    x=left
    for i,(ch,b,w) in enumerate(zip(chars,bounds,widths)):
        ET.SubElement(group,tag('path'),{'id':f'english-{i}','data-character':ch,
            'd':GLYPHS[ch],'fill-rule':'nonzero' if ch=='R' else 'evenodd',
            'transform':f'matrix({s:.12f} 0 0 {s:.12f} {x-b[0]*s:.12f} {top:.12f})'})
        x+=w+(gaps[i] if i<7 else 0)
    x+=plus_gap
    t=plus*.36
    ET.SubElement(group,tag('path'),{'id':'plus','fill':RED,
        'd':f'M0 {t} H{t} V0 H{plus-t} V{t} H{plus} V{plus-t} H{plus-t} V{plus} H{t} V{plus-t} H0 Z',
        'transform':f'translate({x:.12f} {top:.12f})'})
    assert abs(x+plus-left-width)<.00001,(x+plus,left+width)
    return group,{'cap_height':height,'stem_width':56*s,'pair_gaps':gaps,'word_gap':word_gap,
                  'plus_gap':plus_gap,'plus_size':plus,'total_width':width}

def chinese(left=2300,bottom=810,height=186,width=2700,phrase_extra=80):
    source=get(BASE,'chinese-line')
    group=ET.Element(tag('g'),{'id':'chinese-line','fill':NAVY,'data-text':'发现全世界 直接向官方预订'})
    old=ORIGINAL_BOUNDS['chinese-line']
    s=height/old[3]
    widths=[ORIGINAL_BOUNDS[f'chinese-{i}'][2]*s for i in range(12)]
    gap=(width-sum(widths)-phrase_extra)/11
    assert gap>0
    x=left
    for i,node in enumerate(source):
        b=ORIGINAL_BOUNDS[f'chinese-{i}']
        wrapper=ET.SubElement(group,tag('g'),{'id':f'cn-position-{i}',
             'transform':f'matrix({s:.12f} 0 0 {s:.12f} {x-b[0]*s:.12f} {bottom-height-old[1]*s:.12f})'})
        wrapper.append(copy.deepcopy(node))
        x+=widths[i]+(gap if i<11 else 0)+(phrase_extra if i==4 else 0)
    assert abs(x-left-width)<.00001
    return group,{'height':height,'gap':gap,'phrase_extra_gap':phrase_extra,'total_width':width}

master=svg('go-master-v14','-200 -100 5400 1200','GO AI DIRECT+ / 发现全世界 直接向官方预订')
mark=copy.deepcopy(get(BASE,'go-mark'))
master.append(mark)
right=ET.SubElement(master,tag('g'),{'id':'right-block'})
eng,eng_layout=english()
cn,cn_layout=chinese()
right.extend([eng,cn])
master_path=save(master,'GO_MASTER_V14.svg')

equal=copy.deepcopy(master)
equal.set('id','go-master-v14-equal-height')
get(equal,'english-line').set('transform','translate(0 -190)')
get(equal,'chinese-line').set('transform','translate(0 190)')
equal_path=save(equal,'GO_MASTER_V14_EQUAL_HEIGHT.svg')

compact=svg('go-compact-v14','-180 -100 5360 1200','GO AI DIRECT+')
compact.append(copy.deepcopy(mark))
ce,compact_layout=english(left=2250,top=350,height=300,width=2750,plus=150,word_gap=130,plus_gap=65)
compact.append(ce)
compact_path=save(compact,'GO_COMPACT_V14.svg')
symbol=svg('go-symbol-v14','-160 -160 2370 1320','GO')
symbol.append(copy.deepcopy(mark))
symbol_path=save(symbol,'GO_SYMBOL_V14.svg')

def recolor(root,ink,accent):
    r=copy.deepcopy(root)
    for e in r.iter():
        fill=e.get('fill','').lower()
        if fill==NAVY.lower(): e.set('fill',ink)
        if fill==RED.lower(): e.set('fill',accent)
    return r

reverse_path=save(recolor(master,'#FFFFFF',RED),'GO_MASTER_V14_REVERSE.svg')
mono_path=save(recolor(master,'#111111','#111111'),'GO_MASTER_V14_MONO.svg')
save(recolor(compact,'#FFFFFF',RED),'GO_COMPACT_V14_REVERSE.svg')

renders=[]
def render(path,width,name,bg='white',engine='inkscape'):
    target=ROOT/name
    if engine=='inkscape':
        subprocess.run(['inkscape',str(path),'--export-type=png',f'--export-filename={target}',
                        f'--export-width={width}',f'--export-background={bg}',
                        '--export-background-opacity='+('0' if bg=='none' else '1')],check=True,capture_output=True)
    else:
        with fitz.open(stream=path.read_bytes(),filetype='svg') as d: pdf=d.convert_to_pdf()
        with fitz.open(stream=pdf,filetype='pdf') as d:
            s=width/d[0].rect.width
            d[0].get_pixmap(matrix=fitz.Matrix(s,s),alpha=False).save(target)
    im=Image.open(target)
    if bg=='white':
        box=im.convert('L').point(lambda v:255 if v<220 else 0).getbbox()
        assert box and 0<box[0]<box[2]<im.width and 0<box[1]<box[3]<im.height
    else: box=None
    renders.append({'file':name,'size':list(im.size),'renderer':engine,'ink_bounds':box})
    return target

render(master_path,1800,'GO_MASTER_V14.png')
render(master_path,1800,'GO_MASTER_V14_TRANSPARENT.png',bg='none')
render(master_path,1800,'GO_MASTER_V14_SECOND_RENDERER.png',engine='mupdf')
render(master_path,480,'GO_MASTER_V14_480.png')
render(master_path,400,'GO_MASTER_V14_400.png')
render(master_path,320,'GO_MASTER_V14_320.png')
render(equal_path,1800,'GO_MASTER_V14_EQUAL_HEIGHT.png')
render(reverse_path,1200,'GO_MASTER_V14_REVERSE.png',bg=NAVY)
render(compact_path,200,'GO_COMPACT_V14_200.png')
render(compact_path,160,'GO_COMPACT_V14_160.png')
render(symbol_path,48,'GO_SYMBOL_V14_48.png')

def near(a,b,tol=.05):
    assert abs(a-b)<tol,(a,b)

mb,eb,cb=query(master_path),query(equal_path),query(compact_path)
for b in [mb,eb,cb]: near(b['plus'][1],b['english-7'][1])
for b in [mb,eb]:
    for i in [0,2]: near(b['english-line'][i],b['chinese-line'][i])
for i in [1,3]: near(eb['go-mark'][i],eb['right-block'][i])
for i in [1,3]: near(mb['g-ring'][i],mb['o-ring'][i])
assert ET.tostring(mark)==ET.tostring(get(BASE,'go-mark'))
assert ET.tostring(mark)==ET.tostring(get(V13,'go-mark'))
for i,node in enumerate(cn):
    assert ET.tostring(list(node)[0])==ET.tostring(list(get(BASE,'chinese-line'))[i])
assert ''.join(e.get('data-character','') for e in cn.iter())=='发现全世界直接向官方预订'
assert mb['chinese-11'][0]+mb['chinese-11'][2] < 5210
assert not list(master.iter(tag('text')))
assert not list(master.iter(tag('image')))
assert not any(e.get('stroke') for e in master.iter())

# Review sheet shows identity applications at their actual labelled pixel sizes.
board=Image.new('RGB',(1600,1110),'#F3F4F6')
d=ImageDraw.Draw(board)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
d.text((60,40),'GO / V14     REFINED PROPORTIONS',font=font,fill=NAVY)
d.text((60,80),'Closer typography. Clearer phrases. One consistent identity.',font=small,fill='#6B7482')
d.rectangle((40,132,1560,490),fill='white')
hero=Image.open(ROOT/'GO_MASTER_V14.png').convert('RGB')
hero.thumbnail((1420,288),Image.Resampling.LANCZOS)
board.paste(hero,((1600-hero.width)//2,160))
d.text((62,454),'01  PRIMARY / OPTICAL ALIGNMENT',font=small,fill='#6B7482')
d.rectangle((40,520,1010,810),fill=NAVY)
im=Image.open(ROOT/'GO_MASTER_V14_REVERSE.png').convert('RGB')
im.thumbnail((905,210),Image.Resampling.LANCZOS)
board.paste(im,(73,568))
d.text((62,778),'02  REVERSED',font=small,fill='white')
d.rectangle((1040,520,1560,810),fill='white')
d.text((1070,553),'03  SMALL HEADER / 200 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_COMPACT_V14_200.png').convert('RGB'),(1080,602))
d.text((1070,687),'160 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_COMPACT_V14_160.png').convert('RGB'),(1080,726))
d.rectangle((40,840,1560,1070),fill='white')
d.text((64,865),'04  FULL LOCKUP / 480 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_MASTER_V14_480.png').convert('RGB'),(64,923))
d.text((625,865),'400 PX / SECONDARY TEXT',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_MASTER_V14_400.png').convert('RGB'),(625,939))
d.text((1140,865),'SYMBOL / 48 PX',font=small,fill='#6B7482')
board.paste(Image.open(ROOT/'GO_SYMBOL_V14_48.png').convert('RGB'),(1170,948))
board.save(ROOT/'GO_APPLICATIONS_V14.png')

report={'created_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':PARENT_SHA256,
        'previous_design_sha256':V13_SHA256,
        'changes_from_v13':{'right_block_width':[3100,2700],'chinese_gap':[78.08038715191556,cn_layout['gap']],
                            'GO_to_type_gap':[330,250],'english_cap_height':[300,280],
                            'visible_total_width':[5480,5000]},
        'scope':'Native vector geometry and static raster proofs',
        'english':eng_layout,'chinese':cn_layout,'compact':compact_layout,
        'geometry':mb,'equal_height_geometry':eb,'compact_geometry':cb,'renders':renders,
        'assertions':'PASS: original GO and all 12 Chinese glyph contours preserved; bilingual visible widths equal; plus/T tops equal; strict equal-height variant; canvas safety; no external fonts or images',
        'layout_note':'Primary right block uses optical centering; EQUAL_HEIGHT retains the previously requested exact outer alignment.',
        'limitations':['Small subtitle at 320px; compact asset omits subtitle.','Static proof, not a browser/device acceptance.','Design judgment is not a certified numerical grade.']}
(ROOT/'DESIGN_VERIFIED.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'geometry':'PASS','english':eng_layout,'chinese':cn_layout},ensure_ascii=False))
