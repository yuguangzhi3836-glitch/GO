"""Seal the explicitly enumerated V14 deliverables and verify ZIP contents."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
files=[
    'README.md','build.py','package.py','inputs/GO_MASTER_V12.svg','inputs/GO_MASTER_V13.svg',
    'GO_MASTER_V14.svg','GO_MASTER_V14.png','GO_MASTER_V14_TRANSPARENT.png',
    'GO_MASTER_V14_EQUAL_HEIGHT.svg','GO_MASTER_V14_EQUAL_HEIGHT.png',
    'GO_MASTER_V14_REVERSE.svg','GO_MASTER_V14_REVERSE.png','GO_MASTER_V14_MONO.svg',
    'GO_MASTER_V14_SECOND_RENDERER.png','GO_MASTER_V14_480.png',
    'GO_MASTER_V14_400.png','GO_MASTER_V14_320.png',
    'GO_COMPACT_V14.svg','GO_COMPACT_V14_REVERSE.svg',
    'GO_COMPACT_V14_200.png','GO_COMPACT_V14_160.png',
    'GO_SYMBOL_V14.svg','GO_SYMBOL_V14_48.png','GO_APPLICATIONS_V14.png',
    'DESIGN_VERIFIED.json',
]
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=''.join(sha((root/f).read_bytes())+'  '+f+'\n' for f in files)
(root/'SHA256SUMS').write_text(manifest)
package=root/'GO_BRAND_V14_PACKAGE.zip'
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in files+['SHA256SUMS']:
        entry=zipfile.ZipInfo(name,date_time=(2026,9,9,0,0,0))
        entry.compress_type=zipfile.ZIP_DEFLATED
        entry.external_attr=0o100644 << 16
        z.writestr(entry,(root/name).read_bytes(),compresslevel=9)
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(files+['SHA256SUMS'])
    for name in files: assert z.read(name)==(root/name).read_bytes()
archive=['README.md','GO_MASTER_V14.svg','GO_MASTER_V14.png',
         'GO_MASTER_V14_EQUAL_HEIGHT.svg','GO_COMPACT_V14.svg','GO_APPLICATIONS_V14.png',
         'DESIGN_VERIFIED.json','SHA256SUMS','GO_BRAND_V14_PACKAGE.zip']
items=[]
for name in archive:
    raw=(root/name).read_bytes()
    items.append({'path':str(root/name),'relative':name,'size':len(raw),'sha256':sha(raw),
                  'git_sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
print(json.dumps(items))
