#!/usr/bin/env python3
"""Seal measured DEPTH08 changes without altering the archived DEPTH07."""
import argparse
import copy
import difflib
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

from assemble_depth08_candidate import PARENT_SHA, WORK_SHA, ROOTS, sha, source_entries, tree_hash

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'verification/current_build/depth08'


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def hexdigest(data):
    return hashlib.sha256(data).hexdigest()


def measured_xml(path):
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    counts = {k: sum(int(s.get(k, 0)) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
    counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
    counts['seconds'] = round(sum(float(s.get('time', 0)) for s in suites), 3)
    return counts


def build(parent, work):
    if sha(parent) != PARENT_SHA or sha(work) != WORK_SHA:
        raise ValueError('BASELINE_HASH_MISMATCH')
    with zipfile.ZipFile(parent) as pz, zipfile.ZipFile(work) as wz:
        # Only content that may be compared or replaced is loaded; Python runtime
        # bytes stay in the verified original parent and are never repackaged.
        baseline = {}
        for z in (pz, wz):
            for name in z.namelist():
                if not name.endswith('/') and '__pycache__' not in name and not name.endswith(('.pyc', '.pyo')):
                    if name.split('/')[0] in ROOTS | {'acceptance', 'verification', 'governance'} or '/' not in name:
                        baseline[name] = z.read(name)
    totals = measured_xml(EVIDENCE / 'full_regression.xml')
    if totals['failures'] or totals['errors'] or totals['tests'] < 1026:
        raise ValueError('FULL_REGRESSION_NOT_PASSING')
    full = ET.parse(EVIDENCE / 'full_regression.xml')
    selected = [copy.deepcopy(c) for c in full.getroot().iter('testcase')
                if 'test_depth08_durable' in c.get('classname', '') or 'test_depth08_api_and_migration' in c.get('classname', '')]
    target = ET.Element('testsuites')
    suite = ET.SubElement(target, 'testsuite', name='DEPTH08 subset of full_regression.xml',
              tests=str(len(selected)), failures='0', errors='0', skipped='0',
              time=str(sum(float(c.get('time', 0)) for c in selected)))
    suite.extend(selected)
    ET.ElementTree(target).write(EVIDENCE / 'targeted.xml', encoding='utf-8', xml_declaration=True)
    targeted = measured_xml(EVIDENCE / 'targeted.xml')
    if targeted['tests'] < 57 or any(c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None for c in selected):
        raise ValueError('DEPTH08_TARGETED_MATRIX_INCOMPLETE')

    current = {f['path']: ROOT / f['path'] for f in source_entries(ROOT)}
    before = {name: data for name, data in baseline.items()
              if name.split('/')[0] in ROOTS or name in {'pyproject.toml', 'alembic.ini'}}
    removed = set(before) - set(current)
    if removed:
        raise ValueError('UNSUPPORTED_REMOVAL:' + repr(sorted(removed)))
    changes, patch = [], []
    for name, path in sorted(current.items()):
        data, old = path.read_bytes(), before.get(name)
        if data == old:
            continue
        changes.append({'path': name, 'status': 'ADDED' if old is None else 'MODIFIED',
                        'before_sha256': hexdigest(old) if old is not None else None, 'after_sha256': hexdigest(data)})
        patch.extend(difflib.unified_diff((old or b'').decode().splitlines(True), data.decode().splitlines(True),
                      fromfile='DEPTH07/' + name, tofile='DEPTH08/' + name))
    write(ROOT / 'acceptance/DEPTH08_SOURCE_CHANGES.json', {'baseline_work_sha256': WORK_SHA, 'changes': changes})
    (ROOT / 'acceptance/DEPTH08_SOURCE_CHANGES.patch').write_text(''.join(patch))

    groups = {
        'prior_115_migrations': [n for n in before if n.startswith('alembic/versions/') and n.endswith('.py')],
        'frontend': [n for n in before if n.startswith('frontend/')],
        'autonomy_constitution': [n for n in before if n.startswith('src/go_hotel/autonomy/')],
        'v7_master': ['GO_ULTIMATE_MASTER_PLAN_V7.0_2026-08-31_CONSTITUTIONAL_LEGAL_SYNC_MASTER.pdf'],
    }
    immutable = {label: {'count': len(names), 'all_match': all((ROOT / n).read_bytes() == baseline[n] for n in names),
                        'files': [{'path': n, 'sha256': hexdigest(baseline[n])} for n in sorted(names)]}
                 for label, names in groups.items()}
    if not all(g['all_match'] for g in immutable.values()):
        raise ValueError('IMMUTABLE_BASELINE_CHANGED')
    write(EVIDENCE / 'immutable_baseline.json', immutable)

    status = json.loads(baseline['verification/current_build/depth07/CURRENT_BUILD_STATUS.json'])
    status.update(build='CP11_DEPTH_08_DURABLE_EXECUTION', FINAL_RELEASE_GATE='HOLD', engineering_complete=False,
                  deployed=False, python=totals, new_targeted=targeted,
                  targeted_source='Extracted unchanged testcase records from this full_regression.xml')
    status['baseline']['depth07_work_sha256'] = WORK_SHA
    status['baseline']['depth07_archive_commit'] = '34b80961ee11b282a642e3e3722233dd6bd8120b'
    status['blocked_gates'].append('DURABLE_POSTGRESQL_RUNTIME_AND_MIGRATION')
    status['frontend']['evidence_inherited_from'] = 'DEPTH07; frontend bytes unchanged, no new browser or Node certification'
    status['migrations'] = {'current_head': '0116_autonomy_durable', 'prior_files_unchanged': 115,
                            'added_this_batch': ['alembic/versions/0116_autonomy_durable.py'],
                            'new_tables': ['autonomy_task', 'autonomy_step', 'autonomy_event', 'autonomy_cell_control', 'autonomy_qualification'],
                            'populated_downgrade': 'REFUSED; retain evidence or restore verified backup'}
    status['durable_execution'] = {
        'sqlite_reliability_gate': 'PASS', 'postgresql_runtime_gate': 'NOT_RUN_NO_LOCAL_SERVER',
        'registered_cells': 14, 'application_observation_adapters': 14, 'steps_per_observation': 2,
        'sigkill_fault_points': ['after_claim', 'inside_transaction', 'after_checkpoint', 'after_external_effect'],
        'local_effect_semantics': 'Effect + checkpoint + evidence committed in one DB transaction per step and task identity',
        'external_effect_semantics': 'No automatic resend after ambiguous outcome; receipt must bind original operation key',
        'qualification_semantics': 'Persistent, expiring, independently validated; checked again before every step',
        'c13_semantics': 'Deterministic admin-authorized observation; self-qualification remains prohibited',
        'application_scope': 'Aggregate operational observations; no refunds, provider actions or release approvals executed',
        'worker': 'Explicit standalone process; drains durable queue; no automatic periodic task producer',
        'production_autonomy_accepted': False,
    }
    status['immutable_depth08'] = {k: {'count': v['count'], 'all_match': v['all_match']} for k, v in immutable.items()}
    status['engineering_gaps'] = [g for g in status['engineering_gaps'] if g != '14_CELL_DURABLE_EXECUTION_AND_RECOVERY'] + [
        '14_CELL_POSTGRES_RUNTIME_BUSINESS_ADAPTERS_AND_PRODUCTION_QUALIFICATION']
    status['source_tree_sha256'] = tree_hash(source_entries(ROOT))
    status['source_tree_definition'] = 'Canonical sorted path/SHA256 JSON for src, frontend, tests, tests_frontend, scripts, alembic, pyproject.toml and alembic.ini; excludes bytecode'
    write(EVIDENCE / 'CURRENT_BUILD_STATUS.json', status)
    write(EVIDENCE / 'SOURCE_TREE_MANIFEST.json', {'sha256': status['source_tree_sha256'], 'files': source_entries(ROOT)})
    write(ROOT / 'CURRENT_DEPTH_CANDIDATE.json', {'build': status['build'], 'FINAL_RELEASE_GATE': 'HOLD',
        'deployed': False, 'source_tree_sha256': status['source_tree_sha256'],
        'current_report': 'verification/current_build/depth08/CURRENT_BUILD_STATUS.json',
        'start_here': 'GO_DEPTH08_START_HERE.md', 'older_release_documents': 'Historical inherited milestones, not DEPTH08 release evidence'})
    register = json.loads(baseline['acceptance/MASTER_CLOSURE_REGISTER.json'])
    for r in register['requirements']:
        if r['id'] in {'GOV-01', 'GOV-02', 'GOV-03'}:
            r.update(status='LOCAL_DURABLE_GOVERNED_EXECUTION_AND_RECOVERY_TESTED', fully_accepted=False,
                current_evidence=['verification/current_build/depth08/targeted.xml'],
                scope_note='14 deterministic observation adapters + versioned execution kernel. SQLite and killed-process tests pass; PostgreSQL, expanded business adapters and production qualifications remain unaccepted.')
    register['current_build_report'] = 'verification/current_build/depth08/CURRENT_BUILD_STATUS.json'
    write(ROOT / 'acceptance/MASTER_CLOSURE_REGISTER.json', register)

    selected_paths = {c['path'] for c in changes} | {
        'GO_DEPTH08_START_HERE.md', 'CURRENT_DEPTH_CANDIDATE.json', 'acceptance/GO_DEPTH08_REVIEW.md',
        'acceptance/MASTER_CLOSURE_REGISTER.json', 'acceptance/DEPTH08_SOURCE_CHANGES.json',
        'acceptance/DEPTH08_SOURCE_CHANGES.patch'}
    selected_paths |= {p.relative_to(ROOT).as_posix() for p in EVIDENCE.iterdir() if p.suffix in {'.json', '.xml'}}
    manifest = {'build': status['build'], 'FINAL_RELEASE_GATE': 'HOLD', 'parent_sha256': PARENT_SHA,
                'depth07_work_sha256': WORK_SHA, 'source_tree_sha256': status['source_tree_sha256'], 'files': []}
    for name in sorted(selected_paths):
        path = ROOT / name
        manifest['files'].append({'path': name, 'size': path.stat().st_size, 'sha256': sha(path),
            'before_sha256': hexdigest(baseline[name]) if name in baseline else None,
            'mode': 0o755 if path.stat().st_mode & 0o111 else 0o644})
    out = ROOT / 'deliverables'
    out.mkdir(exist_ok=True)
    destination = out / 'GO_CP11_DEPTH_08_DURABLE_EXECUTION_DELTA_20260907.zip'
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr('DEPTH08_DELTA_MANIFEST.json', json.dumps(manifest, indent=2))
        for f in manifest['files']:
            z.write(ROOT / f['path'], 'payload/' + f['path'])
    with zipfile.ZipFile(destination) as z:
        if z.testzip():
            raise ValueError('DELTA_CRC_FAILURE')
    result = {'filename': destination.name, 'path': str(destination), 'size_bytes': destination.stat().st_size,
              'sha256': sha(destination), 'source_tree_sha256': status['source_tree_sha256'],
              'changed_source_files': len(changes), 'payload_files': len(manifest['files']), 'python': totals,
              'new_targeted': targeted, 'FINAL_RELEASE_GATE': 'HOLD'}
    write(out / 'GO_DEPTH08_BUILD_RECEIPT.json', result)
    (out / (destination.name + '.sha256')).write_text(result['sha256'] + '  ' + destination.name + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent', required=True, type=Path)
    parser.add_argument('--depth07-work', required=True, type=Path)
    args = parser.parse_args()
    build(args.parent, args.depth07_work)
