from pathlib import Path
from collections import defaultdict
import hashlib,json,re,zipfile,shutil
r=Path.cwd(); out=r/'held-cpu-evidence'; p=out/'round-1'
assert (p/'exit.json').exists()
result=json.loads((p/'result.json').read_text()); summary={'diagnostic_only':True,'source':json.loads((out/'source.json').read_text()),'result':result,'tiers':{}}
for stage in result['stages']:
 n=stage['concurrent_transactions']; pids=set(stage['process_ids']); totals=defaultdict(lambda:{'wall_seconds':0.,'cpu_seconds':0.}); counts=[0,0]; files=[]
 for f in p.glob('*.profile.json'):
  rows=json.loads(Path(str(f).removesuffix('.profile.json')).read_text())
  if rows[0]['pid'] not in pids:continue
  profile=json.loads(f.read_text()); held=profile['metrics']['held_cpu']; assert held['valid'],held['errors']
  counts[0]+=held['checkouts'];counts[1]+=held['checkins'];files.append(f.name)
  for label,cost in held['held_thread_by_phase'].items():
   for key in cost:totals[label][key]+=cost[key]
 assert len(files)==4 and counts[0]==counts[1]
 summary['tiers'][str(n)]={'profiles':files,'checkouts':counts[0],'checkins':counts[1],'held_phase_totals':dict(sorted(totals.items(),key=lambda x:-x[1]['cpu_seconds']))}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['tiers'],indent=2))
dest=r/'ci/hold_cpu/evidence/same-host-20261002';dest.mkdir(parents=True,exist_ok=False)
shutil.copy2(out/'summary.json',dest/'summary.json')
files=[f for f in out.rglob('*') if f.is_file()]+list((r/'ci/hold_cpu').glob('*.py'))
secret=re.compile(rb'(?i)authorization[^\r\n]{0,20}bearer\s+[a-z0-9._-]{12,}|eyJ[a-zA-Z0-9_-]{15,}\.[a-zA-Z0-9_-]{15,}\.[a-zA-Z0-9_-]{15,}|(?:ghp_|github_pat_)[a-zA-Z0-9_]{20,}')
assert not any(secret.search(f.read_bytes()) for f in files),'REDACTION_REQUIRED'
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(r))
(dest/'SHA256.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in dest.iterdir()},indent=2)+'\n')
