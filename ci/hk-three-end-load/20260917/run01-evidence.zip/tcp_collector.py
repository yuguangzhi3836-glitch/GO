import subprocess,pathlib,shlex,json
work=pathlib.Path(__file__).parent
ssh=[r'C:\Users\Eason\.workbuddy\binaries\PortableGit\versions\1.2.0\usr\bin\ssh.exe','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10']
source="import json,pathlib,time,datetime,collections\nfor tick in range(240):\n out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}\n for name in ['snmp','netstat','sockstat','sockstat6']:\n  lines=pathlib.Path('/proc/net/'+name).read_text().splitlines()\n  if name in ['snmp','netstat']:\n   groups={}\n   for i in range(0,len(lines)-1,2):\n    keys=lines[i].split();vals=lines[i+1].split()\n    groups[keys[0].rstrip(':')]={k:int(v) for k,v in zip(keys[1:],vals[1:]) if v.lstrip('-').isdigit()}\n   out[name]=groups\n  else:out[name]=lines\n states=collections.Counter()\n for name in ['tcp','tcp6']:\n  for line in pathlib.Path('/proc/net/'+name).read_text().splitlines()[1:]:\n   states[line.split()[3]]+=1\n out['tcp_states']=dict(states)\n print(json.dumps(out),flush=True)\n time.sleep(5)\n"
child=subprocess.Popen(ssh+['hk-staging','python3 -u -c '+shlex.quote(source)],stdout=(work/'host-tcp.ndjson').open('w'),stderr=(work/'host-tcp.stderr').open('w'),text=True)
print(json.dumps({'tcp_sampler_pid':child.pid}),flush=True)
child.wait()
