"""Bounded, read-only HK telemetry collector for the authenticated load run."""
import subprocess, json, datetime, time, pathlib, os
EXPECTED = 'sha256:8f8beb568209393fd74660c226ca7b14b2efe171caf5521645ec6fe4cea56119'
SERVICES = {'api','outbox-worker','recovery-worker','reconciliation-worker','judgment-worker','mobile-engagement-worker','mobile-push-worker','mobile-push-receipt-worker'}
DB_PROBE = '''import json
from sqlalchemy import text
from go_hotel.db.session import engine
with engine.connect() as c:
 with c.begin():
  c.execute(text("SET TRANSACTION READ ONLY"))
  c.execute(text("SET LOCAL statement_timeout = '1500ms'"))
  head=list(c.execute(text("select version_num from alembic_version")).scalars())
  activity=[dict(x) for x in c.execute(text("select state,wait_event_type,count(*) n from pg_stat_activity where datname=current_database() group by state,wait_event_type")).mappings()]
  outbox=[dict(x) for x in c.execute(text("select status,count(*) n from transactional_outbox group by status")).mappings()]
print(json.dumps({'db_heads':head,'connections':activity,'outbox':outbox},default=str))
'''
def run(args, timeout=8):
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    if p.returncode: raise RuntimeError('PROBE_EXIT_'+str(p.returncode))
    return p.stdout
start=time.monotonic(); tick=0; last_db=None; last_db_at=None; baseline={}
while time.monotonic()-start < 1800:
    cycle=time.monotonic()
    row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'healthy':True,'reason':None}
    try:
        ids=run(['docker','ps','-a','--filter','label=com.docker.compose.project=go-822-staging','--format','{{.ID}}']).split()
        containers=json.loads(run(['docker','inspect',*ids]))
        facts=[]; seen=set()
        for x in containers:
            service=x['Config']['Labels'].get('com.docker.compose.service')
            state=x['State']
            f={'service':service,'id':x['Id'],'image':x['Image'],'running':state['Running'],'oom_killed':state['OOMKilled'],'restart_count':x['RestartCount'],'health':state.get('Health',{}).get('Status')}
            facts.append(f)
            baseline.setdefault(service,(f['id'],f['restart_count']))
            if (f['id'],f['restart_count']) != baseline[service] or not f['running'] or f['oom_killed'] or f['health']=='unhealthy':
                row.update(healthy=False,reason='SERVICE_CHANGED_OR_DEGRADED_'+str(service))
            if service in SERVICES:
                seen.add(service)
                if f['image']!=EXPECTED: row.update(healthy=False,reason='RUNTIME_IMAGE_CHANGED')
        if seen != SERVICES: row.update(healthy=False,reason='BUSINESS_SERVICE_MISSING')
        row['containers']=facts
        row['stats']=[json.loads(s) for s in run(['docker','stats','--no-stream','--format','{{json .}}']).splitlines() if s]
        mem={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.split(':')[0] in {'MemTotal','MemAvailable','SwapTotal','SwapFree'}}
        row['host']={'memory_bytes':mem,'loadavg':os.getloadavg(),'cpu_ticks':pathlib.Path('/proc/stat').read_text().splitlines()[0].split()[1:]}
        if mem['MemAvailable']<128*1024*1024: row.update(healthy=False,reason='HOST_AVAILABLE_MEMORY_BELOW_128MIB')
        if tick%3==0:
            last_db=json.loads(run(['docker','exec','go-822-staging-api-1','python','-c',DB_PROBE],timeout=6))
            last_db_at=datetime.datetime.now(datetime.timezone.utc).isoformat()
        row['database']=last_db; row['database_sample_at']=last_db_at
        if last_db and last_db['db_heads']!=['0137_hosted_unknown_episode']: row.update(healthy=False,reason='DATABASE_HEAD_CHANGED')
    except Exception as e:
        row.update(healthy=False,reason='HOST_PROBE_'+type(e).__name__)
    row['sample_seconds']=round(time.monotonic()-cycle,3)
    print(json.dumps(row),flush=True)
    tick+=1
    time.sleep(max(0,5-(time.monotonic()-cycle)))
