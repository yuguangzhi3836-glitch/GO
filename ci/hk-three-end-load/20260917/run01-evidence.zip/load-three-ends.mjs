import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

// Protocol-level authenticated VUs; does not represent real browser rendering,
// transactional/order/payment coverage, or permission to enable external supply.
export const BASE = 'https://staging-api.goaidirect.com';
export const EXPECTED = Object.freeze({
  source_sha: 'edd3500575d2f2b81298cc9273025e0a3b734897',
  image: 'sha256:8f8beb568209393fd74660c226ca7b14b2efe171caf5521645ec6fe4cea56119',
  db_head: '0137_hosted_unknown_episode',
});
export const ROLES = ['consumer', 'supplier', 'admin'];
export const VERTICALS = ['HOTEL', 'FLIGHT', 'RAIL', 'RIDE', 'RENTAL', 'ATTRACTION'];
export const PLAN = [20, 100, 250, 500, 1000].map(vus => ({ vus, seconds: vus === 1000 ? 120 : 60 }));
export const LIMITS = { p95_ms: 2000, p99_ms: 5000, error_rate: .01, semantic_errors: 0,
  abort_window_ms: 15000, abort_p95_ms: 3000, abort_error_rate: .05,
  abort_consecutive_checks: 3, timeout_ms: 5000, max_requests: 50000, telemetry_age_ms: 15000 };
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const iso = () => new Date().toISOString();
const sleep = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
const object = x => x !== null && typeof x === 'object' && !Array.isArray(x);
const string = x => typeof x === 'string' && x.length > 0;
const safeCode = x => typeof x === 'string' && /^[A-Z][A-Z0-9_]{1,95}$/.test(x) ? x : null;
export function quantile(values, q) {
  const a = [...values].sort((x, y) => x - y);
  return a.length ? a[Math.max(0, Math.ceil(a.length * q) - 1)] : null;
}
export function allocation(n) {
  const consumer = Math.round(n * .7), supplier = Math.round(n * .15);
  return { consumer, supplier, admin: n - consumer - supplier };
}
export function summary(rows) {
  const errors = rows.filter(r => !r.ok).length;
  return { requests: rows.length, errors, error_rate: rows.length ? errors / rows.length : null,
    semantic_errors: rows.filter(r => r.status === 200 && !r.semantic_ok).length,
    p50_ms: quantile(rows.map(r => r.elapsed_ms), .5), p95_ms: quantile(rows.map(r => r.elapsed_ms), .95),
    p99_ms: quantile(rows.map(r => r.elapsed_ms), .99),
    statuses: rows.reduce((o, r) => (o[r.status] = (o[r.status] || 0) + 1, o), {}) };
}
export function thresholdsPassed(s) {
  return s.requests > 0 && s.p95_ms <= LIMITS.p95_ms && s.p99_ms <= LIMITS.p99_ms &&
    s.error_rate <= LIMITS.error_rate && s.semantic_errors === 0;
}
export function externalLive(value) {
  if (!object(value) && !Array.isArray(value)) return false;
  if (object(value) && value.external_live === true) return true;
  return Object.values(value).some(externalLive);
}
export function criteria(vertical, vu) {
  const date = n => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
  const day = date(30 + vu % 5), end = date(35 + vu % 5);
  const map = {
    HOTEL: ['/v1/search/hotels', { destination: { city_code: 'TYO' }, stay: { check_in: day, check_out: end }, occupancy: { rooms: 1, adults: 2, children: 0 }, currency: 'CNY' }],
    FLIGHT: ['/v1/flights/journeys/search', { trip_type: 'ROUND_TRIP', adults: 2, legs: [{ origin: 'SHA', destination: 'PEK', departure_date: day }, { origin: 'PEK', destination: 'SHA', departure_date: end }] }],
    RAIL: ['/v1/rail/search', { origin_station: 'SHA', destination_station: 'HZH', travel_date: day }],
    RIDE: ['/v1/mobility/rides/search', { pickup: 'PVG', dropoff: 'Bund', pickup_at: day + 'T10:00:00+08:00' }],
    RENTAL: ['/v1/mobility/rentals/search', { pickup_location: 'NRT', return_location: 'NRT', pickup_at: day + 'T10:00:00+09:00', return_at: end + 'T10:00:00+09:00' }],
    ATTRACTION: ['/v1/attractions/search', { destination: '东京', visit_date: day }],
  };
  return { kind: vertical, route: map[vertical][0], body: map[vertical][1] };
}
export function validate(kind, d, context = {}) {
  if (!object(d)) return false;
  if (kind === 'POLICY') return d.environment === 'staging' && typeof d.admin_mfa_required === 'boolean';
  if (kind === 'LOGIN') return d.authenticated === true;
  if (kind === 'REFRESH') return d.refreshed === true;
  if (kind === 'LOGOUT') return d.status === 'REVOKED';
  if (kind === 'ME') {
    if (!string(d.user_id) || (context.userId && context.userId !== d.user_id)) return false;
    if (context.role === 'consumer') return d.status === 'ACTIVE' &&
      (!context.username || d.email?.trim().toLowerCase() === context.username.trim().toLowerCase());
    return d.actor_type === (context.role === 'supplier' ? 'SUPPLIER_USER' : 'GO_ADMIN') &&
      string(d.session_id) && Array.isArray(d.permissions) &&
      (!context.username || d.username?.trim().toLowerCase() === context.username.trim().toLowerCase()) &&
      (context.role !== 'supplier' || (string(d.supplier_id) && d.permissions.length === 1 && d.permissions[0] === 'supplier:read' &&
        Array.isArray(d.roles) && d.roles.length === 1 && d.roles[0] === 'READ_ONLY')) &&
      (!context.supplierId || d.supplier_id === context.supplierId) &&
      (context.role !== 'admin' || (d.permissions.length === 1 && d.permissions[0] === 'admin:read' &&
        Array.isArray(d.roles) && d.roles.length === 1 && d.roles[0] === 'GO_READ_ONLY'));
  }
  if (kind === 'TRIPS') return Array.isArray(d.items);
  if (kind === 'SUPPLIER_ORDERS') return Array.isArray(d.items) && d.count === d.items.length && d.limit === 50 && d.offset === 0 &&
    d.items.every(x => object(x) && VERTICALS.includes(x.vertical) && string(x.order_id) && string(x.status));
  if (kind.startsWith('ADMIN_')) return d.vertical === kind.slice(6) && Array.isArray(d.orders) && Array.isArray(d.refunds) &&
    object(d.metrics) && Number.isInteger(d.metrics.orders) && d.metrics.orders >= 0 && Number.isInteger(d.metrics.refunds) && d.metrics.refunds >= 0;
  if (externalLive(d)) return false;
  if (kind === 'HOTEL') return Array.isArray(d.hotels) && d.hotels.length > 0 && d.hotels.every(h => string(h?.best_offer?.offer_id));
  if (kind === 'FLIGHT') return Array.isArray(d.legs) && d.legs.length === 2 && d.legs.every(l => Array.isArray(l.items) && l.items.length > 0) && d.external_live === false;
  if (['RAIL', 'RIDE', 'RENTAL', 'ATTRACTION'].includes(kind)) return Array.isArray(d.items) && d.items.length > 0 && d.items.every(x => object(x) && x.external_live === false);
  return false;
}
export class CookieJar {
  constructor() { this.cookies = new Map(); }
  absorb(headers, requestPath) {
    if (typeof headers.getSetCookie !== 'function') throw new Error('NODE_GETSETCOOKIE_REQUIRED');
    for (const line of headers.getSetCookie()) {
      const parts = line.split(';'), at = parts[0].indexOf('=');
      if (at < 1) continue;
      const name = parts[0].slice(0, at).trim(), value = parts[0].slice(at + 1).trim();
      const attrs = Object.fromEntries(parts.slice(1).map(p => {
        const [k, ...v] = p.trim().split('='); return [k.toLowerCase(), v.join('=')];
      }));
      const domain = (attrs.domain || new URL(BASE).hostname).replace(/^\./, '').toLowerCase();
      const host = new URL(BASE).hostname;
      if (!(host === domain || host.endsWith('.' + domain))) throw new Error('UNEXPECTED_COOKIE_DOMAIN');
      const cookiePath = attrs.path || requestPath.slice(0, requestPath.lastIndexOf('/') + 1) || '/';
      const expires = attrs['max-age'] !== undefined ? Date.now() + Number(attrs['max-age']) * 1000 : attrs.expires ? Date.parse(attrs.expires) : Infinity;
      const key = name + '|' + cookiePath;
      if (!value || expires <= Date.now()) this.cookies.delete(key);
      else this.cookies.set(key, { name, value, path: cookiePath, expires });
    }
  }
  header(requestPath) {
    const p = requestPath.split('?')[0];
    return [...this.cookies.values()].filter(c => c.expires > Date.now() &&
      (p === c.path || (p.startsWith(c.path) && (c.path.endsWith('/') || p[c.path.length] === '/'))))
      .sort((a, b) => b.path.length - a.path.length).map(c => c.name + '=' + c.value).join('; ');
  }
  get(name) { return [...this.cookies.values()].find(c => c.name === name && c.expires > Date.now())?.value; }
  expiry(role) {
    const token = this.get(role === 'consumer' ? 'go_consumer_access' : 'go_access');
    try { return JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString()).exp * 1000; }
    catch { return 0; }
  }
}
export function orderedUsers(users, counts) {
  const result = [], used = Object.fromEntries(ROLES.map(r => [r, 0]));
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  while (result.length < total) {
    const role = ROLES.filter(r => used[r] < counts[r]).sort((a, b) => used[a] / counts[a] - used[b] / counts[b])[0];
    result.push(users[role][used[role]++]);
  }
  return result;
}
function totp(secret) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = '';
  for (const c of secret.toUpperCase().replace(/[\s=]/g, '')) {
    const value = alphabet.indexOf(c); if (value < 0) throw new Error('INVALID_TOTP_SECRET');
    bits += value.toString(2).padStart(5, '0');
  }
  const bytes = Buffer.from((bits.match(/.{8}/g) || []).map(x => parseInt(x, 2)));
  const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 30000)));
  const digest = crypto.createHmac('sha1', bytes).update(counter).digest(), offset = digest[19] & 15;
  return ((digest.readUInt32BE(offset) & 0x7fffffff) % 1000000).toString().padStart(6, '0');
}
function argsOf(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const key = argv[i]; if (!key.startsWith('--')) throw new Error('INVALID_ARGUMENT');
    if (['--run', '--probe', '--self-test'].includes(key)) args[key.slice(2)] = true;
    else { if (!argv[i + 1] || argv[i + 1].startsWith('--')) throw new Error('MISSING_ARGUMENT'); args[key.slice(2)] = argv[++i]; }
  }
  return args;
}
export function verifyBinding(binding) {
  if (!object(binding) || Object.entries(EXPECTED).some(([k, v]) => binding[k] !== v) ||
      binding.environment !== 'staging' || binding.external_live !== false || binding.simulation_only !== true ||
      !Number.isFinite(Date.parse(binding.at)) || Date.now() - Date.parse(binding.at) > 3600000 || Date.parse(binding.at) > Date.now() + 5000) {
    throw new Error('CURRENT_RUNTIME_BINDING_REQUIRED');
  }
  return Object.fromEntries([...Object.keys(EXPECTED), 'environment', 'external_live', 'simulation_only', 'at'].map(k => [k, binding[k]]));
}
export async function main(argv) {
  const args = argsOf(argv);
  if (args['self-test']) { selfTest(); return; }
  if (!args.run && !args.probe) { console.log(JSON.stringify({ mode: 'PLAN_ONLY', target: BASE, identity: EXPECTED, plan: PLAN, allocation: allocation(1000), limits: LIMITS })); return; }
  if (args.run && args.probe) throw new Error('CHOOSE_PROBE_OR_RUN');
  for (const k of ['accounts', 'identity', 'telemetry-file', 'output']) if (!args[k]) throw new Error('MISSING_' + k.toUpperCase().replaceAll('-', '_'));
  if (!AbortSignal.any || !Headers.prototype.getSetCookie) throw new Error('NODE_22_OR_NEWER_REQUIRED');
  const loginDelay = Number(args['login-delay-ms'] || 250);
  if (!Number.isFinite(loginDelay) || loginDelay < 100 || loginDelay > 5000) throw new Error('INVALID_LOGIN_DELAY');
  const identityBytes = fs.readFileSync(args.identity), identity = verifyBinding(JSON.parse(identityBytes));
  const accounts = JSON.parse(fs.readFileSync(args.accounts));
  const wanted = args.probe ? { consumer: 1, supplier: 1, admin: 1 } : allocation(1000);
  const usernames = new Set();
  for (const role of ROLES) {
    if (!Array.isArray(accounts[role]) || accounts[role].length < wanted[role]) throw new Error('INSUFFICIENT_' + role.toUpperCase() + '_ACCOUNTS');
    for (const a of accounts[role].slice(0, wanted[role])) {
      if (!string(a.username) || !string(a.password)) throw new Error('INVALID_ACCOUNT');
      const key = a.username.trim().toLowerCase(); if (usernames.has(key)) throw new Error('DUPLICATE_ACCOUNT'); usernames.add(key);
    }
  }
  const output = path.resolve(args.output);
  fs.mkdirSync(path.dirname(output), { recursive: true }); fs.mkdirSync(output, { mode: 0o700 });
  const raw = fs.openSync(path.join(output, 'requests.ndjson'), 'wx', 0o600);
  const activityFd = fs.openSync(path.join(output, 'activity.ndjson'), 'wx', 0o600);
  const runId = 'hk3-' + Date.now().toString(36) + '-' + crypto.randomBytes(3).toString('hex');
  const abort = new AbortController(), rows = [], users = Object.fromEntries(ROLES.map(r => [r, []]));
  let stopReason = null, stoppedAt = null, seq = 0, inFlight = 0, maximumInFlight = 0, stage = null;
  const active = Object.fromEntries(ROLES.map(r => [r, 0]));
  const report = { schema_version: 1, run_id: runId, mode: args.probe ? 'PROBE' : 'RUN', started_at: iso(),
    target: BASE, identity, identity_file_sha256: sha(identityBytes), harness_sha256: sha(fs.readFileSync(new URL(import.meta.url))),
    allocation: wanted, plan: PLAN, thresholds: LIMITS, think_time_seconds: [3, 7],
    workload: 'AUTHENTICATED_READS_AND_SIX_VERTICAL_SEARCHES', browser_ux_tested: false,
    account_population: {}, stages: [], endpoint_preflight: [], data_range: {},
    gates: { authenticated_three_end_1000_vus: 'NOT_RUN', payment_transactions: 'NOT_TESTED', production: 'HOLD' },
    limitations: ['No order creation, payment, refund, or browser rendering coverage.',
      'New C accounts can have empty trips and new B tenants can have empty order lists.',
      'Search endpoints may persist synthetic quotes; no transaction writes are requested.',
      'Hotel source isolation is bound to the independent runtime evidence, since its response may omit external_live.'],
    generator: { node: process.version, cpus: os.cpus().length, platform: process.platform, total_memory_bytes: os.totalmem() } };
  const save = () => fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2), { mode: 0o600 });
  function stop(reason) {
    if (!stopReason) { stopReason = safeCode(reason) || 'UNCLASSIFIED_STOP'; stoppedAt = Date.now(); abort.abort(); console.log(JSON.stringify({ stopped_at: iso(), reason: stopReason })); }
  }
  const signalStop = () => stop('OPERATOR_INTERRUPT');
  process.once('SIGINT', signalStop); process.once('SIGTERM', signalStop);
  function telemetry() {
    try {
      const t = JSON.parse(fs.readFileSync(args['telemetry-file'])), age = Date.now() - Date.parse(t.at);
      if (!Number.isFinite(age) || age < -5000 || age > LIMITS.telemetry_age_ms) throw new Error('TELEMETRY_STALE');
      if (t.healthy !== true) throw new Error(safeCode(t.reason) || 'HOST_DEGRADED');
      if (Object.keys(EXPECTED).some(k => t[k] !== undefined && t[k] !== EXPECTED[k])) throw new Error('RUNTIME_IDENTITY_DRIFT');
      if (t.external_live === true) throw new Error('EXTERNAL_LIVE_ENABLED');
      report.last_telemetry = { at: t.at, healthy: true }; return true;
    } catch (e) { stop(safeCode(e.message) || 'TELEMETRY_UNREADABLE'); return false; }
  }
  let lastTick = Date.now();
  const monitor = setInterval(() => {
    const now = Date.now(), lag = now - lastTick - 1000; lastTick = now;
    telemetry();
    if (stage) {
      const recent = rows.filter(r => r.stage === stage.vus && r.finished_ms > now - 15000 && !r.client_aborted && r.phase === 'load');
      const a = { at: iso(), at_ms: now, stage: stage.vus, active_vus: { ...active }, in_flight: inFlight,
        successful_distinct_vus_last_15s: Object.fromEntries(ROLES.map(role => [role, new Set(recent.filter(r => r.role === role && r.ok).map(r => r.vu)).size])),
        event_loop_lag_ms: Math.max(0, lag), generator_rss_bytes: process.memoryUsage().rss, generator_free_memory_bytes: os.freemem() };
      fs.writeSync(activityFd, JSON.stringify(a) + '\n');
      if (stage.steady_started_ms && now < stage.deadline_ms && !stopReason) {
        stage.activity_samples++;
        if (ROLES.some(r => active[r] !== stage.allocation[r])) stop('ACTIVE_POPULATION_LOST');
        if (lag > 1000) stop('GENERATOR_EVENT_LOOP_LAG');
        // Existing admission rule: 15 s rolling window, evaluated each second;
        // three consecutive bad checks stop (not three disjoint 15 s windows).
        if (recent.length >= 30 || now - stage.steady_started_ms >= 15000) {
          const left = now - 15000, right = now, windowRows = recent;
          const byRole = Object.fromEntries(ROLES.map(role => [role, summary(windowRows.filter(r => r.role === role))]));
          let bad = false;
          for (const role of ROLES) {
            const s = byRole[role], failing = s.requests === 0 || s.p95_ms > LIMITS.abort_p95_ms || s.error_rate > LIMITS.abort_error_rate;
            stage.bad_windows[role] = failing ? stage.bad_windows[role] + 1 : 0;
            bad ||= stage.bad_windows[role] >= LIMITS.abort_consecutive_checks;
          }
          stage.windows.push({ start_ms: left, end_ms: right, per_role: byRole });
          if (bad) stop('SUSTAINED_ROLE_LATENCY_OR_ERRORS');
          if (now - (stage.last_log_ms || 0) >= 10000) {
            console.log(JSON.stringify({ checkpoint: stage.vus, active_vus: { ...active }, per_role: byRole })); save(); stage.last_log_ms = now;
          }
        }
      }
    }
  }, 1000);
  async function request(user, spec, phase, stageVus = 0, { cleanup = false } = {}) {
    const requestId = runId + '-' + (++seq).toString(36), payload = spec.body === undefined ? undefined : JSON.stringify(spec.body);
    const row = { phase, stage: stageVus, role: user?.role || 'system', vu: user?.alias || null, kind: spec.kind,
      path: spec.route, method: payload === undefined ? 'GET' : 'POST', request_id: requestId, started_at: iso(), started_ms: Date.now() };
    if (VERTICALS.includes(spec.kind)) row.payload_sha256 = sha(payload);
    let data = null; const start = performance.now(); inFlight++; maximumInFlight = Math.max(maximumInFlight, inFlight);
    try {
      const headers = { 'Content-Type': 'application/json', 'X-Request-ID': requestId, 'User-Agent': 'GO-HK-Three-End-Load/1.0', 'Origin': BASE };
      if (user) {
        headers.Cookie = user.jar.header(spec.route); headers['X-GO-Session'] = user.role === 'consumer' ? 'consumer' : 'console';
        if (user.role !== 'consumer') headers['X-GO-Actor'] = user.role === 'supplier' ? 'SUPPLIER_USER' : 'GO_ADMIN';
        const csrf = user.jar.get(user.role === 'consumer' ? 'go_consumer_csrf' : 'go_csrf');
        if (payload !== undefined && csrf) headers['X-CSRF-Token'] = csrf;
      }
      const response = await fetch(BASE + spec.route, { method: row.method, body: payload, headers, redirect: 'error',
        signal: cleanup ? AbortSignal.timeout(LIMITS.timeout_ms) : AbortSignal.any([abort.signal, AbortSignal.timeout(LIMITS.timeout_ms)]) });
      const text = await response.text(); row.status = response.status; row.response_sha256 = sha(text);
      row.response_request_id = /^[\w-]{1,128}$/.test(response.headers.get('x-request-id') || '') ? response.headers.get('x-request-id') : null;
      if (user) user.jar.absorb(response.headers, spec.route);
      let envelope = null; try { envelope = JSON.parse(text); data = envelope.data; } catch { /* Never persist body. */ }
      row.error_code = safeCode(envelope?.detail) || safeCode(envelope?.error?.code) || null;
      row.semantic_ok = response.status === 200 && validate(spec.kind, data, { role: user?.role, userId: user?.userId, supplierId: user?.supplierId, username: user?.expectedUsername });
      row.ok = row.status === 200 && row.semantic_ok && row.response_request_id === requestId;
      if (row.status === 429 && !cleanup) stop('RATE_LIMIT_429');
      if (VERTICALS.includes(spec.kind) && externalLive(data)) stop('EXTERNAL_LIVE_RESPONSE');
      if (spec.kind === 'ME' && row.status === 200 && !row.semantic_ok) stop('IDENTITY_OR_PERMISSION_MISMATCH');
    } catch (e) {
      row.status = 0; row.ok = false; row.semantic_ok = false;
      row.client_aborted = !cleanup && abort.signal.aborted && (e === abort.signal.reason || e.name === 'AbortError');
      row.error_code = safeCode(e.code) || safeCode(e.cause?.code) || (e.name === 'TimeoutError' ? 'REQUEST_TIMEOUT' : 'TRANSPORT_ERROR');
    } finally {
      inFlight--; row.elapsed_ms = Math.round((performance.now() - start) * 100) / 100; row.finished_ms = Date.now();
      rows.push(row); fs.writeSync(raw, JSON.stringify(row) + '\n');
    }
    if (rows.length >= LIMITS.max_requests && !cleanup) stop('REQUEST_BUDGET_EXHAUSTED');
    return { row, data };
  }
  const meSpec = user => ({ kind: 'ME', route: user.role === 'consumer' ? '/v1/consumer/me' : '/bff/auth/me' });
  async function refreshIfNeeded(user, phase) {
    if (user.jar.expiry(user.role) > Date.now() + 90000) return true;
    const r = await request(user, { kind: 'REFRESH', route: user.role === 'consumer' ? '/v1/consumer/auth/refresh' : '/bff/auth/refresh', body: {} }, phase, stage?.vus || 0);
    if (!r.row.ok) { stop('SESSION_REFRESH_FAILED'); return false; }
    return true;
  }
  function specs(user) {
    if (user.role === 'consumer') return [...VERTICALS.map(v => criteria(v, user.index)), meSpec(user), { kind: 'TRIPS', route: '/v1/consumer/unified-trips' }];
    if (user.role === 'supplier') return [meSpec(user), { kind: 'SUPPLIER_ORDERS', route: '/v1/supplier/transaction-orders?limit=50&offset=0' }];
    return [meSpec(user), ...VERTICALS.map(v => ({ kind: 'ADMIN_' + v, route: '/internal/v1/admin/operations/verticals/' + v }))];
  }
  try {
    if (!telemetry()) throw new Error('TELEMETRY_REQUIRED');
    const policy = await request(null, { kind: 'POLICY', route: '/bff/auth/policy' }, 'policy');
    if (!policy.row.ok) throw new Error('STAGING_POLICY_FAILED');
    report.policy = { environment: policy.data.environment, admin_mfa_required: policy.data.admin_mfa_required };
    for (const role of ROLES) for (let i = 0; i < wanted[role]; i++) users[role].push({ role, index: i, alias: role[0] + i, jar: new CookieJar(), account: accounts[role][i],
      expectedUsername: accounts[role][i].username, userId: accounts[role][i].user_id || null, supplierId: accounts[role][i].supplier_id || null });
    for (const user of orderedUsers(users, wanted)) {
      if (stopReason || !telemetry()) break;
      const a = user.account, body = user.role === 'consumer' ? { email: a.username, password: a.password } : {
        username: a.username, password: a.password, expected_actor_type: user.role === 'supplier' ? 'SUPPLIER_USER' : 'GO_ADMIN',
        ...(a.totp_secret || a.totp_code ? { totp_code: a.totp_secret ? totp(a.totp_secret) : a.totp_code } : {}) };
      const r = await request(user, { kind: 'LOGIN', route: user.role === 'consumer' ? '/v1/consumer/auth/login' : '/bff/auth/login', body }, 'login');
      delete user.account; delete a.password; delete a.totp_secret; delete a.totp_code;
      if (!r.row.ok) throw new Error('ACCOUNT_LOGIN_FAILED');
      user.loggedIn = true;
      const m = await request(user, meSpec(user), 'identity');
      if (!m.row.ok) throw new Error('ACCOUNT_IDENTITY_FAILED');
      user.userId = m.data.user_id; user.supplierId = m.data.supplier_id || null;
      user.sessionHash = sha(runId + '|' + (m.data.session_id || user.jar.get('go_consumer_access') || ''));
      await sleep(loginDelay);
      if (seq % 100 === 0) console.log(JSON.stringify({ prepared_accounts: Object.fromEntries(ROLES.map(r => [r, users[r].filter(u => u.loggedIn).length])) }));
    }
    if (stopReason) throw new Error(stopReason);
    const identities = new Set(), sessions = new Set();
    for (const role of ROLES) {
      const population = users[role];
      for (const u of population) {
        if (identities.has(u.userId) || sessions.has(u.sessionHash)) throw new Error('DUPLICATE_AUTHENTICATED_IDENTITY');
        identities.add(u.userId); sessions.add(u.sessionHash);
      }
      report.account_population[role] = { authenticated_accounts: population.length, distinct_user_ids: new Set(population.map(u => u.userId)).size,
        distinct_session_fingerprints: new Set(population.map(u => u.sessionHash)).size,
        distinct_supplier_ids: new Set(population.map(u => u.supplierId).filter(Boolean)).size };
    }
    for (const role of ROLES) {
      const user = users[role][0];
      if (!await refreshIfNeeded(user, 'preflight')) throw new Error('PREFLIGHT_REFRESH_FAILED');
      for (const spec of specs(user)) {
        const r = await request(user, spec, 'preflight');
        report.endpoint_preflight.push({ role, kind: spec.kind, path: spec.route, status: r.row.status, ok: r.row.ok, request_id: r.row.request_id });
        if (spec.kind === 'TRIPS' || spec.kind === 'SUPPLIER_ORDERS') report.data_range[role] = { first_account_items: r.data?.items?.length ?? null, scope: role === 'consumer' ? 'OWN_ACCOUNT' : 'OWN_SUPPLIER' };
        if (!r.row.ok) throw new Error('ENDPOINT_PREFLIGHT_FAILED');
        await sleep(150);
      }
    }
    report.preflight_passed = true; save();
    if (args.probe) report.gates.probe = 'PASS';
    else for (const p of PLAN) {
      if (stopReason || !telemetry()) break;
      const selected = orderedUsers(users, allocation(p.vus));
      for (const u of selected) { if (!await refreshIfNeeded(u, 'stage_preparation')) break; }
      if (stopReason) break;
      let release; const barrier = new Promise(resolve => { release = resolve; });
      stage = { ...p, started_at: iso(), allocation: allocation(p.vus), requested_steady_seconds: p.seconds,
        ramp_ms: Math.min(10000, p.vus * 40), activity_samples: 0, windows: [], bad_windows: Object.fromEntries(ROLES.map(r => [r, 0])) };
      report.stages.push(stage); const current = stage;
      console.log(JSON.stringify({ stage_start: p.vus, allocation: current.allocation, at: iso() }));
      let arrived = 0;
      await Promise.all(selected.map(async (user, position) => {
        await sleep(current.ramp_ms * position / p.vus);
        if (stopReason) { release(); return; }
        active[user.role]++; arrived++;
        if (arrived === p.vus) {
          current.steady_started_ms = Date.now(); current.steady_started_at = iso();
          current.deadline_ms = current.steady_started_ms + p.seconds * 1000;
          release();
        }
        try {
          await barrier;
          // Deterministic sub-second dispersion after all roles are active.
          await sleep((position * 977) % 1000);
          let iteration = user.index, operations = specs(user);
          while (!stopReason && Date.now() < current.deadline_ms) {
            if (!await refreshIfNeeded(user, 'load_refresh')) break;
            await request(user, operations[iteration++ % operations.length], 'load', p.vus);
            await sleep(Math.min(3000 + ((user.index * 977 + iteration * 137) % 4001), Math.max(0, current.deadline_ms - Date.now())));
          }
        } finally { active[user.role]--; }
      }));
      const ended = Math.min(stoppedAt ?? Date.now(), current.deadline_ms ?? Date.now());
      current.measured_steady_seconds = current.steady_started_ms ? Math.max(0, (ended - current.steady_started_ms) / 1000) : 0;
      current.finished_at = iso(); current.stop_reason = stopReason;
      // Include natural completions during drain if they STARTED within steady time:
      // excluding slow tail requests would bias latency/errors toward a false pass.
      const steadyRows = rows.filter(r => r.phase === 'load' && r.stage === p.vus && r.started_ms >= current.steady_started_ms && r.started_ms < ended && !r.client_aborted);
      current.summary = summary(steadyRows); current.per_role = {}; current.per_kind = {};
      for (const role of ROLES) {
        const rr = steadyRows.filter(r => r.role === role), s = summary(rr);
        current.per_role[role] = { ...s, successful_distinct_vus: new Set(rr.filter(r => r.ok && r.finished_ms <= ended).map(r => r.vu)).size,
          rps: current.measured_steady_seconds ? rr.filter(r => r.finished_ms <= ended).length / current.measured_steady_seconds : 0 };
      }
      for (const kind of new Set(steadyRows.map(r => r.kind))) current.per_kind[kind] = summary(steadyRows.filter(r => r.kind === kind));
      current.passed = !stopReason && current.measured_steady_seconds >= p.seconds && current.activity_samples >= p.seconds - 2 &&
        thresholdsPassed(current.summary) && ROLES.every(r => thresholdsPassed(current.per_role[r]) && current.per_role[r].successful_distinct_vus === current.allocation[r]);
      console.log(JSON.stringify({ stage_result: p.vus, passed: current.passed, per_role: current.per_role })); save(); stage = null;
      if (!current.passed) stop('STAGE_ACCEPTANCE_FAILED');
      if (!telemetry()) break;
    }
  } catch (e) { stop(safeCode(e.message) || 'HARNESS_EXCEPTION'); }
  finally {
    clearInterval(monitor);
    // Revoke each established test session slowly; never erase/modify accounts or orders.
    let logoutSuccess = 0, logoutFailure = 0, consecutiveLogoutFailures = 0;
    const loggedIn = ROLES.flatMap(r => users[r]).filter(u => u.loggedIn);
    for (const user of loggedIn) {
      if (user.jar.expiry(user.role) <= Date.now() + 10000) {
        const refreshed = await request(user, { kind: 'REFRESH', route: user.role === 'consumer' ? '/v1/consumer/auth/refresh' : '/bff/auth/refresh', body: {} }, 'cleanup_refresh', 0, { cleanup: true });
        if (!refreshed.row.ok) {
          logoutFailure++; consecutiveLogoutFailures++;
          if (consecutiveLogoutFailures >= 5) break;
          await sleep(100); continue;
        }
      }
      const r = await request(user, { kind: 'LOGOUT', route: user.role === 'consumer' ? '/v1/consumer/auth/logout' : '/bff/auth/logout', body: {} }, 'cleanup', 0, { cleanup: true });
      if (r.row.ok) { logoutSuccess++; consecutiveLogoutFailures = 0; }
      else { logoutFailure++; consecutiveLogoutFailures++; }
      if (consecutiveLogoutFailures >= 5) break;
      await sleep(100);
    }
    telemetry();
    report.cleanup = { logout_success: logoutSuccess, logout_failed: logoutFailure,
      logout_unattempted: loggedIn.length - logoutSuccess - logoutFailure,
      remaining_sessions: 'Failed/unattempted revocations are not claimed closed; ordinary server expiry still applies.' };
    report.finished_at = iso(); report.stop_reason = stopReason; report.stopped_at = stoppedAt ? new Date(stoppedAt).toISOString() : null;
    report.maximum_in_flight_requests = maximumInFlight;
    report.maximum_stage_started = Math.max(0, ...report.stages.map(s => s.vus));
    report.maximum_stage_passed = Math.max(0, ...report.stages.filter(s => s.passed).map(s => s.vus));
    report.client_aborted_requests = rows.filter(r => r.client_aborted).length;
    report.summary = summary(rows.filter(r => r.phase === 'load' && !r.client_aborted));
    if (!args.probe) report.gates.authenticated_three_end_1000_vus = !stopReason && report.maximum_stage_passed === 1000 ? 'SCOPED_PASS' : 'NOT_PASSED';
    report.success = !stopReason && (args.probe ? report.preflight_passed === true : report.maximum_stage_passed === 1000);
    if (args.probe && !report.success) report.gates.probe = 'NOT_PASSED';
    save(); fs.closeSync(raw); fs.closeSync(activityFd);
    const hashes = Object.fromEntries(fs.readdirSync(output).map(n => [n, sha(fs.readFileSync(path.join(output, n)))]));
    fs.writeFileSync(path.join(output, 'sha256.json'), JSON.stringify(hashes, null, 2), { mode: 0o600 });
    console.log('FINAL_REPORT=' + JSON.stringify(report)); process.exitCode = report.success ? 0 : 1;
    process.removeListener('SIGINT', signalStop); process.removeListener('SIGTERM', signalStop);
  }
}
function selfTest() {
  assert.deepEqual(allocation(1000), { consumer: 700, supplier: 150, admin: 150 });
  assert.deepEqual(allocation(20), { consumer: 14, supplier: 3, admin: 3 });
  assert.equal(validate('HOTEL', { hotels: [{ best_offer: { offer_id: 'x', external_live: true } }] }), false);
  assert.equal(validate('HOTEL', { hotels: [] }), false);
  assert.equal(validate('ME', { user_id: 'a', status: 'ACTIVE' }, { role: 'consumer', userId: 'b' }), false);
  assert.equal(validate('ME', { user_id: 'a', status: 'ACTIVE', email: 'wrong@example.test' }, { role: 'consumer', username: 'expected@example.test' }), false);
  assert.equal(validate('ME', { user_id: 'a', session_id: 's', username: 'test', actor_type: 'GO_ADMIN', permissions: ['admin:read'], roles: ['GO_READ_ONLY'] }, { role: 'admin', username: 'test' }), true);
  assert.equal(validate('ME', { user_id: 'a', session_id: 's', username: 'test', actor_type: 'GO_ADMIN', permissions: ['admin:read', 'admin:approve'], roles: ['GO_GOVERNANCE'] }, { role: 'admin', username: 'test' }), false);
  assert.equal(validate('ME', { user_id: 'a', session_id: 's', actor_type: 'SUPPLIER_USER', supplier_id: 's1', permissions: [] }, { role: 'supplier', supplierId: 's2' }), false);
  assert.equal(validate('SUPPLIER_ORDERS', { items: [], count: 0, limit: 50, offset: 0 }), true);
  assert.equal(thresholdsPassed(summary([{ ok: false, status: 200, semantic_ok: false, elapsed_ms: 2 }])), false);
  const jar = new CookieJar(), h = new Headers();
  h.append('set-cookie', 'go_access=a; Path=/; Secure'); h.append('set-cookie', 'go_refresh=r; Path=/bff/auth; Secure');
  jar.absorb(h, '/bff/auth/login'); assert.equal(jar.header('/v1/supplier/transaction-orders'), 'go_access=a');
  assert.equal(jar.header('/bff/auth/refresh').includes('go_refresh=r'), true);
  assert.equal(jar.header('/bff/authz').includes('go_refresh=r'), false);
  const u = Object.fromEntries(ROLES.map(r => [r, Array.from({ length: allocation(20)[r] }, (_, i) => ({ role: r, index: i }))]));
  assert.deepEqual(orderedUsers(u, allocation(20)).slice(0, 3).map(x => x.role), ROLES);
  assert.throws(() => verifyBinding({ ...EXPECTED, at: iso(), environment: 'production', external_live: false, simulation_only: true }));
  console.log('SELF_TEST_PASS');
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main(process.argv.slice(2)).catch(e => { console.error(safeCode(e.message) || 'HARNESS_START_FAILED'); process.exitCode = 1; });
}
