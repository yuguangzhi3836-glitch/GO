import subprocess,json,pathlib,time,shlex
work=pathlib.Path(__file__).parent
ssh=[r'C:\Users\Eason\.workbuddy\binaries\PortableGit\versions\1.2.0\usr\bin\ssh.exe','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10']
source=(work/'host_sampler.py').read_text(encoding='utf-8')
child=subprocess.Popen(ssh+['hk-staging','python3 -u -c '+shlex.quote(source)],stdout=subprocess.PIPE,stderr=(work/'host-sampler.stderr').open('w'),text=True,bufsize=1)
print(json.dumps({'sampler_pid':child.pid}),flush=True)
try:
 with (work/'host-telemetry.ndjson').open('w',encoding='utf-8') as log:
  for line in child.stdout:
   row=json.loads(line)
   log.write(line);log.flush()
   temp=work/'telemetry.tmp.json'
   temp.write_text(json.dumps(row),encoding='utf-8')
   for retry in range(5):
    try: temp.replace(work/'telemetry.json');break
    except PermissionError: time.sleep(.02)
except KeyboardInterrupt:
 child.terminate()
finally:
 child.wait(timeout=15)
